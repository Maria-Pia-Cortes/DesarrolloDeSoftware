package com.example.tpGrupalARCA.dto.Cliente;

import com.example.tpGrupalARCA.entities.Cliente;
import lombok.Builder;

@Builder
public record ClienteDTO(
        Long idCliente,
        String cuitCuil,
        String denominacion
) {
    public static ClienteDTO toDTO(Cliente cliente) {
        return ClienteDTO.builder()
                .idCliente(cliente.getId())
                .cuitCuil(cliente.getCuitCuil())
                .denominacion(cliente.getDenominacion())
                .build();
    }
}

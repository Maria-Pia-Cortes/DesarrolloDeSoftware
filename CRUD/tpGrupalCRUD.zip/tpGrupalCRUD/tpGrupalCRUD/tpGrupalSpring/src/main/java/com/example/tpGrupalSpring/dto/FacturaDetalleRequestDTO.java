package com.example.tpGrupalSpring.dto;

public record FacturaDetalleRequestDTO(
        Long articuloId,
        String descripcion,
        double cantidad,
        Double precioUnitario,     // opcional: si viene null, el service usa ListaPrecioArticulo.precioVenta
        double porcentajeBonificacion
) {
}

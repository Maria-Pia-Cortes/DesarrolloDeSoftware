package com.example.tpGrupalARCA.dto.ListaPrecio;

import com.example.tpGrupalARCA.entities.ListaPrecioArticulo;
import lombok.Builder;

@Builder
public record ListaPrecioArticuloDTO(
        Long idArticulo,
        String codigo,
        String denominacion,
        String denominacionRubro,
        String denominacionMarca,
        double precioVenta
) {
    public static ListaPrecioArticuloDTO toDTO(ListaPrecioArticulo listaPrecioArticulo){
        String denominacionMarca = null;
        String denominacionRubro = null;
        if (listaPrecioArticulo.getArticulo().getMarca() != null){
            denominacionMarca = listaPrecioArticulo.getArticulo().getMarca().getDenominacion();
        }
        if (listaPrecioArticulo.getArticulo().getRubro() != null){
            denominacionRubro = listaPrecioArticulo.getArticulo().getRubro().getDenominacion();
        }
        return ListaPrecioArticuloDTO.builder()
                .idArticulo(listaPrecioArticulo.getArticulo().getId())
                .codigo(listaPrecioArticulo.getArticulo().getCodigo())
                .denominacion(listaPrecioArticulo.getArticulo().getDenominacion())
                .denominacionRubro(denominacionRubro)
                .denominacionMarca(denominacionMarca)
                .precioVenta(listaPrecioArticulo.getPrecioVenta())
                .build();
    }
}

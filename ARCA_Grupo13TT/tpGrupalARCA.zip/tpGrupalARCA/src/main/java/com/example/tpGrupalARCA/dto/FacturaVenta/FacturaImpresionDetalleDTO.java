package com.example.tpGrupalARCA.dto.FacturaVenta;

import com.example.tpGrupalARCA.entities.FacturaVentaDetalle;

/**
 * Linea de la factura lista para imprimir.
 * El subtotal que se muestra en la grilla es el importe neto (cantidad x precio unitario);
 * el IVA se discrimina aparte en el pie de la factura.
 */
public record FacturaImpresionDetalleDTO(
        String descripcion,
        int cantidad,
        double precioUnitario,
        double importeNeto,
        double importeIva,
        double importeSubtotal
) {
    public static FacturaImpresionDetalleDTO toDto(FacturaVentaDetalle detalle) {
        // Si el detalle no tiene descripcion propia, se usa el nombre del articulo
        String descripcion = detalle.getDescripcion();
        if (descripcion == null || descripcion.isBlank()) {
            descripcion = detalle.getListaPrecioArticulo().getArticulo().getDenominacion();
        }
        return new FacturaImpresionDetalleDTO(
                descripcion,
                detalle.getCantidad(),
                detalle.getPrecioUnitario(),
                detalle.getImporteNeto(),
                detalle.getImporteIva(),
                detalle.getImporteSubtotal());
    }
}

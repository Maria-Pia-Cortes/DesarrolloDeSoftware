package com.example.tpGrupalSpring.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.*;

@Entity
@Table(name = "Marca", schema = "modelo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@EqualsAndHashCode(callSuper = true, exclude = {"denominacion"})
@ToString

public class Marca extends AuditoriaApp{
    @Column(nullable = false)
    private Integer codigo;
    @Setter
    @Column(nullable = false)
    private String denominacion;
}

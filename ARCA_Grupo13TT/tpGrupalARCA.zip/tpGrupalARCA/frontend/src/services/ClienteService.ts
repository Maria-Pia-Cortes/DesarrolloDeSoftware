import type { ClienteDTO } from "../models/cliente.dto";
import type { ErrorDTO } from "../models/error";

export class ClienteService{
    private readonly baseUrl = "http://localhost:8080/api/clientes";

    async buscarClientes(cuitCuil?: string, denominacion?: string): Promise<ClienteDTO[]>{
        const params = new URLSearchParams();
        if (cuitCuil) params.append("cuitCuil", cuitCuil);
        if (denominacion) params.append("denominacion", denominacion);

        const response = await fetch(`${this.baseUrl}?${params.toString()}`);

        if (!response.ok){
            let mensaje;
            try {
                const error: ErrorDTO = await response.json();
                mensaje = `Error: ${response.status} ` + error.detalles.join(", ");
            } catch {
               mensaje = "Fallo interno del sistema: " + `Error: ${response.status}`;
            }
                throw new Error(mensaje);
            }

        return await response.json();
    }
}
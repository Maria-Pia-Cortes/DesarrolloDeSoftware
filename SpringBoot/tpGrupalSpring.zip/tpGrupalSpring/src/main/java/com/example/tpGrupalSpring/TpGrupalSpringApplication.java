package com.example.tpGrupalSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpGrupalSpringApplication {

	public static void main(String[] args) {
        SpringApplication.run(TpGrupalSpringApplication.class, args);
    }
}

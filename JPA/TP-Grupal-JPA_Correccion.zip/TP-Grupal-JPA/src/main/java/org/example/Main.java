package org.example;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import org.example.entities.*;

import java.util.ArrayList;
import java.util.Date;

public class Main {
    public static void main(String[] args) {
        EntityManagerFactory emf =  Persistence.createEntityManagerFactory("FacturacionPU");
        EntityManager em = emf.createEntityManager();

        try {

            em.getTransaction().begin();

            Usuario usuario = Usuario.builder()
                    .usuario("admin")
                    .clave("1234")
                    .nombre("Juan")
                    .apellido("Perez")
                    .build();

            em.persist(usuario);


            // Fecha que utilizaremos para la auditoria
            Date ahora = new Date();

            Rubro rubro = Rubro.builder()
                    .codigo(100)
                    .denominacion("Informatica")
                    .build();

            auditar(rubro, usuario, ahora);

            em.persist(rubro);

            Marca marca = Marca.builder()
                    .codigo(10)
                    .denominacion("Logitech")
                    .build();

            auditar(marca, usuario, ahora);

            em.persist(marca);

            Articulo articulo1 = Articulo.builder()
                    .codigo("ART-001")
                    .denominacion("Teclado inalambrico")
                    .rubro(rubro)
                    .marca(marca)
                    .build();

            auditar(articulo1, usuario, ahora);

            em.persist(articulo1);

            Articulo articulo2 = Articulo.builder()
                    .codigo("ART-002")
                    .denominacion("Mouse optico")
                    .rubro(rubro)
                    .marca(marca)
                    .build();

            auditar(articulo2, usuario, ahora);

            em.persist(articulo2);

            ListaPrecio listaPrecio = ListaPrecio.builder()
                    .codigo("L1")
                    .denominacion("Lista de precios general")
                    .build();

            auditar(listaPrecio, usuario, ahora);

            em.persist(listaPrecio);



            ListaPrecioArticulo listaPrecioArticulo1 =
                    ListaPrecioArticulo.builder()
                            .listaPrecio(listaPrecio)
                            .articulo(articulo1)
                            .precioVenta(25000.00)
                            .build();

            auditar(listaPrecioArticulo1, usuario, ahora);

            em.persist(listaPrecioArticulo1);


            ListaPrecioArticulo listaPrecioArticulo2 =
                    ListaPrecioArticulo.builder()
                            .listaPrecio(listaPrecio)
                            .articulo(articulo2)
                            .precioVenta(12000.00)
                            .build();

            auditar(listaPrecioArticulo2, usuario, ahora);

            em.persist(listaPrecioArticulo2);


            PuntoVenta puntoVenta = PuntoVenta.builder()
                    .numero(1)
                    .descripcion("Punto de venta principal")
                    .tipoEmision("ELECTRONICA")
                    .domicilioComercial("Av. Siempre Viva 123")
                    .build();

            auditar(puntoVenta, usuario, ahora);

            em.persist(puntoVenta);

            double cantidad1 = 2;

            double importeNeto1 =
                    cantidad1 * listaPrecioArticulo1.getPrecioVenta();

            double importeIva1 =
                    importeNeto1 * 0.21;

            double importeSubtotal1 =
                    importeNeto1 + importeIva1;

            TipoMoneda tipoMoneda1 =
                    TipoMoneda.builder()
                            .codigoAfip("5050")
                            .denominacion("Verdura")
                            .simbolo("$")
                            .build();

            auditar(tipoMoneda1, usuario, ahora);
            em.persist(tipoMoneda1);

            Contacto contacto1 =
                    Contacto.builder()
                            .email("cosodelacosa@gmail.com")
                            .telefono("+54 9 2617878980")
                            .celular("4937349")
                            .build();
            em.persist(contacto1);


            Domicilio domicilio1 =
                    Domicilio.builder()
                            .nombreCalle("San Martin")
                            .numeroCalle("5510")
                            .build();
            em.persist(domicilio1);


            Cliente cliente1 =
                    Cliente.builder()
                            .cuitCuil("303030")
                            .denominacion("Cintia Clarez")
                            .contacto(contacto1)
                            .domicilio(domicilio1)
                            .build();

            auditar(cliente1,usuario,ahora);
            em.persist(cliente1);


            FacturaVentaDetalle detalle1 =
                    FacturaVentaDetalle.builder()
                            .listaPrecioArticulo(listaPrecioArticulo1)
                            .descripcion(articulo1.getDenominacion())
                            .cantidad(cantidad1)
                            .precioUnitario(listaPrecioArticulo1.getPrecioVenta())
                            .porcentajeBonificacion(0)
                            .importeNeto(importeNeto1)
                            .importeIva(importeIva1)
                            .importeSubtotal(importeSubtotal1)
                            .build();

            double cantidad2 = 1;

            double importeNeto2 =
                    cantidad2 * listaPrecioArticulo2.getPrecioVenta();

            double importeIva2 =
                    importeNeto2 * 0.21;

            double importeSubtotal2 =
                    importeNeto2 + importeIva2;

            FacturaVentaDetalle detalle2 =
                    FacturaVentaDetalle.builder()
                            .listaPrecioArticulo(listaPrecioArticulo2)
                            .descripcion(articulo2.getDenominacion())
                            .cantidad(cantidad2)
                            .precioUnitario(listaPrecioArticulo2.getPrecioVenta())
                            .porcentajeBonificacion(0)
                            .importeNeto(importeNeto2)
                            .importeIva(importeIva2)
                            .importeSubtotal(importeSubtotal2)
                            .build();


            double importeTotal =
                    importeSubtotal1 + importeSubtotal2;

            FacturaVenta facturaVenta =
                    FacturaVenta.builder()
                            .cliente(cliente1)
                            .tipoMoneda(tipoMoneda1)
                            .numero(1L)
                            .fechaEmision(ahora)
                            .puntoVenta(puntoVenta)
                            .importeCobrado(importeTotal)
                            .importeSaldo(0)
                            .importeTotal(importeTotal)
                            .estado("EMITIDA")
                            .observaciones("Venta de prueba")
                            .detalles(new ArrayList<>())
                            .build();

            auditar(facturaVenta, usuario, ahora);

            detalle1.setFacturaVenta(facturaVenta);
            detalle2.setFacturaVenta(facturaVenta);

            facturaVenta.getDetalles().add(detalle1);
            facturaVenta.getDetalles().add(detalle2);

            em.persist(facturaVenta);


            em.getTransaction().commit();

        } catch (Exception e) {

            if (em.getTransaction().isActive()) {
                System.out.println("HUBO UN ERROR");
                em.getTransaction().rollback();
            }

            throw e;

        } finally {

            em.close();
            emf.close();
        }
    }


    private static void auditar(
            AuditoriaApp entidad,
            Usuario usuario,
            Date fecha) {

        entidad.setFechaAlta(fecha);
        entidad.setFechaModificacion(fecha);
        entidad.setUsuarioCarga(usuario);
        entidad.setUsuarioModificacion(usuario);
    }
}
package com.example.tpGrupalARCA.controller;

import com.example.tpGrupalARCA.dto.CondicionIva.CondicionIvaDTO;
import com.example.tpGrupalARCA.service.CondicionIvaService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/condiciones-iva")
@RequiredArgsConstructor
public class CondicionIvaController {
    private final CondicionIvaService condicionIvaService;

    @GetMapping
    public List<CondicionIvaDTO> findAll(){
        return condicionIvaService.findAll();
    }
}

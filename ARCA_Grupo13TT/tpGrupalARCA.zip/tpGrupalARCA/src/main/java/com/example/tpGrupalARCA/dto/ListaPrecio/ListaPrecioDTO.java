package com.example.tpGrupalARCA.dto.ListaPrecio;

import com.example.tpGrupalARCA.entities.ListaPrecio;
import lombok.Builder;

@Builder
public record ListaPrecioDTO(
        Long idListaPrecio,
        String codigo,
        String denominacion
) {
    public static ListaPrecioDTO toDto(ListaPrecio listaPrecio) {
        return ListaPrecioDTO.builder()
                .idListaPrecio(listaPrecio.getId())
                .codigo(listaPrecio.getCodigo())
                .denominacion(listaPrecio.getDenominacion())
                .build();
    }
}

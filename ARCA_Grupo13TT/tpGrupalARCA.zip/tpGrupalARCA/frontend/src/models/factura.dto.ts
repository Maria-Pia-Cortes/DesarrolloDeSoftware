export interface FacturaReporteDTO{
    idFactura: number;
    numeroFactura?: number;
    fechaEmision: string;
    clienteDenominacion: string;
    condicionIva: string;
    puntoVentaDescripcion: string;
    puntoVentaNumero: number;
    importeTotal: number;
    cantidadItems: number;
    cae?: string;
    caeFechaVencimiento?: string;
    estado: string;
    motivoRechazo?: string;
}

export interface FacturaFiltrosDTO{
    fechaDesde? : string;
    fechaHasta? : string;
    numeroComprobante? : number;
    idCliente? : number;
    informada?: boolean
}

export interface FacturaDetalleRequestDTO {
    idArticulo: number;
    descripcion: string;
    cantidad: number
}

export interface FacturaRequestDTO{
    idCliente: number | null;
    idTipoMoneda: number;
    idPuntoVenta: number;
    idCondicionIVA: number;
    idListaPrecio: number;
    observaciones?: string;
    detalles: FacturaDetalleRequestDTO[]
}

export interface FacturaDetalleReporteDTO {
    idArticulo: number,
    nombreArticulo: string,
    descripcion: string,
    cantidad: number,
    precioLista: number
}

export interface FacturaReporteEditDTO {
    idCliente: number | null,
    denominacionCliente: string,
    idTipoMoneda: number,
    idPuntoVenta: number,
    idCondicionIVA: number,
    idListaPrecio: number,
    observaciones: string,
    detalles: FacturaDetalleReporteDTO[]
}

export interface FacturaRequestEditDTO{
    observaciones: string,
    detalles: FacturaDetalleRequestDTO[]
}
package com.example.tpGrupalARCA.dto.FacturaVenta;

import com.example.tpGrupalARCA.entities.FacturaVenta;
import lombok.Builder;


import java.util.Date;

@Builder

public record FacturaReporteDTO(
        Long idFactura,
        Long numeroFactura,
        Date fechaEmision,
        String clienteDenominacion,
        String condicionIva,
        String puntoVentaDescripcion,
        double importeTotal,
        long cantidadItems,
        String cae,
        Date caeFechaVencimiento,
        String estado,
        String motivoRechazo,
        int puntoVentaNumero
) {
    public static FacturaReporteDTO toDto(FacturaVenta facturaVenta){
        String clienteDenominacion = "Consumidor Final";
        if (facturaVenta.getCliente() != null) {
            clienteDenominacion = facturaVenta.getCliente().getDenominacion();
        }

        return FacturaReporteDTO.builder()
                .idFactura(facturaVenta.getId())
                .fechaEmision(facturaVenta.getFechaEmision())
                .clienteDenominacion(clienteDenominacion)
                .condicionIva(facturaVenta.getCondicionIva().getDenominacion())
                .puntoVentaDescripcion(facturaVenta.getPuntoVenta().getDescripcion())
                .importeTotal(facturaVenta.getImporteTotal())
                .cantidadItems(facturaVenta.getDetalles().size())
                .numeroFactura(facturaVenta.getNumero())
                .cae(facturaVenta.getCae())
                .caeFechaVencimiento(facturaVenta.getCaeFechaVencimiento())
                .estado(facturaVenta.getEstado())
                .motivoRechazo(facturaVenta.getMotivoRechazo())
                .puntoVentaNumero(facturaVenta.getPuntoVenta().getNumero())
                .build();
    }
}

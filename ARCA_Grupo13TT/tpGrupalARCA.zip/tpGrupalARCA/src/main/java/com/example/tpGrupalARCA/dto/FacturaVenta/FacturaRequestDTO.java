package com.example.tpGrupalARCA.dto.FacturaVenta;

import com.example.tpGrupalARCA.entities.*;
import java.util.Date;
import java.util.List;

public record FacturaRequestDTO(
        Long idCliente,
        Long idTipoMoneda,
        Long idPuntoVenta,
        Long idCondicionIVA,
        Long idListaPrecio,
        String observaciones,
        List<FacturaDetalleRequestDTO> detalles
) {
    public FacturaVenta toEntity(Cliente cliente, TipoMoneda tipoMoneda, PuntoVenta puntoVenta, CondicionIva condicionIva, ListaPrecio listaPrecio) {
        return FacturaVenta.builder()
                .cliente(cliente)
                .tipoMoneda(tipoMoneda)
                .fechaEmision(new Date())
                .puntoVenta(puntoVenta)
                .listaPrecio(listaPrecio)
                .condicionIva(condicionIva)
                .estado("INGRESADA")
                .observaciones(observaciones)
                .build();
    }
}

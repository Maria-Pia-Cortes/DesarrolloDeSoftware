export interface ListaPrecioDTO {
    idListaPrecio : number,
    codigo : string,
    denominacion : string
}

export interface ListaPrecioArticuloDTO {
    idArticulo : number,
    codigo : string,
    denominacion : string,
    denominacionRubro? : string,
    denominacionMarca? : string,
    precioVenta : number
}
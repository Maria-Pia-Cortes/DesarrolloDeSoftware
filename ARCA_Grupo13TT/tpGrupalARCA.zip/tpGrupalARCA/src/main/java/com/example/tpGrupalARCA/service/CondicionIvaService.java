package com.example.tpGrupalARCA.service;

import com.example.tpGrupalARCA.dto.CondicionIva.CondicionIvaDTO;
import com.example.tpGrupalARCA.entities.CondicionIva;
import com.example.tpGrupalARCA.repository.CondicionIvaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@RequiredArgsConstructor
@Service
public class CondicionIvaService {
    private final CondicionIvaRepository condicionIvaRepository;

    public List<CondicionIvaDTO> findAll(){
        List<CondicionIva> condicionIvas = condicionIvaRepository.findAllByFechaBajaNull();
        return condicionIvas.stream().map(CondicionIvaDTO :: toDTO).toList();
    }
}

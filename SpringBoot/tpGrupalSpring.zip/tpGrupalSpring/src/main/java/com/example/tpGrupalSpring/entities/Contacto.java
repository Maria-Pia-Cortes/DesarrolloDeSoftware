package com.example.tpGrupalSpring.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.*;

@Entity
@Table(name = "ContactoCliente", schema = "modelo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode(callSuper = true, of = {})
@ToString

public class Contacto extends EntityId{
    private String email;
    private String telefono;
    private String celular;
}

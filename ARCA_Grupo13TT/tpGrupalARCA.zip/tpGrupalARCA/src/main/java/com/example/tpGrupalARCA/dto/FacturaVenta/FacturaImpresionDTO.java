package com.example.tpGrupalARCA.dto.FacturaVenta;

import com.example.tpGrupalARCA.entities.Cliente;
import com.example.tpGrupalARCA.entities.Domicilio;
import com.example.tpGrupalARCA.entities.FacturaVenta;

import java.util.Date;
import java.util.List;

/**
 * Datos completos de una factura para generar el PDF impreso
 * (cabecera, receptor, items, impuestos, CAE).
 */
public record FacturaImpresionDTO(
        Long idFactura,
        int puntoVentaNumero,
        Long numeroFactura,
        Date fechaEmision,
        String puntoVentaDescripcion,
        String domicilioComercial,
        String clienteDenominacion,
        String clienteDocumento,
        String clienteDomicilio,
        String condicionIva,
        String monedaDenominacion,
        String monedaSimbolo,
        String observaciones,
        String cae,
        Date caeFechaVencimiento,
        double importeNeto,
        double importeIva,
        double importeTotal,
        List<FacturaImpresionDetalleDTO> detalles
) {
    public static FacturaImpresionDTO toDto(FacturaVenta factura) {
        String denominacion = "Consumidor Final";
        String documento = "";
        String domicilio = "";

        Cliente cliente = factura.getCliente();
        if (cliente != null) {
            denominacion = cliente.getDenominacion();
            documento = cliente.getCuitCuil();
            Domicilio d = cliente.getDomicilio();
            if (d != null) {
                domicilio = (vacioSiNulo(d.getNombreCalle()) + " " + vacioSiNulo(d.getNumeroCalle())).trim();
            }
        }

        List<FacturaImpresionDetalleDTO> detalles = factura.getDetalles().stream()
                .map(FacturaImpresionDetalleDTO::toDto)
                .toList();
        double neto = detalles.stream().mapToDouble(FacturaImpresionDetalleDTO::importeNeto).sum();
        double iva = detalles.stream().mapToDouble(FacturaImpresionDetalleDTO::importeIva).sum();

        return new FacturaImpresionDTO(
                factura.getId(),
                factura.getPuntoVenta().getNumero(),
                factura.getNumero(),
                factura.getFechaEmision(),
                factura.getPuntoVenta().getDescripcion(),
                factura.getPuntoVenta().getDomicilioComercial(),
                denominacion,
                documento,
                domicilio,
                factura.getCondicionIva().getDenominacion(),
                factura.getTipoMoneda().getDenominacion(),
                factura.getTipoMoneda().getSimbolo(),
                factura.getObservaciones(),
                factura.getCae(),
                factura.getCaeFechaVencimiento(),
                neto,
                iva,
                factura.getImporteTotal(),
                detalles);
    }

    private static String vacioSiNulo(String texto) {
        return texto == null ? "" : texto;
    }
}

package com.example.tpGrupalSpring.entities;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "Cliente", schema = "modelo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@EqualsAndHashCode(callSuper = true, of = {"cuitCuil"})
@ToString

public class Cliente extends AuditoriaApp{
    @Column(nullable = false)
    private String cuitCuil;
    @Setter
    @Column(nullable = false)
    private String denominacion;
    @OneToOne
    @JoinColumn(nullable = false)
    private Contacto contacto;
    @OneToOne
    @JoinColumn(nullable = false)
    private Domicilio domicilio;

}

package com.example.tpGrupalARCA.arca;

import java.util.ArrayList;
import java.util.List;

public class RespuestaCae {
    private String resultado;
    private long numero;                 // número de comprobante que ARCA asignó (último + 1)
    private String cae;
    private String caeFechaVencimiento;
    private final List<String> mensajes = new ArrayList<>();

    public boolean isAprobado() { return "A".equalsIgnoreCase(resultado); }

    public String getResultado() { return resultado; }
    public void setResultado(String resultado) { this.resultado = resultado; }
    public long getNumero() { return numero; }
    public void setNumero(long numero) { this.numero = numero; }
    public String getCae() { return cae; }
    public void setCae(String cae) { this.cae = cae; }
    public String getCaeFechaVencimiento() { return caeFechaVencimiento; }
    public void setCaeFechaVencimiento(String caeFechaVencimiento) { this.caeFechaVencimiento = caeFechaVencimiento; }
    public List<String> getMensajes() { return mensajes; }
}

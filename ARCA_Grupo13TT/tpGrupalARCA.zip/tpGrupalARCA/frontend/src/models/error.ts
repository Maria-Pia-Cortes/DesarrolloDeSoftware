export interface ErrorDTO{
    timestamp : string;
    status : number;
    error : string;
    detalles : string[]
}
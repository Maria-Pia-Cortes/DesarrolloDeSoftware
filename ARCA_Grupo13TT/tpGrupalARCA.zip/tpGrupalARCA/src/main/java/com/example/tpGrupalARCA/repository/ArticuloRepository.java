package com.example.tpGrupalARCA.repository;

import com.example.tpGrupalARCA.entities.Articulo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface ArticuloRepository extends JpaRepository<Articulo, Long> {
    Optional<Articulo> findByIdAndFechaBajaNull(Long id);
}

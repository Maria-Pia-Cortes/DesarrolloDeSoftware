// Respuesta del backend
export interface FacturaReporteDTO {
    id: number;
    numeroFactura: number;
    fechaEmision: string;
    clienteDenominacion: string;
    condicionIva: string;
    puntoVentaDescripcion: string;
    importeTotal: number;
    cantidadItems: number;
    estado: string;
}

// Un renglon de la factura que se envia al backend
export interface FacturaDetalleRequestDTO {
    articuloId: number;
    descripcion?: string | null;
    cantidad: number;
    precioUnitario?: number | null;
    porcentajeBonificacion: number;
}

// Factura que se envia al backend en el POST y el PUT
export interface FacturaRequestDTO {
    clienteId?: number | null;
    condicionIvaId: number;
    puntoVentaId: number;
    tipoMonedaId: number;
    fechaEmision?: string | null;
    estado?: string | null;
    observaciones?: string | null;
    detalles: FacturaDetalleRequestDTO[];
}

// Filtros del
export interface FacturaFiltrosDTO {
    fechaDesde?: string;
    fechaHasta?: string;
    estado?: string;
    montoMinimo?: number;
}
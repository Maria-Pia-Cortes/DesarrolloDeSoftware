package com.example.tpGrupalARCA.dto.PuntoVenta;

import com.example.tpGrupalARCA.entities.PuntoVenta;
import lombok.Builder;

@Builder
public record PuntoVentaDTO(
        Long idPuntoVenta,
        String descripcion,
        String domicilioComercial
) {
    public static PuntoVentaDTO toDto(PuntoVenta puntoVenta) {
        return PuntoVentaDTO.builder()
                .idPuntoVenta(puntoVenta.getId())
                .descripcion(puntoVenta.getDescripcion())
                .domicilioComercial(puntoVenta.getDomicilioComercial())
                .build();
    }
}

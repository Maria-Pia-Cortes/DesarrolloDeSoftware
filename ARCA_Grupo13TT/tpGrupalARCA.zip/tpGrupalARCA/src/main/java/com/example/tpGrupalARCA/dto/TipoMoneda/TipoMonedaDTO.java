package com.example.tpGrupalARCA.dto.TipoMoneda;

import com.example.tpGrupalARCA.entities.TipoMoneda;
import lombok.Builder;

@Builder
public record TipoMonedaDTO(
        Long idTipoMoneda,
        String denominacion,
        String simbolo
) {
    public static TipoMonedaDTO toDto(TipoMoneda tipoMoneda) {
        return TipoMonedaDTO.builder()
                .idTipoMoneda(tipoMoneda.getId())
                .denominacion(tipoMoneda.getDenominacion())
                .simbolo(tipoMoneda.getSimbolo())
                .build();
    }
}

package com.example.tpGrupalARCA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpGrupalARCA {
	public static void main(String[] args) {
        SpringApplication.run(TpGrupalARCA.class, args);
    }
}

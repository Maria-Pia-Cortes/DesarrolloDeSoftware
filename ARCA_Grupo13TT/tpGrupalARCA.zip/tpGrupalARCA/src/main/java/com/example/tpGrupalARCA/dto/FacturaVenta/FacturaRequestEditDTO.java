package com.example.tpGrupalARCA.dto.FacturaVenta;

import com.example.tpGrupalARCA.entities.FacturaVenta;

import java.util.List;

    public record FacturaRequestEditDTO(
        String observaciones,
        List<FacturaDetalleRequestDTO> detalles
) {
    public void applyTo(FacturaVenta facturaVenta) {
        facturaVenta.setObservaciones(observaciones);
    }
}
package com.example.tpGrupalSpring.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

// Traduce las excepciones de cualquier controller a una respuesta HTTP
@RestControllerAdvice
public class GlobalExceptionHandler {

    // Un ID (factura, cliente, articulo...) no existe: Error 404
    @ExceptionHandler(RecursoNoEncontradoException.class)
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ErrorResponse manejarNoEncontrado(RecursoNoEncontradoException ex) {
        return new ErrorResponse(404, ex.getMessage());
    }

    // Datos invalidos que detecta el service (sin items, cantidad <= 0, falta un id...): Error 400
    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ErrorResponse manejarArgumentoInvalido(IllegalArgumentException ex) {
        return new ErrorResponse(400, ex.getMessage());
    }

    // Cualquier otro error inesperado: Error 500
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ErrorResponse manejarErrorGeneral(Exception ex) {
        return new ErrorResponse(500, "Se produjo un error interno en el servidor");
    }
}
package com.example.tpGrupalARCA.repository;

import com.example.tpGrupalARCA.entities.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ClienteRepository extends JpaRepository<Cliente, Long> {
    Optional<Cliente> findByIdAndFechaBajaNull(Long id);
    List<Cliente> findAllByFechaBajaNull();
}

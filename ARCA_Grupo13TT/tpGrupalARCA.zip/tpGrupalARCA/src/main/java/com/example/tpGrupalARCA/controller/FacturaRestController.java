package com.example.tpGrupalARCA.controller;

import com.example.tpGrupalARCA.dto.FacturaVenta.FacturaImpresionDTO;
import com.example.tpGrupalARCA.dto.FacturaVenta.FacturaReporteDTO;
import com.example.tpGrupalARCA.dto.FacturaVenta.FacturaReporteEditDTO;
import com.example.tpGrupalARCA.dto.FacturaVenta.FacturaRequestDTO;
import com.example.tpGrupalARCA.dto.FacturaVenta.FacturaRequestEditDTO;
import com.example.tpGrupalARCA.dto.Paginacion.PaginaDTO;
import com.example.tpGrupalARCA.service.FacturaService;
import com.example.tpGrupalARCA.service.ReporteService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/api/facturas")
@RequiredArgsConstructor
public class FacturaRestController {
    private final FacturaService facturaService;
    private final ReporteService reporteService;

    @GetMapping("/{id}")
    public FacturaReporteEditDTO obtenerFacturaAEditar(@PathVariable Long id){
        return facturaService.obtenerFacturaAEditar(id);
    }

    @GetMapping
    public List<FacturaReporteDTO> buscarFacturas(
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date fechaDesde,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date fechaHasta,
            @RequestParam(required = false) String estado,
            @RequestParam(required = false) Double montoMinimo
    ){
        return facturaService.buscarFacturasFiltradas(fechaDesde, fechaHasta, estado, montoMinimo);
    }

    @GetMapping("/paginada")
    public PaginaDTO<FacturaReporteDTO> buscarFacturasPaginadas(
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date fechaDesde,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date fechaHasta,
            @RequestParam(required = false) Long numeroComprobante,
            @RequestParam(required = false) Long idCliente,
            @RequestParam(required = false) Boolean informada,
            @RequestParam(required = false, defaultValue = "0") Integer pagina,
            @RequestParam(required = false, defaultValue = "10") Integer tamanio
    ){
        return facturaService.buscarFacturasPaginadas(fechaDesde, fechaHasta, numeroComprobante, idCliente, informada, pagina, tamanio);
    }

    @GetMapping("/pdf")
    public ResponseEntity<byte[]> descargarPdf(
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date fechaDesde,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date fechaHasta,
            @RequestParam(required = false) String estado,
            @RequestParam(required = false) Double montoMinimo) throws Exception {

        List<FacturaReporteDTO> reporte =
                facturaService.buscarFacturasFiltradas(fechaDesde, fechaHasta, estado, montoMinimo);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=reporte_facturas.pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(reporteService.generarPdf(reporte));
    }

    @GetMapping("/excel")
    public ResponseEntity<byte[]> descargarExcel(
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date fechaDesde,
            @RequestParam(required = false)
            @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) Date fechaHasta,
            @RequestParam(required = false) String estado,
            @RequestParam(required = false) Double montoMinimo) {

        List<FacturaReporteDTO> reporte =
                facturaService.buscarFacturasFiltradas(fechaDesde, fechaHasta, estado, montoMinimo);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=reporte_facturas.txt")
                .contentType(new MediaType("text", "tab-separated-values"))
                .body(reporteService.generarExcel(reporte));
    }

    @GetMapping("/{id}/pdf")
    public ResponseEntity<byte[]> descargarPdfFactura(@PathVariable Long id) throws Exception {
        FacturaImpresionDTO factura = facturaService.buscarFacturaParaImprimir(id);

        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "inline; filename=factura_" + id + ".pdf")
                .contentType(MediaType.APPLICATION_PDF)
                .body(reporteService.generarPdfFactura(factura));
    }

    @PostMapping
    public ResponseEntity<FacturaReporteDTO> crearFactura(@RequestBody FacturaRequestDTO facturaRequestDTO){
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(facturaService.save(facturaRequestDTO));
    }

    @PutMapping("/{id}")
        public ResponseEntity<FacturaReporteDTO> actualizarFactura(@PathVariable Long id, @RequestBody FacturaRequestEditDTO facturaRequestEditDTO){
        return ResponseEntity
                .ok()
                .body(facturaService.update(facturaRequestEditDTO,id));
    }

    @PostMapping("/{id}/autorizar")
    public ResponseEntity<FacturaReporteDTO> autorizarFactura(@PathVariable Long id){
        return ResponseEntity
                .ok()
                .body(facturaService.autorizar(id));
    }

    @PostMapping("/{id}/anular")
    public ResponseEntity<Void> anularFactura(@PathVariable Long id){
        facturaService.anular(id);
        return ResponseEntity
                .noContent()
                .build();
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteFactura(@PathVariable Long id){
        facturaService.delete(id);
        return ResponseEntity
                .noContent()
                .build();
    }
}
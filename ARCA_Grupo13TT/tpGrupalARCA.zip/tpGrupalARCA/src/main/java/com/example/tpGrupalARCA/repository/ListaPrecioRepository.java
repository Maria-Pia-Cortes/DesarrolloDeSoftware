package com.example.tpGrupalARCA.repository;

import com.example.tpGrupalARCA.entities.ListaPrecio;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ListaPrecioRepository extends JpaRepository<ListaPrecio, Long> {
    Optional<ListaPrecio> findByIdAndFechaBajaNull(Long id);
    List<ListaPrecio> findAllByFechaBajaNull();
}

package com.example.tpGrupalSpring.service;

import com.example.tpGrupalSpring.dto.FacturaReporteDTO;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.List;

@Service
public class ReporteService {

    public byte[] generarPdf(List<FacturaReporteDTO> reporte) throws DocumentException {
        ByteArrayOutputStream salida = new ByteArrayOutputStream();
        Document documento = new Document(PageSize.A4.rotate());
        PdfWriter.getInstance(documento, salida);
        documento.open();

        documento.add(new Paragraph("Reporte de Facturas de Venta",
                new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD)));
        documento.add(new Paragraph(" "));

        PdfPTable tabla = new PdfPTable(7);
        tabla.setWidthPercentage(100);

        String[] encabezados = {"Nro", "Fecha", "Cliente", "Condicion IVA",
                "Punto de venta", "Importe total", "Items"};
        for (String h : encabezados) {
            PdfPCell celda = new PdfPCell(new Phrase(h, new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD)));
            celda.setBackgroundColor(BaseColor.LIGHT_GRAY);
            tabla.addCell(celda);
        }

        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        for (FacturaReporteDTO f : reporte) {
            tabla.addCell(String.valueOf(f.numeroFactura()));
            tabla.addCell(formato.format(f.fechaEmision()));
            tabla.addCell(f.clienteDenominacion());
            tabla.addCell(f.condicionIva());
            tabla.addCell(f.puntoVentaDescripcion());
            tabla.addCell(String.format("$ %.2f", f.importeTotal()));
            tabla.addCell(String.valueOf(f.cantidadItems()));
        }

        documento.add(tabla);
        documento.close();
        return salida.toByteArray();
    }

    public byte[] generarExcel(List<FacturaReporteDTO> reporte) {
        SimpleDateFormat formato = new SimpleDateFormat("dd/MM/yyyy");
        StringBuilder sb = new StringBuilder();

        sb.append('\uFEFF'); // marca para que Excel respete las tildes
        sb.append("Nro\tFecha\tCliente\tCondicion IVA\tPunto de venta\tImporte total\tItems\n");

        for (FacturaReporteDTO f : reporte) {
            sb.append(f.numeroFactura()).append('\t')
                    .append(formato.format(f.fechaEmision())).append('\t')
                    .append(f.clienteDenominacion()).append('\t')
                    .append(f.condicionIva()).append('\t')
                    .append(f.puntoVentaDescripcion()).append('\t')
                    .append(String.format("%.2f", f.importeTotal())).append('\t')
                    .append(f.cantidadItems()).append('\n');
        }
        return sb.toString().getBytes(StandardCharsets.UTF_8);
    }
}

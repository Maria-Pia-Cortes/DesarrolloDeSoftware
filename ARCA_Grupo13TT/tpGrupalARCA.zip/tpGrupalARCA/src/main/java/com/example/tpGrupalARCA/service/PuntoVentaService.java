package com.example.tpGrupalARCA.service;

import com.example.tpGrupalARCA.dto.PuntoVenta.PuntoVentaDTO;
import com.example.tpGrupalARCA.entities.PuntoVenta;
import com.example.tpGrupalARCA.repository.PuntoVentaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class PuntoVentaService {
    private final PuntoVentaRepository puntoVentaRepository;

    public List<PuntoVentaDTO> findAll(){
        List<PuntoVenta> puntoVentas = puntoVentaRepository.findAll();
        return puntoVentas.stream().map(PuntoVentaDTO :: toDto).toList();
    }
}

package com.example.tpGrupalARCA.repository;

import com.example.tpGrupalARCA.entities.FacturaVentaDetalle;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface FacturaVentaDetalleRepository extends JpaRepository<FacturaVentaDetalle, Long> {
    Optional<FacturaVentaDetalle> findById(Long id);
    List<FacturaVentaDetalle> findAll();
}

package com.example.tpGrupalARCA.repository;

import com.example.tpGrupalARCA.entities.Articulo;
import com.example.tpGrupalARCA.entities.ListaPrecio;
import com.example.tpGrupalARCA.entities.ListaPrecioArticulo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ListaPrecioArticuloRepository extends JpaRepository<ListaPrecioArticulo, Long>{
    List<ListaPrecioArticulo> findAllByListaPrecioAndFechaBajaNull(ListaPrecio listaPrecio);
    Optional<ListaPrecioArticulo> findByListaPrecioAndArticuloAndFechaBajaNull(ListaPrecio listaPrecio, Articulo articulo);
    Optional<ListaPrecioArticulo> findByIdAndFechaBajaNull(Long id);
}

import type { ErrorDTO } from "../models/error";
import type { FacturaFiltrosDTO, FacturaReporteDTO, FacturaReporteEditDTO, FacturaRequestDTO, FacturaRequestEditDTO } from "../models/factura.dto";
import type { PaginaDTO } from "../models/pagina.dto";

export class FacturaService {
    private readonly baseUrl = "http://localhost:8080/api/facturas";

    async obtenerFacturas(filtros: FacturaFiltrosDTO): Promise<FacturaReporteDTO[]>{
        const params = this.obtenerParametros(filtros);
        const response = await fetch(`${this.baseUrl}?${params.toString()}`);
        await this.verificarRespuesta(response);

        return await response.json();
    }

    async obtenerFacturasPaginadas(filtros: FacturaFiltrosDTO, pagina: number, tamanio: number): Promise<PaginaDTO<FacturaReporteDTO>>{
        const params = this.obtenerParametros(filtros);
        params.append("pagina", pagina.toString());
        params.append("tamanio", tamanio.toString());
        const response = await fetch(`${this.baseUrl}/paginada?${params.toString()}`);
        await this.verificarRespuesta(response);

        return response.json();
    }

    async crearFactura(factura: FacturaRequestDTO): Promise<FacturaReporteDTO> {
        const response = await fetch(this.baseUrl, {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(factura)
        });
        await this.verificarRespuesta(response);

        return await response.json();
    }

    async actualizarFactura(id: number, facturaRequest: FacturaRequestEditDTO): Promise<FacturaReporteDTO> {
        const response = await fetch(`${this.baseUrl}/${id}`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(facturaRequest)
        });
        await this.verificarRespuesta(response);

        return await response.json();
    }

    async autorizarFactura(id: number): Promise<FacturaReporteDTO> {
        const response = await fetch(`${this.baseUrl}/${id}/autorizar`, {
            method: "POST",
        });
        await this.verificarRespuesta(response);

        return await response.json();
    }

    async eliminarFactura(id: number): Promise<void>{
        const response = await fetch(`${this.baseUrl}/${id}`, {
            method: "DELETE",
        });
        await this.verificarRespuesta(response);
    }

    async obtenerFacturaAEditar(id: number): Promise<FacturaReporteEditDTO> {
        const response = await fetch(`${this.baseUrl}/${id}`)
        await this.verificarRespuesta(response);

        return await response.json();
    }

    async anularFactura(id: number): Promise<void>{
        const response = await fetch(`${this.baseUrl}/${id}/anular`, {
            method: "POST",
        });
        await this.verificarRespuesta(response);
    }

    async obtenerPdf(id: number): Promise<Blob> {
        const response = await fetch(`${this.baseUrl}/${id}/pdf`);
        await this.verificarRespuesta(response);
        return await response.blob();
    }

    private async verificarRespuesta(response: Response): Promise<void> {
        if (response.ok) return;

        let mensaje;
        try {
            const error: ErrorDTO = await response.json();
            mensaje = `Error: ${response.status} ` + error.detalles.join(", ");
        } catch {
            mensaje = "Fallo interno del sistema: " + `Error: ${response.status}`;
        }
        throw new Error(mensaje);
    }

    private obtenerParametros(filtros: FacturaFiltrosDTO): URLSearchParams{
        const params = new URLSearchParams();
        if (filtros.fechaDesde) params.append("fechaDesde", filtros.fechaDesde);
        if (filtros.fechaHasta) params.append("fechaHasta",filtros.fechaHasta);
        if (filtros.numeroComprobante) params.append("numeroComprobante", filtros.numeroComprobante.toString());
        if (filtros.idCliente) params.append("idCliente", filtros.idCliente.toString());
        if (filtros.informada !== undefined) params.append("informada", filtros.informada.toString());
        return params
    }
}
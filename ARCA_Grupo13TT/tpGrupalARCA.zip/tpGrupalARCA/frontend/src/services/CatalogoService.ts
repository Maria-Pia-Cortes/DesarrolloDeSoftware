import type { CondicionIvaDTO } from "../models/condicioniva.dto";
import type { ErrorDTO } from "../models/error";
import type { ListaPrecioArticuloDTO, ListaPrecioDTO } from "../models/listaprecio.dto";
import type { PuntoVentaDTO } from "../models/puntoventa.dto";
import type { TipoMonedaDTO } from "../models/tipomoneda.dto";

export class CatalogoService{
    private readonly baseUrl = "http://localhost:8080/api";

    async listarPuntosVenta(): Promise<PuntoVentaDTO[]>{
        const response = await fetch(`${this.baseUrl}/puntos-venta`);
        await this.verificarRespuesta(response);

        return await response.json();
    }

    async listarTiposMoneda(): Promise<TipoMonedaDTO[]>{
        const response = await fetch(`${this.baseUrl}/tipos-moneda`);
        await this.verificarRespuesta(response);
        
        return await response.json();
    }

    async listarCondicionesIVA(): Promise<CondicionIvaDTO[]>{
        const response = await fetch(`${this.baseUrl}/condiciones-iva`);
        await this.verificarRespuesta(response);        
        
        return await response.json();
    }

    async listarListaPrecio(): Promise<ListaPrecioDTO[]>{
        const response = await fetch(`${this.baseUrl}/listas-precio`);
        await this.verificarRespuesta(response);

        return await response.json();
    }

    async listarArticulosPorListaPrecio(idListaPrecio: number, codigo?: string, denominacion?: string): Promise<ListaPrecioArticuloDTO[]>{
        const params = new URLSearchParams();
        params.append("idListaPrecio", idListaPrecio.toString());

        if (codigo !== undefined) {
            params.append("codigo", codigo.toString());
        }
        if (denominacion !== undefined) {
            params.append("denominacion", denominacion);
        }

        const response = await fetch(`${this.baseUrl}/listas-precio-articulo?${params.toString()}`);
        await this.verificarRespuesta(response);

        return response.json();
    }

    private async verificarRespuesta(response: Response): Promise<void> {
        if (response.ok) return;

        let mensaje;
        try {
            const error: ErrorDTO = await response.json();
            mensaje = `Error: ${response.status} ` + error.detalles.join(", ");
        } catch {
            mensaje = "Fallo interno del sistema: " + `Error: ${response.status}`;
        }
        throw new Error(mensaje);
    }
}
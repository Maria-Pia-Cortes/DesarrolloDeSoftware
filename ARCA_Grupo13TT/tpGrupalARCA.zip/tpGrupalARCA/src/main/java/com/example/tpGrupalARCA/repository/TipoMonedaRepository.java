package com.example.tpGrupalARCA.repository;

import com.example.tpGrupalARCA.entities.TipoMoneda;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface TipoMonedaRepository extends JpaRepository<TipoMoneda, Long> {
    Optional<TipoMoneda> findByIdAndFechaBajaNull(Long id);
    List<TipoMoneda> findAllByFechaBajaNull();
}

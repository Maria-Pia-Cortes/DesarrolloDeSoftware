package com.example.tpGrupalARCA.repository;

import com.example.tpGrupalARCA.entities.FacturaVenta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface FacturaVentaRepository extends JpaRepository<FacturaVenta, Long> {
    Optional<FacturaVenta> findByIdAndFechaAnulacionNullAndFechaBajaNull(Long id);
    Optional<FacturaVenta> findByIdAndFechaBajaNull(Long id);

}

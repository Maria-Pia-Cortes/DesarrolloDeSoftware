package com.example.tpGrupalARCA.dto.Paginacion;

import lombok.Builder;

import java.util.List;

@Builder
public record PaginaDTO<T>(
        List<T> contenido,
        int pagina,
        int tamanio,
        Long totalElementos,
        int totalPaginas
        )
{
    public static <T> PaginaDTO<T> paginar(List<T> contenido, int pagina, int tamanio, Long totalElementos){
        int totalPaginas = (int) Math.ceil((double) totalElementos / tamanio);
        return new PaginaDTO<>(contenido, pagina, tamanio, totalElementos, totalPaginas);
    }
}

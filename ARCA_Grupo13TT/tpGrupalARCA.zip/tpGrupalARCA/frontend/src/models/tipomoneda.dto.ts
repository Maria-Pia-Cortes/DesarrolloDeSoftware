export interface TipoMonedaDTO {
    idTipoMoneda : number,
    denominacion : string,
    simbolo : string
}
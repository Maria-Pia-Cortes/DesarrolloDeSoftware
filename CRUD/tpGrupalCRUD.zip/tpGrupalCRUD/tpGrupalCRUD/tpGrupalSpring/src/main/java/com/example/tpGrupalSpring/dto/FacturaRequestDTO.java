package com.example.tpGrupalSpring.dto;

import java.util.Date;
import java.util.List;

public record FacturaRequestDTO(
        Long clienteId,            // opcional: null = Consumidor Final
        Long condicionIvaId,
        Long puntoVentaId,
        Long tipoMonedaId,
        Date fechaEmision,         // opcional: si viene null, el service usa la fecha actual
        String estado,             // opcional en el alta; se usa al actualizar
        String observaciones,
        List<FacturaDetalleRequestDTO> detalles
) {
}
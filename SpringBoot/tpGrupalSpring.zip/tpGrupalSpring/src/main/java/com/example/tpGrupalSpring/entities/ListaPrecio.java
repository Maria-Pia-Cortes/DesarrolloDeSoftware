package com.example.tpGrupalSpring.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.*;

@Entity
@Table(name = "ListaPrecio", schema = "modelo")
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@EqualsAndHashCode(callSuper = true, of = {"codigo"})
@ToString

public class ListaPrecio extends AuditoriaApp{
    @Column(nullable = false)
    private String codigo;
    @Setter
    @Column(nullable = false)
    private String denominacion;
}

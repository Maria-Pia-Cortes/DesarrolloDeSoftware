package com.example.tpGrupalARCA.controller;

import com.example.tpGrupalARCA.dto.Cliente.ClienteDTO;
import com.example.tpGrupalARCA.service.ClienteService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/clientes")
@RequiredArgsConstructor
public class ClienteController {
    private final ClienteService clienteService;

    @GetMapping
    public List<ClienteDTO> findByCuitCuilOrDenominacion(
            @RequestParam(name = "cuitCuil", required = false) String cuitCuil,
            @RequestParam(name = "denominacion", required = false) String denominacion){
        return clienteService.findByCuitCuilOrDenominacion(cuitCuil, denominacion);
    }
}

package org.example.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "ListaPrecio", schema = "modelo")
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter

public class ListaPrecio extends AuditoriaApp{
    @Column(nullable = false)
    private String codigo;
    @Column(nullable = false)
    private String denominacion;
}

export interface PuntoVentaDTO {
    idPuntoVenta : number,
    descripcion : string,
    domicilioComercial : string
}
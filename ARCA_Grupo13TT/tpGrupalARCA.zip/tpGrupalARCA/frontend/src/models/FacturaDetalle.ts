import type { FacturaDetalleReporteDTO, FacturaDetalleRequestDTO } from "./factura.dto";

export class FacturaDetalle {
    public readonly idArticulo: number;
    public readonly nombreArticulo: string;
    public readonly precio: number;
    public descripcion: string;
    private cantidad: number;

    constructor(idArticulo: number, nombreArticulo: string, precio: number, descripcion: string, cantidad?: number){
        const c = cantidad ?? 1;
        if (!Number.isInteger(c) || c < 1) throw new Error("Las cantidades solo deben ser enteros positivos");
        this.idArticulo = idArticulo;
        this.nombreArticulo = nombreArticulo;
        this.precio = precio;
        this.descripcion = descripcion;
        this.cantidad = cantidad ?? 1;
    }

    get subtotal(){
        return this.precio * this.cantidad;
    }

    get getCantidad(){
        return this.cantidad;   
    }

    set setCantidad(cantidad: number){
        if (cantidad < 1 || !Number.isInteger(cantidad)) throw new Error("Error no se puede poner una cantidad negativa o nula");
        this.cantidad = cantidad;
    }

    incrementar(cantidad: number){
        if (cantidad<=0 || !Number.isInteger(cantidad)) throw new Error("Error al actualizar la cantidad del detalle de la factura");
        this.cantidad += cantidad;
    }

    toRequestDTO(): FacturaDetalleRequestDTO{
        const detalle: FacturaDetalleRequestDTO = {
            idArticulo: this.idArticulo,
            descripcion: this.descripcion,
            cantidad: this.cantidad,
        }
        return detalle;
    }

    static desdeDTO(dto: FacturaDetalleReporteDTO): FacturaDetalle {
        return new FacturaDetalle(dto.idArticulo, dto.nombreArticulo, dto.precioLista, dto.descripcion ?? "", dto.cantidad);
    }

}
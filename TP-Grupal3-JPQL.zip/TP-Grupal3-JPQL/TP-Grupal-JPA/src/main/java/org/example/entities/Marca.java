package org.example.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Marca", schema = "modelo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter

public class Marca extends AuditoriaApp{
    @Column(nullable = false)
    private Integer codigo;
    @Column(nullable = false)
    private String denominacion;

    @Override
    public String toString() {
        return "Marca = " + "codigo: " + codigo + " , denominacion: " + denominacion;
    }
}

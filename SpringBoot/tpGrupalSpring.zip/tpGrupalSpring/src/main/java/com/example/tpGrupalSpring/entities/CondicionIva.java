package com.example.tpGrupalSpring.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.*;

@Entity
@Table(name = "CondicionIva", schema = "modelo")
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@EqualsAndHashCode(callSuper = true)
@ToString

public class CondicionIva extends AuditoriaApp {
    @Column(nullable = false)
    private int codigoAfip;
    @Column(nullable = false)
    private String denominacion;
}

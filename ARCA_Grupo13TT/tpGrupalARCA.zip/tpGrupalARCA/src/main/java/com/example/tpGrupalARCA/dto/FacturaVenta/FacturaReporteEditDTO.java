package com.example.tpGrupalARCA.dto.FacturaVenta;

import com.example.tpGrupalARCA.entities.FacturaVenta;
import lombok.Builder;

import java.util.List;

@Builder
public record FacturaReporteEditDTO(
        Long idCliente,
        String denominacionCliente,
        Long idTipoMoneda,
        Long idPuntoVenta,
        Long idCondicionIVA,
        Long idListaPrecio,
        String observaciones,
        List<FacturaDetalleReporteDTO> detalles
) {
    public static FacturaReporteEditDTO toDto(FacturaVenta facturaVenta) {
        return FacturaReporteEditDTO.builder()
                .idCliente(facturaVenta.getCliente() != null ? facturaVenta.getCliente().getId() : null)
                .denominacionCliente(facturaVenta.getCliente() != null ? facturaVenta.getCliente().getDenominacion() : "Consumidor Final")
                .idTipoMoneda(facturaVenta.getTipoMoneda().getId())
                .idPuntoVenta(facturaVenta.getPuntoVenta().getId())
                .idCondicionIVA(facturaVenta.getCondicionIva().getId())
                .idListaPrecio(facturaVenta.getListaPrecio().getId())
                .observaciones(facturaVenta.getObservaciones())
                .detalles(facturaVenta.getDetalles().stream()
                        .map(FacturaDetalleReporteDTO::toDto)
                        .toList())
                .build();
    }
}

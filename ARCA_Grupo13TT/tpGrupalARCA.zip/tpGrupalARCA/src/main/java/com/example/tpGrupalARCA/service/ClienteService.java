package com.example.tpGrupalARCA.service;

import com.example.tpGrupalARCA.dto.Cliente.ClienteDTO;
import com.example.tpGrupalARCA.repository.ClienteRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class ClienteService {

    @PersistenceContext
    private EntityManager em;

    public List<ClienteDTO> findByCuitCuilOrDenominacion(String cuitCuil, String denominacion){
        String cuit = cuitCuil == null ? "" : cuitCuil.trim().replace("-","");
        String razon = denominacion == null ? "" : denominacion.trim();

        StringBuilder jpqlclientes =  new StringBuilder(
                "SELECT new com.example.tpGrupalARCA.dto.Cliente.ClienteDTO(" +
                        "c.id, c.cuitCuil, c.denominacion " +
                        ")" +
                        "FROM Cliente c " +
                        "WHERE c.fechaBaja IS NULL"
        );

        Map<String, Object> parametros = new HashMap<>();

        if (!cuit.trim().isEmpty()) {
            jpqlclientes.append(" AND c.cuitCuil LIKE CONCAT(:cuitCuil, '%')");
            parametros.put("cuitCuil", cuit);
        }
        if (!razon.trim().isEmpty()) {
            jpqlclientes.append(" AND LOWER(c.denominacion) LIKE LOWER(CONCAT('%',:razon,'%'))");
            parametros.put("razon", razon);
        }

        jpqlclientes.append(" ORDER BY c.denominacion ASC, c.id ASC");

        TypedQuery<ClienteDTO> clientes = em.createQuery(jpqlclientes.toString(), ClienteDTO.class);
        clientes.setMaxResults(20);
        parametros.forEach(clientes::setParameter);

        return clientes.getResultList();
    }
}

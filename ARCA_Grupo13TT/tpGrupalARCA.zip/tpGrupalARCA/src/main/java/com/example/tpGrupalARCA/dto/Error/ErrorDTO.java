package com.example.tpGrupalARCA.dto.Error;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

public record ErrorDTO(
        LocalDateTime timestamp,
        Integer status,
        String error,
        List<String> detalles
) {
    public static ErrorDTO of(int status, String error, List<String> detalles) {
        return new ErrorDTO(LocalDateTime.now(), status, error, detalles);
    }

    public static ErrorDTO simple(int status, String error, String detalle) {
        return new ErrorDTO(LocalDateTime.now(), status, error, List.of(Objects.requireNonNullElse(detalle, "Sin observaciones del Error")));
    }
}

package com.example.tpGrupalARCA.service;

import com.example.tpGrupalARCA.dto.ListaPrecio.ListaPrecioDTO;
import com.example.tpGrupalARCA.entities.ListaPrecio;
import com.example.tpGrupalARCA.repository.ListaPrecioRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@RequiredArgsConstructor
@Service
public class ListaPrecioService {
    private final ListaPrecioRepository listaPrecio;

    public List<ListaPrecioDTO> findAll(){
        List<ListaPrecio> listaPrecios = listaPrecio.findAllByFechaBajaNull();
        return listaPrecios.stream().map(ListaPrecioDTO :: toDto).toList();
    }
}

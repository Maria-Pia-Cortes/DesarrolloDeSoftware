package com.example.tpGrupalARCA.arca;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import javax.xml.parsers.DocumentBuilderFactory;
import java.io.StringReader;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

@Service
public class ArcaService {

    private static final String NS = "http://ar.gov.afip.dif.FEV1/";

    @Value("${arca.cuit}")
    private long cuit;

    @Value("${arca.key-path}")
    private String keyPath;

    @Value("${arca.cert-path}")
    private String certPath;

    @Value("${arca.produccion:false}")
    private boolean produccion;

    @Value("${arca.cbte-tipo:11}")
    private int cbteTipo;

    public RespuestaCae autorizar(int ptoVta, int condicionIvaReceptor,
                                  String documentoCliente, double importeTotal) throws Exception {
        if (cbteTipo != 11) {
            throw new IllegalStateException("Solo está implementada la Factura C (arca.cbte-tipo=11)");
        }

        String[] auth = AfipWsaaClient.obtenerTokenYSign(keyPath, certPath, "wsfe", produccion, String.valueOf(cuit));
        String token = auth[0];
        String sign = auth[1];

        // Último comprobante autorizado -> el nuevo es el siguiente
        long nuevoNumero = ultimoComprobante(token, sign, ptoVta) + 1;

        // Pedir el CAE
        return solicitarCae(token, sign, ptoVta, nuevoNumero, condicionIvaReceptor, documentoCliente, importeTotal);
    }

    private long ultimoComprobante(String token, String sign, int ptoVta) throws Exception {
        String soap = envelope(
                "<ar:FECompUltimoAutorizado>" +
                        auth(token, sign) +
                        "<ar:PtoVta>" + ptoVta + "</ar:PtoVta>" +
                        "<ar:CbteTipo>" + cbteTipo + "</ar:CbteTipo>" +
                        "</ar:FECompUltimoAutorizado>");

        String respuesta = AfipHttpUtil.enviarSoap(AfipHttpUtil.getURLWsfe(produccion), soap, NS + "FECompUltimoAutorizado");
        Document doc = parsear(respuesta);
        lanzarSiHayFault(doc);

        String numero = texto(doc, "CbteNro");
        if (numero == null) {
            throw new RuntimeException("ARCA no devolvió el último comprobante: " + mensajesDeError(doc));
        }
        return Long.parseLong(numero);
    }

    private RespuestaCae solicitarCae(String token, String sign, int ptoVta, long numero,
                                      int condicionIvaReceptor, String documentoCliente,
                                      double importeTotal) throws Exception {

        int docTipo = 99;
        long docNro = 0;
        String digitos = documentoCliente == null ? "" : documentoCliente.replaceAll("\\D", "");
        if (digitos.length() == 11) {
            docTipo = 80;
            docNro = Long.parseLong(digitos);
        } else if (digitos.length() == 7 || digitos.length() == 8) {
            docTipo = 96;
            docNro = Long.parseLong(digitos);
        }

        String fecha = LocalDate.now(ZoneId.of("America/Argentina/Buenos_Aires"))
                .format(DateTimeFormatter.ofPattern("yyyyMMdd"));
        String total = String.format(Locale.US, "%.2f", importeTotal);

        String detalle =
                "<ar:FECAEDetRequest>" +
                        "<ar:Concepto>1</ar:Concepto>" +                       // 1 = Productos
                        "<ar:DocTipo>" + docTipo + "</ar:DocTipo>" +
                        "<ar:DocNro>" + docNro + "</ar:DocNro>" +
                        "<ar:CbteDesde>" + numero + "</ar:CbteDesde>" +
                        "<ar:CbteHasta>" + numero + "</ar:CbteHasta>" +
                        "<ar:CbteFch>" + fecha + "</ar:CbteFch>" +
                        "<ar:ImpTotal>" + total + "</ar:ImpTotal>" +
                        "<ar:ImpTotConc>0.00</ar:ImpTotConc>" +
                        "<ar:ImpNeto>" + total + "</ar:ImpNeto>" +
                        "<ar:ImpOpEx>0.00</ar:ImpOpEx>" +
                        "<ar:ImpTrib>0.00</ar:ImpTrib>" +
                        "<ar:ImpIVA>0.00</ar:ImpIVA>" +
                        "<ar:MonId>PES</ar:MonId>" +                           // pesos
                        "<ar:MonCotiz>1</ar:MonCotiz>" +
                        "<ar:CondicionIVAReceptorId>" + condicionIvaReceptor + "</ar:CondicionIVAReceptorId>" +
                        "</ar:FECAEDetRequest>";

        String soap = envelope(
                "<ar:FECAESolicitar>" +
                        auth(token, sign) +
                        "<ar:FeCAEReq>" +
                        "<ar:FeCabReq>" +
                        "<ar:CantReg>1</ar:CantReg>" +
                        "<ar:PtoVta>" + ptoVta + "</ar:PtoVta>" +
                        "<ar:CbteTipo>" + cbteTipo + "</ar:CbteTipo>" +
                        "</ar:FeCabReq>" +
                        "<ar:FeDetReq>" + detalle + "</ar:FeDetReq>" +
                        "</ar:FeCAEReq>" +
                        "</ar:FECAESolicitar>");

        String respuesta = AfipHttpUtil.enviarSoap(AfipHttpUtil.getURLWsfe(produccion), soap, NS + "FECAESolicitar");
        return interpretarRespuestaCae(respuesta, numero);
    }

    static RespuestaCae interpretarRespuestaCae(String xml, long numero) throws Exception {
        Document doc = parsear(xml);
        lanzarSiHayFault(doc);

        RespuestaCae r = new RespuestaCae();
        r.setNumero(numero);
        r.setResultado(texto(doc, "Resultado"));   // el primero que aparece es el de la cabecera
        r.setCae(texto(doc, "CAE"));
        r.setCaeFechaVencimiento(texto(doc, "CAEFchVto"));

        agregarMensajes(doc, "Obs", "Observación", r);
        agregarMensajes(doc, "Err", "Error", r);

        if (r.getResultado() == null) {
            throw new RuntimeException(r.getMensajes().isEmpty()
                    ? "Respuesta inesperada de ARCA: " + xml
                    : "ARCA devolvió: " + String.join(" | ", r.getMensajes()));
        }
        return r;
    }

    private static void agregarMensajes(Document doc, String tag, String etiqueta, RespuestaCae r) {
        NodeList nodos = doc.getElementsByTagNameNS("*", tag);
        for (int i = 0; i < nodos.getLength(); i++) {
            Element e = (Element) nodos.item(i);
            r.getMensajes().add(etiqueta + " " + textoHijo(e, "Code") + ": " + textoHijo(e, "Msg"));
        }
    }

    private static String envelope(String cuerpo) {
        return "<?xml version=\"1.0\" encoding=\"utf-8\"?>" +
                "<soap:Envelope xmlns:soap=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ar=\"" + NS + "\">" +
                "<soap:Body>" + cuerpo + "</soap:Body></soap:Envelope>";
    }

    private String auth(String token, String sign) {
        return "<ar:Auth><ar:Token>" + token + "</ar:Token><ar:Sign>" + sign + "</ar:Sign><ar:Cuit>" + cuit + "</ar:Cuit></ar:Auth>";
    }

    private static Document parsear(String xml) throws Exception {
        DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
        f.setNamespaceAware(true);
        f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true); // seguridad: sin DTD
        return f.newDocumentBuilder().parse(new InputSource(new StringReader(xml)));
    }

    /** Texto del primer elemento con ese nombre (sin importar el prefijo de namespace), o null si no está. */
    private static String texto(Document doc, String nombre) {
        NodeList l = doc.getElementsByTagNameNS("*", nombre);
        return l.getLength() == 0 ? null : l.item(0).getTextContent();
    }

    private static String textoHijo(Element padre, String nombre) {
        NodeList l = padre.getElementsByTagNameNS("*", nombre);
        return l.getLength() == 0 ? "" : l.item(0).getTextContent();
    }

    private static void lanzarSiHayFault(Document doc) {
        String fault = texto(doc, "faultstring");
        if (fault != null) {
            throw new RuntimeException("ARCA devolvió un SOAP Fault: " + fault);
        }
    }

    private static String mensajesDeError(Document doc) {
        StringBuilder sb = new StringBuilder();
        NodeList errs = doc.getElementsByTagNameNS("*", "Err");
        for (int i = 0; i < errs.getLength(); i++) {
            Element e = (Element) errs.item(i);
            sb.append(textoHijo(e, "Code")).append(": ").append(textoHijo(e, "Msg")).append(" ");
        }
        return sb.length() == 0 ? "(sin detalle)" : sb.toString().trim();
    }
}

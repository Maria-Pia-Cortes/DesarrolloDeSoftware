package org.example.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Cliente", schema = "modelo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter

public class Cliente extends AuditoriaApp{
    @Column(nullable = false)
    private String cuitCuil;
    @Column(nullable = false)
    private String denominacion;
    @OneToOne
    @JoinColumn(nullable = false)
    private Contacto contacto;
    @OneToOne
    @JoinColumn(nullable = false)
    private Domicilio domicilio;

    @Override
    public String toString() {
        return "Cliente = " + "cuitCuil = " + cuitCuil + ", denominacion = " + denominacion + ", contacto = " + contacto + ", domicilio = " + domicilio;
    }
}

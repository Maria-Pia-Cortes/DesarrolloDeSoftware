package com.example.tpGrupalARCA.dto.CondicionIva;

import com.example.tpGrupalARCA.entities.CondicionIva;
import lombok.Builder;

@Builder
public record CondicionIvaDTO(
        Long idCondicionIva,
        int codigoAfip,
        String denominacion
) {
    public static CondicionIvaDTO toDTO(CondicionIva condicionIva) {
        return CondicionIvaDTO.builder()
                .idCondicionIva(condicionIva.getId())
                .codigoAfip(condicionIva.getCodigoAfip())
                .denominacion(condicionIva.getDenominacion())
                .build();
    }
}

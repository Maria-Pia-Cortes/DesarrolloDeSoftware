package com.example.tpGrupalARCA.config;

import com.example.tpGrupalARCA.entities.*;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;

@Component
public class CargaDatosInicial implements CommandLineRunner {

    @PersistenceContext
    private EntityManager em;

    @Override
    @Transactional
    public void run(String... args){

        Long cantidad = em.createQuery("SELECT COUNT(c) FROM CondicionIva c", Long.class).getSingleResult();
        if (cantidad > 0) {
            return;
        }

        Usuario usuario = Usuario.builder()
                .usuario("admin")
                .clave("1234")
                .nombre("Juan")
                .apellido("Perez")
                .build();
        em.persist(usuario);
        
        Date ahora = new Date();
        
        Rubro rubroInf = Rubro.builder()
                .codigo(100)
                .denominacion("Informatica")
                .build();
        auditar(rubroInf, usuario, ahora);
        em.persist(rubroInf);

        Rubro rubroElec = Rubro.builder()
                .codigo(101)
                .denominacion("Electronica")
                .build();
        auditar(rubroElec, usuario, ahora);
        em.persist(rubroElec);

        Marca marcaLog = Marca.builder()
                .codigo(10)
                .denominacion("Logitech")
                .build();
        auditar(marcaLog, usuario, ahora);
        em.persist(marcaLog);

        Marca marcaVaio = Marca.builder()
                .codigo(11)
                .denominacion("VAIO")
                .build();
        auditar(marcaVaio, usuario, ahora);
        em.persist(marcaVaio);

        Marca marcaLiliana = Marca.builder()
                .codigo(12)
                .denominacion("Liliana")
                .build();
        auditar(marcaLiliana, usuario, ahora);
        em.persist(marcaLiliana);

        ListaPrecio listaPrecio1 = ListaPrecio.builder()
                .codigo("L1")
                .denominacion("Lista de precios mayorista")
                .build();

        auditar(listaPrecio1, usuario, ahora);
        em.persist(listaPrecio1);

        ListaPrecio listaPrecio2 = ListaPrecio.builder()
                .codigo("L2")
                .denominacion("Lista de precios minorista")
                .build();

        auditar(listaPrecio2, usuario, ahora);
        em.persist(listaPrecio2);

        Articulo articulo1 = Articulo.builder()
                .codigo("ART-001")
                .denominacion("Teclado inalambrico")
                .rubro(rubroInf)
                .marca(marcaLog)
                .build();
        auditar(articulo1, usuario, ahora);
        em.persist(articulo1);

        Articulo articulo2 = Articulo.builder()
                .codigo("ART-002")
                .denominacion("Mouse optico")
                .rubro(rubroInf)
                .marca(marcaLog)
                .build();
        auditar(articulo2, usuario, ahora);
        em.persist(articulo2);

        Articulo articulo3 = Articulo.builder()
                .codigo("ART-003")
                .denominacion("Monitor LED 24 pulgadas")
                .rubro(rubroInf)
                .marca(marcaLog)
                .build();
        auditar(articulo3, usuario, ahora);
        em.persist(articulo3);

        Articulo articulo4 = Articulo.builder()
                .codigo("ART-004")
                .denominacion("Laptop VAIO 2016")
                .rubro(rubroInf)
                .marca(marcaVaio)
                .build();
        auditar(articulo4, usuario, ahora);
        em.persist(articulo4);

        Articulo articulo5 = Articulo.builder()
                .codigo("ART-005")
                .denominacion("Laptop VAIO 2018")
                .rubro(rubroInf)
                .marca(marcaVaio)
                .build();
        auditar(articulo5, usuario, ahora);
        em.persist(articulo5);

        Articulo articulo6 = Articulo.builder()
                .codigo("ART-006")
                .denominacion("Mousepad LG 35cm x 75cm")
                .rubro(rubroInf)
                .marca(marcaLog)
                .build();
        auditar(articulo6, usuario, ahora);
        em.persist(articulo6);

        Articulo articulo7 = Articulo.builder()
                .codigo("ART-007")
                .denominacion("Silla gamer LG ultra comoda")
                .rubro(rubroInf)
                .marca(marcaLog)
                .build();
        auditar(articulo7, usuario, ahora);
        em.persist(articulo7);

        Articulo articulo8 = Articulo.builder()
                .codigo("ART-008")
                .denominacion("Ventilador liliana de pie, 4 velocidades")
                .rubro(rubroElec)
                .marca(marcaLiliana)
                .build();
        auditar(articulo8, usuario, ahora);
        em.persist(articulo8);

        Articulo articulo9 = Articulo.builder()
                .codigo("ART-009")
                .denominacion("Ventilador liliana de pie, 5 velocidades!!")
                .rubro(rubroElec)
                .marca(marcaLiliana)
                .build();
        auditar(articulo9, usuario, ahora);
        em.persist(articulo9);

        Articulo articulo10 = Articulo.builder()
                .codigo("ART-0010")
                .denominacion("Aire Acondicionado liliana")
                .rubro(rubroElec)
                .marca(marcaLiliana)
                .build();
        auditar(articulo10, usuario, ahora);
        em.persist(articulo10);

        ListaPrecioArticulo listaPrecioArticulo1 = ListaPrecioArticulo.builder()
                        .listaPrecio(listaPrecio1)
                        .articulo(articulo1)
                        .precioVenta(50000.00)
                        .build();
        auditar(listaPrecioArticulo1, usuario, ahora);
        em.persist(listaPrecioArticulo1);

        ListaPrecioArticulo listaPrecioArticulo2 = ListaPrecioArticulo.builder()
                        .listaPrecio(listaPrecio2)
                        .articulo(articulo1)
                        .precioVenta(65000.00)
                        .build();
        auditar(listaPrecioArticulo2, usuario, ahora);
        em.persist(listaPrecioArticulo2);

        ListaPrecioArticulo listaPrecioArticulo3 = ListaPrecioArticulo.builder()
                .listaPrecio(listaPrecio1)
                .articulo(articulo2)
                .precioVenta(25000.00)
                .build();
        auditar(listaPrecioArticulo3, usuario, ahora);
        em.persist(listaPrecioArticulo3);

        ListaPrecioArticulo listaPrecioArticulo4 = ListaPrecioArticulo.builder()
                .listaPrecio(listaPrecio2)
                .articulo(articulo2)
                .precioVenta(30000.00)
                .build();
        auditar(listaPrecioArticulo4, usuario, ahora);
        em.persist(listaPrecioArticulo4);

        ListaPrecioArticulo listaPrecioArticulo5 = ListaPrecioArticulo.builder()
                .listaPrecio(listaPrecio1)
                .articulo(articulo3)
                .precioVenta(100000.00)
                .build();
        auditar(listaPrecioArticulo5, usuario, ahora);
        em.persist(listaPrecioArticulo5);

        ListaPrecioArticulo listaPrecioArticulo6 = ListaPrecioArticulo.builder()
                .listaPrecio(listaPrecio2)
                .articulo(articulo3)
                .precioVenta(135000.00)
                .build();
        auditar(listaPrecioArticulo6, usuario, ahora);
        em.persist(listaPrecioArticulo6);

        ListaPrecioArticulo listaPrecioArticulo7 = ListaPrecioArticulo.builder()
                .listaPrecio(listaPrecio1)
                .articulo(articulo4)
                .precioVenta(750000.00)
                .build();
        auditar(listaPrecioArticulo7, usuario, ahora);
        em.persist(listaPrecioArticulo7);

        ListaPrecioArticulo listaPrecioArticulo8 = ListaPrecioArticulo.builder()
                .listaPrecio(listaPrecio2)
                .articulo(articulo4)
                .precioVenta(1000000.00)
                .build();
        auditar(listaPrecioArticulo8, usuario, ahora);
        em.persist(listaPrecioArticulo8);

        ListaPrecioArticulo listaPrecioArticulo9 = ListaPrecioArticulo.builder()
                .listaPrecio(listaPrecio1)
                .articulo(articulo5)
                .precioVenta(750000.00)
                .build();
        auditar(listaPrecioArticulo9, usuario, ahora);
        em.persist(listaPrecioArticulo9);

        ListaPrecioArticulo listaPrecioArticulo10 = ListaPrecioArticulo.builder()
                .listaPrecio(listaPrecio2)
                .articulo(articulo5)
                .precioVenta(1200000.00)
                .build();
        auditar(listaPrecioArticulo10, usuario, ahora);
        em.persist(listaPrecioArticulo10);

        ListaPrecioArticulo listaPrecioArticulo11 = ListaPrecioArticulo.builder()
                .listaPrecio(listaPrecio1)
                .articulo(articulo6)
                .precioVenta(15000.00)
                .build();
        auditar(listaPrecioArticulo11, usuario, ahora);
        em.persist(listaPrecioArticulo11);


        ListaPrecioArticulo listaPrecioArticulo12 = ListaPrecioArticulo.builder()
                .listaPrecio(listaPrecio2)
                .articulo(articulo6)
                .precioVenta(20000.00)
                .build();
        auditar(listaPrecioArticulo12, usuario, ahora);
        em.persist(listaPrecioArticulo12);

        ListaPrecioArticulo listaPrecioArticulo13 = ListaPrecioArticulo.builder()
                .listaPrecio(listaPrecio1)
                .articulo(articulo7)
                .precioVenta(600000.00)
                .build();
        auditar(listaPrecioArticulo13, usuario, ahora);
        em.persist(listaPrecioArticulo13);

        ListaPrecioArticulo listaPrecioArticulo14 = ListaPrecioArticulo.builder()
                .listaPrecio(listaPrecio2)
                .articulo(articulo7)
                .precioVenta(750000.00)
                .build();
        auditar(listaPrecioArticulo14, usuario, ahora);
        em.persist(listaPrecioArticulo14);

        ListaPrecioArticulo listaPrecioArticulo15 = ListaPrecioArticulo.builder()
                .listaPrecio(listaPrecio1)
                .articulo(articulo8)
                .precioVenta(230000.00)
                .build();
        auditar(listaPrecioArticulo15, usuario, ahora);
        em.persist(listaPrecioArticulo15);

        ListaPrecioArticulo listaPrecioArticulo16 = ListaPrecioArticulo.builder()
                .listaPrecio(listaPrecio2)
                .articulo(articulo8)
                .precioVenta(300000.00)
                .build();
        auditar(listaPrecioArticulo16, usuario, ahora);
        em.persist(listaPrecioArticulo16);


        ListaPrecioArticulo listaPrecioArticulo17 = ListaPrecioArticulo.builder()
                .listaPrecio(listaPrecio1)
                .articulo(articulo9)
                .precioVenta(280000.00)
                .build();
        auditar(listaPrecioArticulo17, usuario, ahora);
        em.persist(listaPrecioArticulo17);

        ListaPrecioArticulo listaPrecioArticulo18 = ListaPrecioArticulo.builder()
                .listaPrecio(listaPrecio2)
                .articulo(articulo9)
                .precioVenta(325000.00)
                .build();
        auditar(listaPrecioArticulo18, usuario, ahora);
        em.persist(listaPrecioArticulo18);

        ListaPrecioArticulo listaPrecioArticulo19 = ListaPrecioArticulo.builder()
                .listaPrecio(listaPrecio1)
                .articulo(articulo10)
                .precioVenta(500000.00)
                .build();
        auditar(listaPrecioArticulo19, usuario, ahora);
        em.persist(listaPrecioArticulo19);


        ListaPrecioArticulo listaPrecioArticulo20 = ListaPrecioArticulo.builder()
                .listaPrecio(listaPrecio2)
                .articulo(articulo10)
                .precioVenta(630000.00)
                .build();
        auditar(listaPrecioArticulo20, usuario, ahora);
        em.persist(listaPrecioArticulo20);


        PuntoVenta puntoVenta1 = PuntoVenta.builder()
                .numero(1)
                .descripcion("Sucursal Principal")
                .tipoEmision("ELECTRONICA")
                .domicilioComercial("Av. Siempre Viva 123")
                .build();
        auditar(puntoVenta1, usuario, ahora);
        em.persist(puntoVenta1);

        PuntoVenta puntoVenta2 = PuntoVenta.builder()
                .numero(2)
                .descripcion("Sucursal Norte")
                .tipoEmision("ELECTRONICA")
                .domicilioComercial("Bv. Roca 456")
                .build();
        auditar(puntoVenta2, usuario, ahora);
        em.persist(puntoVenta2);

        PuntoVenta puntoVenta3 = PuntoVenta.builder()
                .numero(3)
                .descripcion("Sucursal Secundaria")
                .tipoEmision("ELECTRONICA")
                .domicilioComercial("Napoles 1115")
                .build();
        auditar(puntoVenta3, usuario, ahora);
        em.persist(puntoVenta3);

        TipoMoneda tipoMoneda1 =
                TipoMoneda.builder()
                        .codigoAfip("5050")
                        .denominacion("Peso Argentino")
                        .simbolo("PES")
                        .build();

        auditar(tipoMoneda1, usuario, ahora);
        em.persist(tipoMoneda1);

        Contacto contacto1 =
                Contacto.builder()
                        .email("cosodelacosa@gmail.com")
                        .telefono("+54 9 2617878980")
                        .celular("4937349")
                        .build();
        em.persist(contacto1);


        Domicilio domicilio1 =
                Domicilio.builder()
                        .nombreCalle("San Martin")
                        .numeroCalle("5510")
                        .build();
        em.persist(domicilio1);

        Contacto contacto2 =
                Contacto.builder()
                        .email("mimosas333@gmail.com")
                        .telefono("+54 9 26112312310")
                        .celular("67676767")
                        .build();
        em.persist(contacto2);


        Domicilio domicilio2 =
                Domicilio.builder()
                        .nombreCalle("Capillares")
                        .numeroCalle("4578")
                        .build();
        em.persist(domicilio2);

        Contacto contacto3 =
                Contacto.builder()
                        .email("riquitoriquito@gmail.com")
                        .telefono("+54 9 2614545312")
                        .celular("4937349")
                        .build();
        em.persist(contacto3);


        Domicilio domicilio3 =
                Domicilio.builder()
                        .nombreCalle("Guyana Francesa")
                        .numeroCalle("4141")
                        .build();
        em.persist(domicilio3);

        Contacto contacto4 =
                Contacto.builder()
                        .email("kotlinaVSPyE5@gmail.com")
                        .telefono("+54 9 2615462312")
                        .celular("5645346")
                        .build();
        em.persist(contacto4);


        Domicilio domicilio4 =
                Domicilio.builder()
                        .nombreCalle("Chabuco")
                        .numeroCalle("7878")
                        .build();
        em.persist(domicilio4);


        Cliente cliente1 =
                Cliente.builder()
                        .cuitCuil("20111111112")
                        .denominacion("Cintia Clarez")
                        .contacto(contacto1)
                        .domicilio(domicilio1)
                        .build();
        auditar(cliente1, usuario, ahora);
        em.persist(cliente1);

        Cliente cliente2 =
                Cliente.builder()
                        .cuitCuil("123456")
                        .denominacion("Caminantes Paulinos SA")
                        .contacto(contacto2)
                        .domicilio(domicilio2)
                        .build();
        auditar(cliente2, usuario, ahora);
        em.persist(cliente2);

        Cliente cliente3 =
                Cliente.builder()
                        .cuitCuil("132123")
                        .denominacion("Un Cafecito & Co")
                        .contacto(contacto3)
                        .domicilio(domicilio3)
                        .build();
        auditar(cliente3, usuario, ahora);
        em.persist(cliente3);

        Cliente cliente4 =
                Cliente.builder()
                        .cuitCuil("541345")
                        .denominacion("Apolo")
                        .contacto(contacto4)
                        .domicilio(domicilio4)
                        .build();
        auditar(cliente4, usuario, ahora);
        em.persist(cliente4);


        CondicionIva condicionIva = CondicionIva.builder()
                .codigoAfip(1)
                .denominacion("Responsable Inscripto")
                .build();

        auditar(condicionIva, usuario, ahora);
        em.persist(condicionIva);

        CondicionIva condicionIva2 = CondicionIva.builder()
                .codigoAfip(5)
                .denominacion("Consumidor Final")
                .build();
        auditar(condicionIva2, usuario, ahora);
        em.persist(condicionIva2);

        CondicionIva condicionIva3 = CondicionIva.builder()
                .codigoAfip(6)
                .denominacion("Monotributista")
                .build();
        auditar(condicionIva3, usuario, ahora);
        em.persist(condicionIva3);
    }

    private static void auditar(
            AuditoriaApp entidad,
            Usuario usuario,
            Date fecha) {

        entidad.setFechaAlta(fecha);
        entidad.setFechaModificacion(fecha);
        entidad.setUsuarioCarga(usuario);
        entidad.setUsuarioModificacion(usuario);
    }
}

package com.example.tpGrupalARCA.controller;

import com.example.tpGrupalARCA.dto.ListaPrecio.ListaPrecioArticuloDTO;
import com.example.tpGrupalARCA.service.ListaPrecioArticuloService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/listas-precio-articulo")
@RequiredArgsConstructor
public class ListaPrecioArticuloController {
    private final ListaPrecioArticuloService listaPrecioService;

    @GetMapping
    public List<ListaPrecioArticuloDTO> buscarListaPrecioArticulo(
            @RequestParam(name = "idListaPrecio") Long idListaPrecio,
            @RequestParam(name = "codigo", required = false) String codigo,
            @RequestParam(name = "denominacion", required = false) String denominacion
    ){
        return listaPrecioService.findAll(idListaPrecio, codigo, denominacion);
    }
}

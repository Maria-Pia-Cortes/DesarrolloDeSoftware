package com.example.tpGrupalSpring.dto;

import com.example.tpGrupalSpring.entities.FacturaVenta;
import lombok.Builder;


import java.util.Date;

@Builder

public record FacturaReporteDTO(
        Long numeroFactura,
        Date fechaEmision,
        String clienteDenominacion,
        String condicionIva,
        String puntoVentaDescripcion,
        double importeTotal,
        long cantidadItems
) {
    public static FacturaReporteDTO toDto(FacturaVenta facturaVenta){
        return FacturaReporteDTO.builder()
                .numeroFactura(facturaVenta.getNumero())
                .fechaEmision(facturaVenta.getFechaEmision())
                .clienteDenominacion(facturaVenta.getCliente().getDenominacion())
                .condicionIva(facturaVenta.getCondicionIva().getDenominacion())
                .puntoVentaDescripcion(facturaVenta.getPuntoVenta().getDescripcion())
                .importeTotal(facturaVenta.getImporteTotal())
                .cantidadItems(facturaVenta.getDetalles().size())
                .build();
    }
}

package com.example.tpGrupalARCA.service;

import com.example.tpGrupalARCA.dto.FacturaVenta.FacturaImpresionDTO;
import com.example.tpGrupalARCA.dto.FacturaVenta.FacturaImpresionDetalleDTO;
import com.example.tpGrupalARCA.dto.FacturaVenta.FacturaReporteDTO;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

@Service
public class ReporteService {

    public byte[] generarPdf(List<FacturaReporteDTO> reportes) throws DocumentException {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        Document document = new Document(PageSize.A4.rotate());
        PdfWriter.getInstance(document, stream);
        document.open();

        document.add(new Paragraph("Reporte de facturas",
                new Font(Font.FontFamily.TIMES_ROMAN, 16, Font.BOLD)));
        document.add(new Paragraph(" "));
        PdfPTable table = new PdfPTable(7);
        table.setWidthPercentage(100);
        String[] titulos = {"Numero", "Fecha Emision", "Cliente", "Condicion IVA", "Punto Venta", "Importe Total", "Items"};

        Font fuenteTitulo = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD);

        for (String titulo : titulos) {
            PdfPCell celda = new PdfPCell(new Phrase(titulo, fuenteTitulo));
            celda.setBackgroundColor(BaseColor.LIGHT_GRAY);
            celda.setHorizontalAlignment(Element.ALIGN_CENTER);
            table.addCell(celda);
        }

        Font fuenteCeldas = new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL);
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");

        for (FacturaReporteDTO reporte : reportes) {
            table.addCell(new PdfPCell(new Phrase(String.valueOf(reporte.numeroFactura()), fuenteCeldas)));
            table.addCell(new PdfPCell(new Phrase(simpleDateFormat.format(reporte.fechaEmision()), fuenteCeldas)));
            table.addCell(new PdfPCell(new Phrase(reporte.clienteDenominacion(), fuenteCeldas)));
            table.addCell(new PdfPCell(new Phrase(reporte.condicionIva(), fuenteCeldas)));
            table.addCell(new PdfPCell(new Phrase(reporte.puntoVentaDescripcion(), fuenteCeldas)));
            table.addCell(new PdfPCell(new Phrase(String.format(Locale.forLanguageTag("es-AR"), "%.2f", reporte.importeTotal()), fuenteCeldas)));
            table.addCell(new PdfPCell(new Phrase(String.valueOf(reporte.cantidadItems()), fuenteCeldas)));
        }
        document.add(table);

        document.close();
        return stream.toByteArray();
    }

    public byte[] generarExcel(List<FacturaReporteDTO> reportes) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append('\uFEFF');
        stringBuilder.append("\t\t\tReporte de facturas\n");
        stringBuilder.append("Numero\tFecha Emision\tCliente\tCondicion IVA\tPunto Venta\tImporte Total\tItems");
        stringBuilder.append("\n");

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");

        for (FacturaReporteDTO  reporte : reportes) {
            stringBuilder.append(reporte.numeroFactura());
            stringBuilder.append("\t");
            stringBuilder.append(simpleDateFormat.format(reporte.fechaEmision()));
            stringBuilder.append("\t");
            stringBuilder.append(reporte.clienteDenominacion());
            stringBuilder.append("\t");
            stringBuilder.append(reporte.condicionIva());
            stringBuilder.append("\t");
            stringBuilder.append(reporte.puntoVentaDescripcion());
            stringBuilder.append("\t");
            stringBuilder.append(String.format(Locale.forLanguageTag("es-AR"), "%.2f", reporte.importeTotal()));
            stringBuilder.append("\t");
            stringBuilder.append(reporte.cantidadItems());
            stringBuilder.append("\n");
        }

        return stringBuilder.toString().getBytes(StandardCharsets.UTF_8);
    }

    // ------------------------------------------------------------------
    // Factura impresa (formato comercial tipo Factura A/B/C)
    // ------------------------------------------------------------------

    private static final Locale LOCALE_AR = Locale.forLanguageTag("es-AR");
    private static final int MIN_FILAS_ITEMS = 15;

    private static final BaseColor COLOR_BORDE = new BaseColor(60, 60, 60);
    private static final BaseColor COLOR_LINEA = new BaseColor(170, 170, 170);
    private static final BaseColor COLOR_ENCABEZADO = new BaseColor(228, 222, 210);
    private static final BaseColor COLOR_TOTAL = new BaseColor(45, 45, 45);

    private static final Font F_EMISOR = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD);
    private static final Font F_LETRA = new Font(Font.FontFamily.HELVETICA, 30, Font.BOLD);
    private static final Font F_TITULO = new Font(Font.FontFamily.HELVETICA, 18, Font.BOLD);
    private static final Font F_NUMERO = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD);
    private static final Font F_ETIQUETA = new Font(Font.FontFamily.HELVETICA, 9, Font.BOLD);
    private static final Font F_TEXTO = new Font(Font.FontFamily.HELVETICA, 9, Font.NORMAL);
    private static final Font F_ITEM = new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL);
    private static final Font F_CHICA = new Font(Font.FontFamily.HELVETICA, 7, Font.NORMAL);
    private static final Font F_TOTAL = new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD, BaseColor.WHITE);
    private static final Font F_TOTAL_ETIQUETA = new Font(Font.FontFamily.HELVETICA, 9, Font.BOLD, BaseColor.WHITE);

    // Datos del emisor: el CUIT y el tipo de comprobante salen de la config de ARCA;
    // el resto es opcional (si no se define, se usan valores por defecto).
    @Value("${arca.cuit:}")
    private String cuitEmisor;
    @Value("${arca.cbte-tipo:11}")
    private int tipoComprobante;
    @Value("${factura.emisor.razon-social:}")
    private String emisorRazonSocial;
    @Value("${factura.emisor.condicion-iva:}")
    private String emisorCondicionIva;
    @Value("${factura.emisor.ingresos-brutos:}")
    private String emisorIngresosBrutos;
    @Value("${factura.emisor.inicio-actividades:}")
    private String emisorInicioActividades;

    /** Genera el PDF de una factura autorizada: cabecera, receptor, items, totales y CAE. */
    public byte[] generarPdfFactura(FacturaImpresionDTO factura) throws DocumentException {
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        Document document = new Document(PageSize.A4, 28, 28, 28, 28);
        PdfWriter.getInstance(document, stream);
        document.addTitle("Factura " + numeroFormateado(factura));
        document.open();

        document.add(armarCabecera(factura));
        document.add(armarReceptor(factura));
        document.add(armarTablaItems(factura));
        if (factura.observaciones() != null && !factura.observaciones().isBlank()) {
            document.add(armarObservaciones(factura.observaciones()));
        }
        document.add(armarTotales(factura));
        document.add(armarPieCae(factura));

        document.close();
        return stream.toByteArray();
    }

    /** Encabezado: datos del negocio | letra y codigo | tipo, numero, fecha y CUIT. */
    private PdfPTable armarCabecera(FacturaImpresionDTO factura) {
        PdfPTable tabla = new PdfPTable(new float[]{42f, 16f, 42f});
        tabla.setWidthPercentage(100);
        tabla.setSplitLate(false); // permite partir filas entre paginas: evita "Infinite table loop"

        String nombre = emisorRazonSocial.isBlank() ? factura.puntoVentaDescripcion() : emisorRazonSocial;
        String condicion = emisorCondicionIva.isBlank() ? condicionIvaEmisorPorDefecto() : emisorCondicionIva;

        PdfPCell celdaEmisor = new PdfPCell();
        celdaEmisor.setPadding(10f);
        celdaEmisor.setBorderColor(COLOR_BORDE);
        celdaEmisor.addElement(new Paragraph(nombre, F_EMISOR));
        celdaEmisor.addElement(new Paragraph(" ", F_CHICA));
        celdaEmisor.addElement(new Paragraph(etiquetaValor("Domicilio comercial:", factura.domicilioComercial())));
        celdaEmisor.addElement(new Paragraph(etiquetaValor("Condicion frente al IVA:", condicion)));
        tabla.addCell(celdaEmisor);

        PdfPCell celdaLetra = new PdfPCell();
        celdaLetra.setPadding(6f);
        celdaLetra.setBorderColor(COLOR_BORDE);
        Paragraph letra = new Paragraph(letraComprobante(), F_LETRA);
        letra.setAlignment(Element.ALIGN_CENTER);
        Paragraph codigo = new Paragraph("COD. " + codigoComprobante(), F_CHICA);
        codigo.setAlignment(Element.ALIGN_CENTER);
        celdaLetra.addElement(letra);
        celdaLetra.addElement(codigo);
        tabla.addCell(celdaLetra);

        SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
        PdfPCell celdaDatos = new PdfPCell();
        celdaDatos.setPadding(10f);
        celdaDatos.setBorderColor(COLOR_BORDE);
        celdaDatos.addElement(new Paragraph("FACTURA", F_TITULO));
        celdaDatos.addElement(new Paragraph("N\u00ba " + numeroFormateado(factura), F_NUMERO));
        celdaDatos.addElement(new Paragraph(" ", F_CHICA));
        celdaDatos.addElement(new Paragraph(etiquetaValor("Fecha de emision:", formatoFecha.format(factura.fechaEmision()))));
        celdaDatos.addElement(new Paragraph(etiquetaValor("C.U.I.T.:", cuitFormateado())));
        if (!emisorIngresosBrutos.isBlank()) {
            celdaDatos.addElement(new Paragraph(etiquetaValor("Ingresos Brutos:", emisorIngresosBrutos)));
        }
        if (!emisorInicioActividades.isBlank()) {
            celdaDatos.addElement(new Paragraph(etiquetaValor("Inicio de actividades:", emisorInicioActividades)));
        }
        tabla.addCell(celdaDatos);
        return tabla;
    }

    /** Datos del cliente (receptor). */
    private PdfPTable armarReceptor(FacturaImpresionDTO factura) {
        PdfPTable tabla = new PdfPTable(new float[]{55f, 45f});
        tabla.setWidthPercentage(100);
        tabla.setSplitLate(false); // permite partir filas entre paginas: evita "Infinite table loop"

        String documento = factura.clienteDocumento() == null || factura.clienteDocumento().isBlank()
                ? "-" : factura.clienteDocumento();
        String domicilio = factura.clienteDomicilio() == null || factura.clienteDomicilio().isBlank()
                ? "-" : factura.clienteDomicilio();

        PdfPCell razonSocial = celdaTexto(etiquetaValor("Apellido y Nombre / Razon Social:", factura.clienteDenominacion()));
        razonSocial.setColspan(2);
        tabla.addCell(razonSocial);
        tabla.addCell(celdaTexto(etiquetaValor("CUIT / DNI:", documento)));
        tabla.addCell(celdaTexto(etiquetaValor("Condicion frente al IVA:", factura.condicionIva())));
        tabla.addCell(celdaTexto(etiquetaValor("Domicilio:", domicilio)));
        tabla.addCell(celdaTexto(etiquetaValor("Moneda:", factura.monedaDenominacion() + " (" + factura.monedaSimbolo() + ")")));
        return tabla;
    }

    /** Grilla de items: Cantidad | Descripcion | Precio Unitario | Subtotal. */
    private PdfPTable armarTablaItems(FacturaImpresionDTO factura) {
        PdfPTable tabla = new PdfPTable(new float[]{10f, 52f, 19f, 19f});
        tabla.setWidthPercentage(100);
        tabla.setSplitLate(false); // permite partir filas entre paginas: evita "Infinite table loop"
        tabla.setSpacingBefore(6f);
        tabla.setHeaderRows(1);

        String[] titulos = {"CANT.", "DESCRIPCION", "P. UNITARIO", "SUBTOTAL"};
        for (String titulo : titulos) {
            PdfPCell encabezado = new PdfPCell(new Phrase(titulo, F_ETIQUETA));
            encabezado.setBackgroundColor(COLOR_ENCABEZADO);
            encabezado.setHorizontalAlignment(Element.ALIGN_CENTER);
            encabezado.setPadding(5f);
            encabezado.setBorderColor(COLOR_BORDE);
            tabla.addCell(encabezado);
        }

        for (FacturaImpresionDetalleDTO detalle : factura.detalles()) {
            tabla.addCell(celdaItem(String.valueOf(detalle.cantidad()), Element.ALIGN_CENTER));
            tabla.addCell(celdaItem(detalle.descripcion(), Element.ALIGN_LEFT));
            tabla.addCell(celdaItem(importe(detalle.precioUnitario()), Element.ALIGN_RIGHT));
            tabla.addCell(celdaItem(importe(detalle.importeNeto()), Element.ALIGN_RIGHT));
        }

        // Filas vacias para que la factura conserve el aspecto de formulario
        for (int i = factura.detalles().size(); i < MIN_FILAS_ITEMS; i++) {
            for (int columna = 0; columna < 4; columna++) {
                tabla.addCell(celdaItem("", Element.ALIGN_LEFT));
            }
        }
        return tabla;
    }

    private PdfPTable armarObservaciones(String observaciones) {
        PdfPTable tabla = new PdfPTable(1);
        tabla.setWidthPercentage(100);
        tabla.setSplitLate(false); // permite partir filas entre paginas: evita "Infinite table loop"
        tabla.setSpacingBefore(6f);
        tabla.addCell(celdaTexto(etiquetaValor("Observaciones:", observaciones)));
        return tabla;
    }

    /** Pie con el calculo de impuestos y el total final destacado. */
    private PdfPTable armarTotales(FacturaImpresionDTO factura) {
        boolean discriminaIva = factura.importeIva() > 0.005;
        PdfPTable tabla = discriminaIva
                ? new PdfPTable(new float[]{1f, 1f, 1.3f})
                : new PdfPTable(new float[]{1f, 1.3f});
        tabla.setWidthPercentage(100);
        tabla.setSplitLate(false); // permite partir filas entre paginas: evita "Infinite table loop"
        tabla.setSpacingBefore(6f);

        String simbolo = factura.monedaSimbolo() == null ? "$" : factura.monedaSimbolo();

        tabla.addCell(celdaTitulo("SUBTOTAL (NETO)", COLOR_ENCABEZADO, F_ETIQUETA));
        if (discriminaIva) {
            tabla.addCell(celdaTitulo("IVA " + porcentajeIva(factura) + " %", COLOR_ENCABEZADO, F_ETIQUETA));
        }
        tabla.addCell(celdaTitulo("TOTAL " + simbolo, COLOR_TOTAL, F_TOTAL_ETIQUETA));

        PdfPCell neto = celdaTexto(new Phrase(importe(factura.importeNeto()), F_NUMERO));
        neto.setHorizontalAlignment(Element.ALIGN_RIGHT);
        tabla.addCell(neto);
        if (discriminaIva) {
            PdfPCell iva = celdaTexto(new Phrase(importe(factura.importeIva()), F_NUMERO));
            iva.setHorizontalAlignment(Element.ALIGN_RIGHT);
            tabla.addCell(iva);
        }
        PdfPCell total = new PdfPCell(new Phrase(simbolo + " " + importe(factura.importeTotal()), F_TOTAL));
        total.setBackgroundColor(COLOR_TOTAL);
        total.setHorizontalAlignment(Element.ALIGN_RIGHT);
        total.setPadding(7f);
        total.setBorderColor(COLOR_BORDE);
        tabla.addCell(total);
        return tabla;
    }

    /** Pie legal: datos de autorizacion de ARCA (CAE y vencimiento). */
    private PdfPTable armarPieCae(FacturaImpresionDTO factura) {
        PdfPTable tabla = new PdfPTable(1);
        tabla.setWidthPercentage(100);
        tabla.setSplitLate(false); // permite partir filas entre paginas: evita "Infinite table loop"
        tabla.setSpacingBefore(8f);

        String vencimiento = factura.caeFechaVencimiento() == null
                ? "-" : new SimpleDateFormat("dd/MM/yyyy").format(factura.caeFechaVencimiento());

        PdfPCell celda = new PdfPCell();
        celda.setPadding(8f);
        celda.setBorderColor(COLOR_BORDE);
        celda.addElement(new Paragraph("Comprobante Autorizado", F_NUMERO));
        celda.addElement(new Paragraph(etiquetaValor("CAE N\u00ba:", factura.cae())));
        celda.addElement(new Paragraph(etiquetaValor("Fecha de Vto. de CAE:", vencimiento)));
        tabla.addCell(celda);
        return tabla;
    }

    // ---------------------------- helpers ----------------------------

    /** Numero con formato punto de venta - comprobante: 0001-00000012. */
    private String numeroFormateado(FacturaImpresionDTO factura) {
        long numero = factura.numeroFactura() == null ? 0L : factura.numeroFactura();
        return String.format("%04d-%08d", factura.puntoVentaNumero(), numero);
    }

    /** Letra segun el codigo de comprobante ARCA: 1-5 = A, 6-10 = B, 11 en adelante = C. */
    private String letraComprobante() {
        if (tipoComprobante < 6) return "A";
        if (tipoComprobante < 11) return "B";
        return "C";
    }

    private String codigoComprobante() {
        return String.format("%03d", tipoComprobante);
    }

    private String condicionIvaEmisorPorDefecto() {
        return tipoComprobante < 11 ? "IVA Responsable Inscripto" : "Responsable Monotributo";
    }

    private String soloDigitos(String texto) {
        return texto == null ? "" : texto.replaceAll("\\D", "");
    }

    private String cuitFormateado() {
        String cuit = soloDigitos(cuitEmisor);
        if (cuit.length() != 11) return cuitEmisor;
        return cuit.substring(0, 2) + "-" + cuit.substring(2, 10) + "-" + cuit.substring(10);
    }

    private String importe(double valor) {
        return String.format(LOCALE_AR, "%,.2f", valor);
    }

    /** Porcentaje de IVA aplicado, deducido de los importes (ej: 21 o 10,5). */
    private String porcentajeIva(FacturaImpresionDTO factura) {
        if (factura.importeNeto() <= 0) return "0";
        double porcentaje = Math.round(factura.importeIva() / factura.importeNeto() * 1000.0) / 10.0;
        return porcentaje == Math.rint(porcentaje)
                ? String.valueOf((long) porcentaje)
                : String.format(LOCALE_AR, "%.1f", porcentaje);
    }

    private Phrase etiquetaValor(String etiqueta, String valor) {
        Phrase frase = new Phrase();
        frase.add(new Chunk(etiqueta + " ", F_ETIQUETA));
        frase.add(new Chunk(valor == null ? "" : valor, F_TEXTO));
        return frase;
    }

    private PdfPCell celdaTexto(Phrase frase) {
        PdfPCell celda = new PdfPCell(frase);
        celda.setPadding(5f);
        celda.setBorderColor(COLOR_BORDE);
        return celda;
    }

    private PdfPCell celdaTitulo(String texto, BaseColor fondo, Font fuente) {
        PdfPCell celda = new PdfPCell(new Phrase(texto, fuente));
        celda.setBackgroundColor(fondo);
        celda.setHorizontalAlignment(Element.ALIGN_CENTER);
        celda.setPadding(4f);
        celda.setBorderColor(COLOR_BORDE);
        return celda;
    }

    private PdfPCell celdaItem(String texto, int alineacion) {
        PdfPCell celda = new PdfPCell(new Phrase(texto == null ? "" : texto, F_ITEM));
        celda.setHorizontalAlignment(alineacion);
        celda.setVerticalAlignment(Element.ALIGN_MIDDLE);
        celda.setBorder(Rectangle.LEFT | Rectangle.RIGHT | Rectangle.BOTTOM);
        celda.setBorderColor(COLOR_LINEA);
        celda.setBorderWidth(0.4f);
        celda.setPadding(4f);
        celda.setMinimumHeight(22f);
        return celda;
    }
}

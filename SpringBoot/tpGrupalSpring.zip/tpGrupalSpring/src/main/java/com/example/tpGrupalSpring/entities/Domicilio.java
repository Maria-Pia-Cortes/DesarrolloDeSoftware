package com.example.tpGrupalSpring.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.*;

@Entity
@Table(name = "DomicilioCliente", schema = "modelo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter
@EqualsAndHashCode(callSuper = true, of = {})
@ToString

public class Domicilio extends EntityId{
    private String nombreCalle;
    private String numeroCalle;
}

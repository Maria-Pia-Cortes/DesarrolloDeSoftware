package org.example;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import org.example.entities.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        EntityManagerFactory emf =  Persistence.createEntityManagerFactory("FacturacionPU");
        EntityManager em = emf.createEntityManager();

        try {

            em.getTransaction().begin();

            Usuario usuario = Usuario.builder()
                    .usuario("admin")
                    .clave("1234")
                    .nombre("Juan")
                    .apellido("Perez")
                    .build();

            em.persist(usuario);


            // Fecha que utilizaremos para la auditoria
            Date ahora = new Date();

            Rubro rubro = Rubro.builder()
                    .codigo(100)
                    .denominacion("Informatica")
                    .build();

            auditar(rubro, usuario, ahora);

            em.persist(rubro);

            Marca marca = Marca.builder()
                    .codigo(10)
                    .denominacion("Logitech")
                    .build();

            auditar(marca, usuario, ahora);

            em.persist(marca);

            Articulo articulo1 = Articulo.builder()
                    .codigo("ART-001")
                    .denominacion("Teclado inalambrico")
                    .rubro(rubro)
                    .marca(marca)
                    .build();

            auditar(articulo1, usuario, ahora);

            em.persist(articulo1);

            Articulo articulo2 = Articulo.builder()
                    .codigo("ART-002")
                    .denominacion("Mouse optico")
                    .rubro(rubro)
                    .marca(marca)
                    .build();

            auditar(articulo2, usuario, ahora);

            em.persist(articulo2);

            ListaPrecio listaPrecio = ListaPrecio.builder()
                    .codigo("L1")
                    .denominacion("Lista de precios general")
                    .build();

            auditar(listaPrecio, usuario, ahora);

            em.persist(listaPrecio);



            ListaPrecioArticulo listaPrecioArticulo1 =
                    ListaPrecioArticulo.builder()
                            .listaPrecio(listaPrecio)
                            .articulo(articulo1)
                            .precioVenta(25000.00)
                            .build();

            auditar(listaPrecioArticulo1, usuario, ahora);

            em.persist(listaPrecioArticulo1);


            ListaPrecioArticulo listaPrecioArticulo2 =
                    ListaPrecioArticulo.builder()
                            .listaPrecio(listaPrecio)
                            .articulo(articulo2)
                            .precioVenta(12000.00)
                            .build();

            auditar(listaPrecioArticulo2, usuario, ahora);

            em.persist(listaPrecioArticulo2);


            PuntoVenta puntoVenta = PuntoVenta.builder()
                    .numero(1)
                    .descripcion("Punto de venta principal")
                    .tipoEmision("ELECTRONICA")
                    .domicilioComercial("Av. Siempre Viva 123")
                    .build();

            auditar(puntoVenta, usuario, ahora);

            em.persist(puntoVenta);

            double cantidad1 = 2;

            double importeNeto1 =
                    cantidad1 * listaPrecioArticulo1.getPrecioVenta();

            double importeIva1 =
                    importeNeto1 * 0.21;

            double importeSubtotal1 =
                    importeNeto1 + importeIva1;

            TipoMoneda tipoMoneda1 =
                    TipoMoneda.builder()
                            .codigoAfip("5050")
                            .denominacion("Verdura")
                            .simbolo("$")
                            .build();

            auditar(tipoMoneda1, usuario, ahora);
            em.persist(tipoMoneda1);

            Contacto contacto1 =
                    Contacto.builder()
                            .email("cosodelacosa@gmail.com")
                            .telefono("+54 9 2617878980")
                            .celular("4937349")
                            .build();
            em.persist(contacto1);


            Domicilio domicilio1 =
                    Domicilio.builder()
                            .nombreCalle("San Martin")
                            .numeroCalle("5510")
                            .build();
            em.persist(domicilio1);


            Cliente cliente1 =
                    Cliente.builder()
                            .cuitCuil("303030")
                            .denominacion("Cintia Clarez")
                            .contacto(contacto1)
                            .domicilio(domicilio1)
                            .build();

            auditar(cliente1,usuario,ahora);
            em.persist(cliente1);


            FacturaVentaDetalle detalle1 =
                    FacturaVentaDetalle.builder()
                            .listaPrecioArticulo(listaPrecioArticulo1)
                            .descripcion(articulo1.getDenominacion())
                            .cantidad(cantidad1)
                            .precioUnitario(listaPrecioArticulo1.getPrecioVenta())
                            .porcentajeBonificacion(0)
                            .importeNeto(importeNeto1)
                            .importeIva(importeIva1)
                            .importeSubtotal(importeSubtotal1)
                            .build();

            double cantidad2 = 1;

            double importeNeto2 =
                    cantidad2 * listaPrecioArticulo2.getPrecioVenta();

            double importeIva2 =
                    importeNeto2 * 0.21;

            double importeSubtotal2 =
                    importeNeto2 + importeIva2;

            FacturaVentaDetalle detalle2 =
                    FacturaVentaDetalle.builder()
                            .listaPrecioArticulo(listaPrecioArticulo2)
                            .descripcion(articulo2.getDenominacion())
                            .cantidad(cantidad2)
                            .precioUnitario(listaPrecioArticulo2.getPrecioVenta())
                            .porcentajeBonificacion(0)
                            .importeNeto(importeNeto2)
                            .importeIva(importeIva2)
                            .importeSubtotal(importeSubtotal2)
                            .build();


            double importeTotal =
                    importeSubtotal1 + importeSubtotal2;

            FacturaVenta facturaVenta =
                    FacturaVenta.builder()
                            .cliente(cliente1)
                            .tipoMoneda(tipoMoneda1)
                            .numero(1L)
                            .fechaEmision(ahora)
                            .puntoVenta(puntoVenta)
                            .importeCobrado(importeTotal)
                            .importeSaldo(0)
                            .importeTotal(importeTotal)
                            .estado("EMITIDA")
                            .observaciones("Venta de prueba")
                            .detalles(new ArrayList<>())
                            .build();

            auditar(facturaVenta, usuario, ahora);

            detalle1.setFacturaVenta(facturaVenta);
            detalle2.setFacturaVenta(facturaVenta);

            facturaVenta.getDetalles().add(detalle1);
            facturaVenta.getDetalles().add(detalle2);

            em.persist(facturaVenta);


            // ==== Datos adicionales de prueba ====

            // Articulo sin marca y que nunca se factura
            Articulo articulo3 = Articulo.builder()
                    .codigo("ART-003")
                    .denominacion("Monitor LED 24 pulgadas")
                    .rubro(rubro)
                    .build();

            auditar(articulo3, usuario, ahora);
            em.persist(articulo3);

            // Segundo punto de venta
            PuntoVenta puntoVenta2 = PuntoVenta.builder()
                    .numero(2)
                    .descripcion("Sucursal Norte")
                    .tipoEmision("ELECTRONICA")
                    .domicilioComercial("Bv. Roca 456")
                    .build();

            auditar(puntoVenta2, usuario, ahora);
            em.persist(puntoVenta2);

            // Facturas extra con importes variados, puntos de venta, datos para filtrar y no devuelvan siempre listas vacias
            double[] importesExtra = {5000, 8000, 15000, 32000, 60000, 45000};

            for (int i = 0; i < importesExtra.length; i++) {
                double importeNetoExtra = importesExtra[i];
                double importeIvaExtra = importeNetoExtra * 0.21;
                double importeSubtotalExtra = importeNetoExtra + importeIvaExtra;

                FacturaVentaDetalle detalleExtra =
                        FacturaVentaDetalle.builder()
                                .listaPrecioArticulo(listaPrecioArticulo1)
                                .descripcion(articulo1.getDenominacion())
                                .cantidad(1)
                                .precioUnitario(importeNetoExtra)
                                .porcentajeBonificacion(0)
                                .importeNeto(importeNetoExtra)
                                .importeIva(importeIvaExtra)
                                .importeSubtotal(importeSubtotalExtra)
                                .build();

                FacturaVenta facturaExtra =
                        FacturaVenta.builder()
                                .cliente(cliente1)
                                .tipoMoneda(tipoMoneda1)
                                .numero(2L + i)
                                .fechaEmision(ahora)
                                .puntoVenta(i % 2 == 0 ? puntoVenta : puntoVenta2)
                                .importeCobrado(importeSubtotalExtra)
                                .importeSaldo(0)
                                .importeTotal(importeSubtotalExtra)
                                .estado("EMITIDA")
                                .observaciones("Venta de prueba " + (i + 2))
                                .detalles(new ArrayList<>())
                                .build();

                auditar(facturaExtra, usuario, ahora);

                detalleExtra.setFacturaVenta(facturaExtra);
                facturaExtra.getDetalles().add(detalleExtra);

                em.persist(facturaExtra);
            }

            em.getTransaction().commit();

        } catch (Exception e) {

            if (em.getTransaction().isActive()) {
                System.out.println("HUBO UN ERROR");
                em.getTransaction().rollback();
            }

            em.close();
            emf.close();

            throw e;

        }

        // Nivel 1

        // ==== Consulta 1 ====
        System.out.println("\n=== Consulta 1: todas las facturas ===");
        List<FacturaVenta> listafacturas = em.createQuery(
                        "SELECT f FROM FacturaVenta f", FacturaVenta.class
                )
                .getResultList();
        listafacturas.forEach(System.out::println);

        // ==== Consulta 2 ====
        System.out.println("\n=== Consulta 2: todas las facturas (nro, fecha e importe) ===");
        List<Object[]> listafacturas2 = em.createQuery(
                        "SELECT f.numero,f.fechaEmision, f.importeTotal FROM FacturaVenta f", Object[].class
                )
                .getResultList();
        listafacturas2.forEach(fila -> System.out.println(Arrays.toString(fila)));

        // ==== Consulta 3 ====
        System.out.println("\n=== Consulta 3: articulos de un rubro especifico ===");
        List<Articulo> listaarticulosrubro = em.createQuery(
                        "SELECT a FROM Articulo a WHERE a.rubro.denominacion = :rubro", Articulo.class
                )
                .setParameter("rubro","Informatica")
                .getResultList();
        listaarticulosrubro.forEach(System.out::println);

        // ==== Consulta 4 ====
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date fechaInferior;
        Date fechaSuperior;
        try {
            fechaInferior = sdf.parse("2026-08-10");
            fechaSuperior = sdf.parse("2026-09-30");
        } catch (ParseException e) {
            throw new RuntimeException(e);
        }

        System.out.println("\n=== Consulta 4: facturas 10/08/2026 hasta 30/09/2026 ===");
        List<FacturaVenta> listaFacturaRangoFecha = em.createQuery(
                        "SELECT f FROM FacturaVenta f WHERE f.fechaEmision BETWEEN :fechaInferior AND :fechaSuperior", FacturaVenta.class
                )
                .setParameter("fechaInferior",fechaInferior)
                .setParameter("fechaSuperior", fechaSuperior)
                .getResultList();
        listaFacturaRangoFecha.forEach(System.out::println);

        // Nivel 2

        // ==== Consulta 5 ====
        System.out.println("\n=== Consulta 5: facturas con estado = Emitida, importe superior a $10000 y no anuladas ===");
        List<FacturaVenta> listaFacturaEmitidas = em.createQuery(
                        "SELECT f FROM FacturaVenta f WHERE f.estado = :estado AND f.importeTotal > :importe AND f.fechaAnulacion IS NULL", FacturaVenta.class
                )
                .setParameter("estado","EMITIDA")
                .setParameter("importe", 10000)
                .getResultList();
        listaFacturaEmitidas.forEach(System.out::println);

        // ==== Consulta 6 ====
        System.out.println("\n=== Consulta 6: clientes con texto parcial o cuyo CUIT/CUIL comience con 20- ===");
        List<Cliente> clientesDenominacionOCuil20 = em.createQuery(
                        "SELECT c FROM Cliente c WHERE LOWER(c.denominacion) LIKE CONCAT('%', LOWER(:texto),'%') OR c.cuitCuil LIKE CONCAT( LOWER(:cuil),'%')",
                        Cliente.class
                )
                .setParameter("cuil", "20-")
                .setParameter("texto", "ia")
                .getResultList();
        clientesDenominacionOCuil20.forEach(System.out::println);

        // ==== Consulta 7 ====
        System.out.println("\n=== Consulta 7: todos los estados posibles de las facturas, sin duplicados, ordenados alfabeticamente de forma ascendente ===");
        List<String> estadosFacturas = em.createQuery(
                        "SELECT DISTINCT f.estado FROM FacturaVenta f ORDER BY f.estado ASC",
                        String.class
                )
                .getResultList();
        estadosFacturas.forEach(System.out::println);

        // ==== Consulta 8 ====
        System.out.println("\n=== Consulta 8: cantidad total de facturas, suma acumulada de sus importes totales y el importe promedio devuelto en un solo objeto/arreglo ===");
        Object[] cantFacturasSumImportesPromImportes = em.createQuery(
                        "SELECT COUNT (f), SUM (f.importeTotal), AVG (f.importeTotal)  FROM FacturaVenta f",
                        Object[].class
                )
                .getSingleResult();
        System.out.println(Arrays.toString(cantFacturasSumImportesPromImportes));

        // ==== Consulta 9 ====
        System.out.println("\n=== Consulta 9: Todos los puntos de venta cuyo numero coincida con (1, 2, 5) ===");
        List<PuntoVenta> puntosVentaFiltrados = em.createQuery(
                        "SELECT p FROM PuntoVenta p WHERE p.numero IN :puntos",
                        PuntoVenta.class
                )
                .setParameter("puntos", List.of(1,2,5))
                .getResultList();
        puntosVentaFiltrados.forEach(System.out::println);

        // Nivel 3

        // ==== Consulta 10 ====
        System.out.println("\n=== Consulta 10: Facturas de admin ===");
        List<FacturaVenta> facturasPorUsuario = em.createQuery(
                        "SELECT f FROM FacturaVenta f WHERE f.usuarioCarga.usuario = :nombre",
                        FacturaVenta.class
                )
                .setParameter("nombre", "admin")
                .getResultList();
        facturasPorUsuario.forEach(System.out::println);

        // ==== Consulta 11 ====
        System.out.println("\n=== Consulta 11: Facturas detalle del Punto de Venta 1 ===");
        List<FacturaVentaDetalle> facturasDetallePorPuntoVenta = em.createQuery(
                        "SELECT fd FROM FacturaVentaDetalle fd JOIN fd.facturaVenta f JOIN f.puntoVenta p WHERE p.numero = :puntoVenta",
                        FacturaVentaDetalle.class
                )
                .setParameter("puntoVenta", 1)
                .getResultList();
        facturasDetallePorPuntoVenta.forEach(System.out::println);

        // ==== Consulta 12 ====
        System.out.println("\n=== Consulta 12: Articulos con su marca, incluyendo los que no tienen marca ===");
        List<Object[]> articulosYMarcas = em.createQuery(
                        "SELECT a.denominacion, m.denominacion FROM Articulo a LEFT JOIN a.marca m",
                        Object[].class
                )
                .getResultList();
        articulosYMarcas.forEach(fila -> System.out.println(Arrays.toString(fila)));

        // ==== Consulta 13 ====
        System.out.println("\n=== Consulta 13: Facturas con al menos un detalle de articulo de Logitech ===");
        List<FacturaVenta> facturaVentasSegunMarca = em.createQuery(
                        "SELECT fd.facturaVenta FROM FacturaVentaDetalle fd WHERE fd.listaPrecioArticulo.articulo.marca.denominacion = :marca",
                        FacturaVenta.class
                )
                .setParameter("marca","Logitech")
                .getResultList();
        facturaVentasSegunMarca.forEach(System.out::println);

        // ==== Consulta 14 ====
        System.out.println("\n=== Consulta 14: Facturas cuyo importe total es mayor al importe promedio ===");
        List<FacturaVenta> facturasVentasMayoresAlPromedio = em.createQuery(
                        "SELECT f FROM FacturaVenta f WHERE f.importeTotal >" +
                                "(SELECT AVG(fv.importeTotal) FROM FacturaVenta fv)",
                        FacturaVenta.class
                )
                .getResultList();
        facturasVentasMayoresAlPromedio.forEach(System.out::println);

        // Nivel 4

        // ==== Consulta 15 ====
        System.out.println("\n=== Consulta 15: Descripcion de Punto de Venta, cantidad de Facturas y Total Facturado ===");
        List<Object[]> puntosVentaFacturas = em.createQuery(
                        "SELECT f.puntoVenta.descripcion, COUNT(f), SUM(f.importeTotal) FROM FacturaVenta f GROUP BY f.puntoVenta.id,f.puntoVenta.descripcion",
                        Object[].class
                )
                .getResultList();
        puntosVentaFacturas.forEach(fila -> System.out.println(Arrays.toString(fila)));

        // ==== Consulta 16 ====
        System.out.println("\n=== Consulta 16: Usuario con mas de 5 facturas de venta ===");
        List<String> usuariosCargaConMasCincoFacturas = em.createQuery(
                        "SELECT fv.usuarioCarga.nombre FROM FacturaVenta fv GROUP BY fv.usuarioCarga.id,fv.usuarioCarga.nombre HAVING COUNT(fv) > 5",
                        String.class
                )
                .getResultList();
        usuariosCargaConMasCincoFacturas.forEach(System.out::println);

        // ==== Consulta 17 ====
        System.out.println("\n=== Consulta 17: Denominacion de cada marca, cantidad total vendidas y el subtotal acumulado, agrupado por marca ===");
        List<Object[]> unidadesVendidasYSubtotalPorMarca = em.createQuery(
                        "SELECT fd.listaPrecioArticulo.articulo.marca.denominacion, SUM(fd.cantidad), SUM(fd.importeSubtotal) FROM FacturaVentaDetalle fd GROUP BY fd.listaPrecioArticulo.articulo.marca.id,fd.listaPrecioArticulo.articulo.marca.denominacion",
                        Object[].class
                )
                .getResultList();
        unidadesVendidasYSubtotalPorMarca.forEach(fila -> System.out.println(Arrays.toString(fila)));

        // Nivel 5

        // ==== Consulta 18 ====
        System.out.println("\n=== Consulta 18: Marca con al menos un articulo facturado ===");
        List<Marca> marcasConArticulosFacturados = em.createQuery(
                        "SELECT m FROM Marca m WHERE EXISTS " +
                                "(SELECT fd FROM FacturaVentaDetalle fd WHERE fd.listaPrecioArticulo.articulo.marca = m)",
                        Marca.class
                )
                .getResultList();
        marcasConArticulosFacturados.forEach(System.out::println);

        // ==== Consulta 19 ====
        System.out.println("\n=== Consulta 19: Articulo en ningun detalle factura ===");
        List<Articulo> articulosSinFacturacion = em.createQuery(
                        "SELECT a FROM Articulo a WHERE NOT EXISTS " +
                                "(SELECT fd FROM FacturaVentaDetalle fd WHERE fd.listaPrecioArticulo.articulo = a)",
                        Articulo.class
                )
                .getResultList();
        articulosSinFacturacion.forEach(System.out::println);

        // ==== Consulta 20 ====
        System.out.println("\n=== Consulta 20: Numero de factura, su importe total y una columna llamada Categoria ===");
        List<Object[]> facturasSegunCategorias = em.createQuery(
                        "SELECT f.numero, f.importeTotal, " +
                                "CASE " +
                                "WHEN f.importeTotal > 50000 THEN 'ALTO VALOR' " +
                                "WHEN f.importeTotal >= 10000 THEN 'MEDIO VALOR' " +
                                "ELSE 'BAJO VALOR' " +
                                "END AS categoria " +
                                "FROM FacturaVenta f ORDER BY f.importeTotal DESC",
                        Object[].class
                )
                .getResultList();
        facturasSegunCategorias.forEach(fila -> System.out.println(Arrays.toString(fila)));

        em.close();
        emf.close();
    }


    private static void auditar(
            AuditoriaApp entidad,
            Usuario usuario,
            Date fecha) {

        entidad.setFechaAlta(fecha);
        entidad.setFechaModificacion(fecha);
        entidad.setUsuarioCarga(usuario);
        entidad.setUsuarioModificacion(usuario);
    }
}
package com.example.tpGrupalARCA.service;

import com.example.tpGrupalARCA.dto.TipoMoneda.TipoMonedaDTO;
import com.example.tpGrupalARCA.entities.TipoMoneda;
import com.example.tpGrupalARCA.repository.TipoMonedaRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class TipoMonedaService {
    private final TipoMonedaRepository tipoMonedaRepository;

    public List<TipoMonedaDTO> findAll(){
        List<TipoMoneda> tipoMonedas = tipoMonedaRepository.findAllByFechaBajaNull();
        return tipoMonedas.stream().map(TipoMonedaDTO :: toDto).toList();
    }
}

package com.example.tpGrupalSpring.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.*;

@Entity
@Table(name = "PuntoVenta", schema = "modelo")
@Builder
@Getter
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true, of ={"numero", "domicilioComercial"})
@ToString

public class PuntoVenta extends AuditoriaApp{
    @Column(nullable = false)
    private int numero;
    @Setter
    private String descripcion;
    @Setter
    private String tipoEmision;
    private String domicilioComercial;
}

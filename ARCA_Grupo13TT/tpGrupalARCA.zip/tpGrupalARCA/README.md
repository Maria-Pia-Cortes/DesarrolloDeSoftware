# tpGrupalARCA – Facturación electrónica con ARCA/AFIP

Sistema de gestión de **Facturas de Venta** (CRUD) con backend en **Spring Boot** y frontend en **HTML + TypeScript**. Se integra con los web services de **ARCA/AFIP** (entorno de homologación) para certificar los comprobantes y obtener el **CAE**, y genera la **factura en PDF** con formato comercial.

> Trabajo práctico grupal – UTN FRM.

## Funcionalidades

- Alta, modificación, baja y consulta de facturas, con filtros y paginación.
- Búsqueda de clientes y artículos mediante exploradores.
- Grilla de ítems editable (cantidad, descripción, precio unitario, subtotal).
- Una factura se puede modificar por completo mientras **no esté certificada**; una vez informada a ARCA se bloquea la edición y solo puede anularse.
- Certificación contra ARCA (WSAA + WSFEv1) y obtención del CAE.
- **Impresión de la factura en PDF** (`GET /api/facturas/{id}/pdf`) con:
  - Encabezado: datos del negocio, letra y código del comprobante, número (`0001-00000012`), fecha y CUIT.
  - Datos del cliente: razón social, CUIT/DNI, domicilio, condición frente al IVA y moneda.
  - Tabla de ítems: Cantidad, Descripción, Precio Unitario y Subtotal.
  - Pie con subtotal neto, IVA y **total destacado**.
  - CAE y fecha de vencimiento del CAE.

## Requisitos

- **Java 17** (JDK)
- **PostgreSQL** con una base llamada `facturacion_db` (puerto 5432)
- **Node.js** y **pnpm** (para el frontend)
- Clave privada y certificado de **homologación** de ARCA (ya incluidos en la carpeta `arca/`)

Gradle no hace falta instalarlo: el proyecto incluye el wrapper (`gradlew`).

## Instalación y ejecución

### 1. Clonar el repositorio

```bash
git clone https://github.com/Maria-Pia-Cortes/DesarrolloDeSoftware.git
cd DesarrolloDeSoftware/ARCA_Grupo13TT
```

### 2. Configurar la base de datos y ARCA

Editar `src/main/resources/application.properties`:

- `spring.datasource.url`, `spring.datasource.username` y `spring.datasource.password` con los datos de tu PostgreSQL.
- `arca.cuit` con el CUIT del emisor y `arca.cbte-tipo` con el tipo de comprobante (`1` = A, `6` = B, `11` = C).

La carpeta `arca/` ya incluye la clave privada y el certificado de **homologación** (entorno de pruebas de ARCA), para que el proyecto funcione sin configuración extra:

- `privada_test.key`
- `certificado_test.crt`

> No son credenciales de producción. El certificado corresponde al CUIT configurado en `arca.cuit`: si se cambia el CUIT, hay que generar un certificado nuevo.

### 3. Datos del negocio para la factura impresa (opcional)

Si querés que aparezcan en el encabezado de la factura, agregá estas propiedades (todas son opcionales):

```properties
factura.emisor.razon-social=Mi Negocio S.R.L.
factura.emisor.condicion-iva=Responsable Monotributo
factura.emisor.ingresos-brutos=123456789
factura.emisor.inicio-actividades=01/11/2013
```

Si no se definen, se usa la descripción del punto de venta como nombre del negocio.

### 4. Levantar el backend

```bash
./gradlew bootRun        # Linux / macOS
gradlew.bat bootRun      # Windows
```

El backend queda en `http://localhost:8080`. Al iniciar por primera vez se cargan los datos iniciales.

### 5. Levantar el frontend

```bash
cd frontend
pnpm install
pnpm dev
```

Abrir `http://localhost:5173` en el navegador.

## Estructura del proyecto

```
ARCA_Grupo13TT/
├── arca/                 # clave y certificado de homologación de ARCA
├── frontend/             # HTML + TypeScript (Vite)
├── src/main/java/        # backend Spring Boot
│   └── com/example/tpGrupalARCA/
│       ├── arca/         # cliente WSAA / WSFE
│       ├── controller/   # API REST
│       ├── dto/          # DTOs (incluye FacturaImpresionDTO para el PDF)
│       ├── entities/     # entidades JPA
│       ├── repository/
│       └── service/      # lógica de negocio y generación de PDF (ReporteService)
├── build.gradle
└── README.md
```

## Integrantes

- Cortes Maria Pia
- Fehler Valentina
- Delahaye Agusto
- Rodriguez Santos
- Zerpa Santiago

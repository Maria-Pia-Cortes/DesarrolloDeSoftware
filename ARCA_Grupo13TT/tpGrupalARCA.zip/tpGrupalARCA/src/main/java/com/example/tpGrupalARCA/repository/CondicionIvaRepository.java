package com.example.tpGrupalARCA.repository;

import com.example.tpGrupalARCA.entities.CondicionIva;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface CondicionIvaRepository extends JpaRepository<CondicionIva, Long> {
    Optional<CondicionIva> findByIdAndFechaBajaNull(Long id);
    List<CondicionIva> findAllByFechaBajaNull();
}

package com.example.tpGrupalSpring.entities;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "ListaPrecioArticulo", schema = "modelo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@EqualsAndHashCode(callSuper = true, exclude = {"precioVenta"})
@ToString

public class ListaPrecioArticulo extends AuditoriaApp{

    @ManyToOne
    @JoinColumn(nullable = false)
    private ListaPrecio listaPrecio;
    @Setter
    @Column(nullable = false)
    private double precioVenta;
    @ManyToOne
    @JoinColumn(nullable = false)
    private Articulo articulo;
}

import type { ClienteDTO } from "./cliente.dto";
import type { FacturaDetalleRequestDTO, FacturaReporteEditDTO, FacturaRequestDTO, FacturaRequestEditDTO } from "./factura.dto";
import { FacturaDetalle } from "./FacturaDetalle";

export class Factura {
    public cliente : ClienteDTO | null;
    public idTipoMoneda : number;
    public idPuntoVenta : number;
    public idCondicionIVA : number;
    public idListaPrecio : number;
    public observaciones: string;
    private detalles: FacturaDetalle[] = [];

    constructor(){
        this.cliente = null;
        this.idTipoMoneda = 0;
        this.idPuntoVenta = 0;
        this.idCondicionIVA = 0;
        this.idListaPrecio = 0;
        this.observaciones = "";
    }

    get total(){
        return this.detalles.reduce((ac,d) => ac + d.subtotal,0)
    }

    get tieneItems(): boolean{
        return (this.detalles.length > 0);
    }

    agregarDetalle(nuevo: FacturaDetalle): boolean{
        const detalle = this.detalles.find(d => d.idArticulo === nuevo.idArticulo);
        if(detalle){
            detalle?.incrementar(nuevo.getCantidad)
            return false
        }
        this.detalles.push(nuevo);
        return true;
    }

    quitarDetalle(idArticulo: number){
        this.detalles = this.detalles.filter(d => d.idArticulo !== idArticulo);     
    }

    leerDetalles(): ReadonlyArray<FacturaDetalle>{ return this.detalles; }

    vaciarDetalles(){ this.detalles = []; }

    aRequest(): FacturaRequestDTO{
        let detalles : FacturaDetalleRequestDTO[] = this.detalles.map(d => d.toRequestDTO());
        const facturaRequestDTO: FacturaRequestDTO = {
            idCliente: !this.cliente ? null : this.cliente.idCliente,
            idTipoMoneda: this.idTipoMoneda,
            idPuntoVenta: this.idPuntoVenta,
            idCondicionIVA: this.idCondicionIVA,
            idListaPrecio: this.idListaPrecio,
            observaciones: this.observaciones,
            detalles: detalles,
        };
        return facturaRequestDTO;
    }

    aRequestEdit(): FacturaRequestEditDTO{
        let detalles : FacturaDetalleRequestDTO[] = this.detalles.map(d => d.toRequestDTO());
        const facturaRequestEditDTO : FacturaRequestEditDTO = {
            observaciones: this.observaciones,
            detalles: detalles,
        }
        return facturaRequestEditDTO
    }

    static desdeDTO(dto: FacturaReporteEditDTO): Factura{
        let factura: Factura = new Factura();
        // El back solo manda id y denominación del cliente (no el CUIT): alcanza para mostrarlo y para el request.
        factura.cliente = dto.idCliente !== null
            ? { idCliente: dto.idCliente, cuitCuil: "", denominacion: dto.denominacionCliente }
            : null;
        factura.idTipoMoneda = dto.idTipoMoneda;
        factura.idPuntoVenta = dto.idPuntoVenta;
        factura.idCondicionIVA = dto.idCondicionIVA;
        factura.idListaPrecio = dto.idListaPrecio;
        factura.observaciones = dto.observaciones ?? "";
        factura.detalles = dto.detalles.map(d => FacturaDetalle.desdeDTO(d));
        return factura;
    }
}
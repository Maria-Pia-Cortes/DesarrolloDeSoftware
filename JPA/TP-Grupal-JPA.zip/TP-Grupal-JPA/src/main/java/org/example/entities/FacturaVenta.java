package org.example.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.Date;
import java.util.List;

@Entity
@Table (name = "Factura")
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter

public class FacturaVenta extends AuditoriaApp{
    private Long numero;
    @Temporal(TemporalType.DATE)
    @Column(nullable = false)
    private Date fechaEmision;
    @ManyToOne
    @JoinColumn(nullable = false)
    private PuntoVenta puntoVenta;
    private double importeCobrado;
    private double importeSaldo;
    @Column (nullable = false)
    private double importeTotal;
    private String cae;
    @Temporal(TemporalType.DATE)
    private Date caeFechaVencimiento;
    private String resultadoAfip;
    private String motivoRechazo;
    @Column(nullable = false)
    private String estado;
    @Temporal(TemporalType.DATE)
    private Date fechaAnulacion;
    private String observaciones;
    @OneToMany(mappedBy = "facturaVenta", cascade = CascadeType.ALL)
    private List<FacturaVentaDetalle> detalles;
}

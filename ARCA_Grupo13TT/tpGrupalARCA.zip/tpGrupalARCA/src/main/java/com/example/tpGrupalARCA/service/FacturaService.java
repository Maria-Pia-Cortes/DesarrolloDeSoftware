package com.example.tpGrupalARCA.service;

import com.example.tpGrupalARCA.arca.ArcaService;
import com.example.tpGrupalARCA.arca.RespuestaCae;
import com.example.tpGrupalARCA.dto.FacturaVenta.*;
import com.example.tpGrupalARCA.dto.Paginacion.PaginaDTO;
import com.example.tpGrupalARCA.entities.*;
import com.example.tpGrupalARCA.repository.*;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityNotFoundException;
import jakarta.persistence.PersistenceContext;
import org.springframework.transaction.annotation.Transactional;
import jakarta.persistence.TypedQuery;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.*;

@RequiredArgsConstructor
@Service
public class FacturaService {
    private final FacturaVentaRepository facturaVentaRepository;
    private final ClienteRepository clienteRepository;
    private final TipoMonedaRepository tipoMonedaRepository;
    private final PuntoVentaRepository puntoVentaRepository;
    private final CondicionIvaRepository condicionIvaRepository;
    private final ListaPrecioRepository listaPrecioRepository;
    private final ArticuloRepository articuloRepository;
    private final ListaPrecioArticuloRepository listaPrecioArticuloRepository;
    private final ArcaService arcaService;

    @PersistenceContext
    private EntityManager em;

    private void cargarDetallesAFactura(CondicionIva condicionIva, ListaPrecio listaPrecio, List<FacturaDetalleRequestDTO> detalles, FacturaVenta facturaVenta) {
        Set<Long> vistos= new HashSet<>();

        if (detalles == null || detalles.isEmpty()) {
            throw new IllegalArgumentException("La factura debe tener al menos un item, sino debe ser eliminada");
        }

        double iva = 0.00;
        if (condicionIva.getDenominacion().equals("Responsable Inscripto")) {
            iva = 10.5;
        } else if (condicionIva.getDenominacion().equals("Consumidor Final")) {
            iva = 21.0;
        }

        for (FacturaDetalleRequestDTO detalle : detalles) {
            if (detalle.cantidad() <= 0)
                throw new IllegalArgumentException("La cantidad del detalle debe ser mayor que 0");
            if (!vistos.add(detalle.idArticulo())) throw new IllegalArgumentException("Un articulo solo puede estar dentro de una sola linea de articulo");

            Articulo articulo = articuloRepository.findByIdAndFechaBajaNull(detalle.idArticulo())
                    .orElseThrow(() -> new EntityNotFoundException("No se encontro el Articulo de id: " + detalle.idArticulo()));
            ListaPrecioArticulo listaPrecioArticulo = listaPrecioArticuloRepository.findByListaPrecioAndArticuloAndFechaBajaNull(listaPrecio, articulo)
                    .orElseThrow(() -> new EntityNotFoundException("No se encuentra cargado un precio para ese articulo con esa lista de precio"));
            facturaVenta.addDetalle(detalle.toEntity(facturaVenta, listaPrecioArticulo, iva));
        }
    }

    @Transactional
    public FacturaReporteDTO autorizar(Long facturaId) {
        FacturaVenta factura = facturaVentaRepository.findByIdAndFechaBajaNull(facturaId)
                .orElseThrow(() -> new EntityNotFoundException("No se encontro la Factura con id: " + facturaId));
        if ("AUTORIZADA".equals(factura.getEstado())) {
            throw new IllegalArgumentException("La factura ya fue autorizada por ARCA (CAE " + factura.getCae() + ")");
        }
        if ("ANULADA".equals(factura.getEstado())) {
            throw new IllegalArgumentException("No se puede enviar a ARCA una factura anulada");
        }
        autorizarEnArca(factura, factura.getPuntoVenta(), factura.getCondicionIva(), factura.getCliente());
        return FacturaReporteDTO.toDto(factura);
    }

    private void autorizarEnArca(FacturaVenta factura, PuntoVenta puntoVenta,
                                 CondicionIva condicionIva, Cliente cliente) {
        try {
            factura.setMotivoRechazo(null);   // por si es un reintento y quedó el motivo anterior
            String documento = (cliente == null) ? null : cliente.getCuitCuil();
            RespuestaCae respuesta = arcaService.autorizar(
                    puntoVenta.getNumero(), condicionIva.getCodigoAfip(), documento, factura.getImporteTotal());

            factura.setResultadoAfip(respuesta.getResultado());

            if (respuesta.isAprobado()) {
                factura.setCae(respuesta.getCae());
                factura.setNumero(respuesta.getNumero());
                factura.setCaeFechaVencimiento(new SimpleDateFormat("yyyyMMdd").parse(respuesta.getCaeFechaVencimiento()));
                factura.setEstado("AUTORIZADA");
            } else {
                factura.setEstado("RECHAZADA");
                factura.setMotivoRechazo(recortar(String.join(" | ", respuesta.getMensajes())));
            }
        } catch (Exception e) {
            factura.setEstado("ERROR_ARCA");
            factura.setMotivoRechazo(recortar(e.getMessage()));
        }
    }

    private String recortar(String texto) {
        if (texto == null) return null;
        return texto.length() > 500 ? texto.substring(0, 500) : texto;
    }

    @Transactional
    public FacturaReporteDTO save(FacturaRequestDTO facturaRequestDTO) {
        TipoMoneda tipoMoneda = tipoMonedaRepository.findByIdAndFechaBajaNull(facturaRequestDTO.idTipoMoneda())
                .orElseThrow(() -> new EntityNotFoundException("No se encontro el Tipo de Moneda con id: " + facturaRequestDTO.idTipoMoneda()));
        PuntoVenta puntoVenta = puntoVentaRepository.findByIdAndFechaBajaNull(facturaRequestDTO.idPuntoVenta())
                .orElseThrow(() -> new EntityNotFoundException("No se encontro el Punto de Venta con id: " + facturaRequestDTO.idPuntoVenta()));
        CondicionIva condicionIva = condicionIvaRepository.findByIdAndFechaBajaNull(facturaRequestDTO.idCondicionIVA())
                .orElseThrow(() -> new EntityNotFoundException("No se encontro la Condicion Iva con id: " + facturaRequestDTO.idCondicionIVA()));
        Cliente cliente = null;
        if (facturaRequestDTO.idCliente() != null) {
            cliente = clienteRepository.findByIdAndFechaBajaNull(facturaRequestDTO.idCliente())
                    .orElseThrow(() -> new EntityNotFoundException("No se encontro el Cliente de id: " + facturaRequestDTO.idCliente()));
        } else {
            if (!Objects.equals(condicionIva.getDenominacion(), "Consumidor Final"))
                throw new IllegalArgumentException("Si el Cliente es consumidor final, su condicion de iva tambien lo sera");
        }
        ListaPrecio listaPrecio = listaPrecioRepository.findByIdAndFechaBajaNull(facturaRequestDTO.idListaPrecio())
                .orElseThrow(() -> new EntityNotFoundException("No se encontro la Lista de Precio con id: " + facturaRequestDTO.idListaPrecio()));

        FacturaVenta facturaVenta = facturaRequestDTO.toEntity(cliente, tipoMoneda, puntoVenta, condicionIva, listaPrecio);

        cargarDetallesAFactura(condicionIva,listaPrecio,facturaRequestDTO.detalles(),facturaVenta);

        facturaVenta = facturaVentaRepository.save(facturaVenta);
        return FacturaReporteDTO.toDto(facturaVenta);
    }

    @Transactional
    public FacturaReporteDTO update(FacturaRequestEditDTO facturaRequestEditDTO, Long facturaId) {
        FacturaVenta factura = facturaVentaRepository.findByIdAndFechaAnulacionNullAndFechaBajaNull(facturaId)
                .orElseThrow(() -> new EntityNotFoundException("No se econtro la Factura con id: " + facturaId));
        if (factura.getEstado().equals("AUTORIZADA")) throw new IllegalArgumentException("No se puede editar una factura autorizada por Arca");

        facturaRequestEditDTO.applyTo(factura);

        ListaPrecio listaPrecio = factura.getListaPrecio();
        CondicionIva condicionIva = factura.getCondicionIva();

        factura.limpiarDetalles();
        cargarDetallesAFactura(condicionIva,listaPrecio,facturaRequestEditDTO.detalles(),factura);

        factura.setEstado("INGRESADA");
        factura.setMotivoRechazo(null);
        factura.setResultadoAfip(null);
        factura.setFechaModificacion(new Date());

        factura = facturaVentaRepository.save(factura);
        return FacturaReporteDTO.toDto(factura);
    }

    @Transactional(readOnly = true)
    public FacturaReporteEditDTO obtenerFacturaAEditar(Long idFactura){
         FacturaVenta facturaVenta = facturaVentaRepository.findByIdAndFechaAnulacionNullAndFechaBajaNull(idFactura)
                .orElseThrow(() -> new EntityNotFoundException("No se encontro la factura con id: " + idFactura));
         if (facturaVenta.getEstado().equals("AUTORIZADA")) throw new IllegalArgumentException("No se puede editar una factura ya autorizada por al ARCA");
        return  FacturaReporteEditDTO.toDto(facturaVenta);
    }

    @Transactional
    public void delete(Long facturaId) {
        FacturaVenta facturaVenta = facturaVentaRepository.findByIdAndFechaBajaNull(facturaId)
                .orElseThrow(() -> new EntityNotFoundException("No se econtro la Factura con id: " + facturaId));
        if (Set.of("AUTORIZADA", "ANULADA").contains(facturaVenta.getEstado())) {
            throw new IllegalArgumentException("No se puede eliminar la factura");
        }
        facturaVenta.setFechaBaja(new Date());
        facturaVenta.setEstado("ELIMINADA");
        facturaVentaRepository.save(facturaVenta);
    }

    @Transactional
    public void anular(Long facturaId) {
        FacturaVenta factura = facturaVentaRepository.findByIdAndFechaBajaNull(facturaId)
                .orElseThrow(() -> new EntityNotFoundException("No se econtro la Factura con id: " + facturaId));
        if (factura.getEstado().equals("ANULADA"))
            throw new IllegalArgumentException("No se puede anular una factura ya anulada");
        if (!factura.getEstado().equals("AUTORIZADA")) {
            throw new IllegalArgumentException("No se puede anular una factura no informada al arca");
        }
        factura.setEstado("ANULADA");
        factura.setFechaAnulacion(new Date());
        facturaVentaRepository.save(factura);
    }

    @Transactional(readOnly = true)
    public FacturaImpresionDTO buscarFacturaParaImprimir(Long facturaId) {
        FacturaVenta factura = facturaVentaRepository.findByIdAndFechaBajaNull(facturaId)
                .orElseThrow(() -> new EntityNotFoundException("No se encontro la Factura con id: " + facturaId));
        if (factura.getCae() == null || factura.getCae().isBlank()) {
            throw new IllegalArgumentException("La factura no tiene CAE, no se puede imprimir");
        }
        if ("ANULADA".equals(factura.getEstado())) {
            throw new IllegalArgumentException("No se puede imprimir una factura anulada");
        }
        return FacturaImpresionDTO.toDto(factura);
    }

    public PaginaDTO<FacturaReporteDTO> buscarFacturasPaginadas(Date fechaDesde, Date fechaHasta, Long numeroComprobante, Long idCliente, Boolean informada, int pagina, int tamanio) {
        if (!Set.of(5, 10, 20).contains(tamanio))
            throw new IllegalArgumentException("Ingrese un tamaño de paginacion valido");
        if (pagina < 0) throw new IllegalArgumentException("Ingrese una pagina valida");

        StringBuilder cantFacturas = new StringBuilder(
                "SELECT COUNT(DISTINCT f.id)" +
                        " FROM FacturaVenta f " +
                        " LEFT JOIN f.cliente c " +
                        " JOIN f.condicionIva ci " +
                        " JOIN f.puntoVenta pv " +
                        " JOIN f.detalles d " +
                        " WHERE f.fechaBaja IS NULL"
        );

        StringBuilder facturas = new StringBuilder(
                "SELECT new com.example.tpGrupalARCA.dto.FacturaVenta.FacturaReporteDTO( " +
                        " f.id, f.numero, f.fechaEmision," +
                        " CASE" +
                        "   WHEN c.denominacion IS NULL THEN 'Consumidor Final'" +
                        "   ELSE c.denominacion" +
                        " END," +
                        " ci.denominacion, pv.descripcion, f.importeTotal, COUNT(d), " +
                        " f.cae, f.caeFechaVencimiento, f.estado, f.motivoRechazo," +
                        " pv.numero " +
                        ")" +
                        " FROM FacturaVenta f " +
                        " LEFT JOIN f.cliente c " +
                        " JOIN f.condicionIva ci " +
                        " JOIN f.puntoVenta pv " +
                        " JOIN f.detalles d " +
                        " WHERE f.fechaBaja IS NULL"
        );

        Map<String, Object> parametros = new HashMap<>();

        if (fechaDesde != null) {
            facturas.append(" AND f.fechaEmision >= :fechaDesde ");
            cantFacturas.append(" AND f.fechaEmision >= :fechaDesde ");
            parametros.put("fechaDesde", fechaDesde);
        }
        if (fechaHasta != null) {
            facturas.append(" AND f.fechaEmision <= :fechaHasta ");
            cantFacturas.append(" AND f.fechaEmision <= :fechaHasta ");
            parametros.put("fechaHasta", fechaHasta);
        }
        if (numeroComprobante != null) {
            facturas.append(" AND f.numero = :numeroComprobante ");
            cantFacturas.append(" AND f.numero = :numeroComprobante ");
            parametros.put("numeroComprobante", numeroComprobante);
        }
        if (idCliente != null) {
            facturas.append(" AND c.id = :idCliente ");
            cantFacturas.append(" AND c.id = :idCliente ");
            parametros.put("idCliente", idCliente);
        }
        if (informada != null) {
            if (informada) {
                facturas.append(" AND f.numero IS NOT NULL");
                cantFacturas.append(" AND f.numero IS NOT NULL");
            } else {
                facturas.append(" AND f.numero IS NULL");
                cantFacturas.append(" AND f.numero IS NULL");
            }
        }

        TypedQuery<Long> queryCantFacturas = em.createQuery(cantFacturas.toString(), Long.class);
        parametros.forEach(queryCantFacturas::setParameter);

        facturas.append(" GROUP BY f.id, f.numero, f.fechaEmision, c.denominacion, ci.denominacion," +
                " pv.descripcion, f.importeTotal, f.cae, f.caeFechaVencimiento," +
                " f.estado, f.motivoRechazo, pv.numero");
        facturas.append(" ORDER BY f.id DESC");

        TypedQuery<FacturaReporteDTO> queryFacturas = em.createQuery(facturas.toString(), FacturaReporteDTO.class);
        queryFacturas.setFirstResult(pagina * tamanio);
        queryFacturas.setMaxResults(tamanio);
        parametros.forEach(queryFacturas::setParameter);

        return PaginaDTO.paginar(queryFacturas.getResultList(), pagina, tamanio, queryCantFacturas.getSingleResult());
    }

    public List<FacturaReporteDTO> buscarFacturasFiltradas(Date fechaDesde, Date fechaHasta, String estado, Double montoMinimo) {
        StringBuilder jpql = new StringBuilder(
                "SELECT new com.example.tpGrupalARCA.dto.FacturaVenta.FacturaReporteDTO( " +
                        " f.id, f.numero, f.fechaEmision," +
                        " CASE" +
                        "   WHEN c.denominacion IS NULL THEN 'Consumidor Final'" +
                        "   ELSE c.denominacion" +
                        " END," +
                        " ci.denominacion, pv.descripcion, f.importeTotal, COUNT(d), " +
                        " f.cae, f.caeFechaVencimiento, f.estado, f.motivoRechazo," +
                        " pv.numero " +
                        ")" +
                        "FROM FacturaVenta f " +
                        " LEFT JOIN f.cliente c " +
                        " JOIN f.condicionIva ci " +
                        " JOIN f.puntoVenta pv " +
                        " JOIN f.detalles d " +
                        " WHERE f.fechaBaja IS NULL"
        );

        Map<String, Object> parametros = new HashMap<>();
        if (fechaDesde != null) {
            jpql.append(" AND f.fechaEmision >= :fechaDesde ");
            parametros.put("fechaDesde", fechaDesde);
        }
        if (fechaHasta != null) {
            jpql.append(" AND f.fechaEmision <= :fechaHasta ");
            parametros.put("fechaHasta", fechaHasta);
        }
        if (estado != null && !estado.trim().isEmpty()) {
            jpql.append(" AND f.estado = :estado ");
            parametros.put("estado", estado);
        }
        if (montoMinimo != null) {
            jpql.append(" AND f.importeTotal >= :montoMinimo ");
            parametros.put("montoMinimo", montoMinimo);
        }

        jpql.append(" GROUP BY f.id, f.numero, f.fechaEmision, c.denominacion, ci.denominacion," +
                " pv.descripcion, f.importeTotal, f.cae, f.caeFechaVencimiento," +
                " f.estado, f.motivoRechazo, pv.numero");
        jpql.append(" ORDER BY f.id ASC");

        TypedQuery<FacturaReporteDTO> query = em.createQuery(jpql.toString(),
                FacturaReporteDTO.class);
        parametros.forEach(query::setParameter);

        return query.getResultList();
    }
}
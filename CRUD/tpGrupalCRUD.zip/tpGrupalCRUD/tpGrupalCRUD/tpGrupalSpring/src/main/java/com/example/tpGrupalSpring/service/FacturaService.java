package com.example.tpGrupalSpring.service;

import com.example.tpGrupalSpring.dto.FacturaDetalleRequestDTO;
import com.example.tpGrupalSpring.dto.FacturaReporteDTO;
import com.example.tpGrupalSpring.dto.FacturaRequestDTO;
import com.example.tpGrupalSpring.entities.Cliente;
import com.example.tpGrupalSpring.entities.CondicionIva;
import com.example.tpGrupalSpring.entities.FacturaVenta;
import com.example.tpGrupalSpring.entities.FacturaVentaDetalle;
import com.example.tpGrupalSpring.entities.ListaPrecioArticulo;
import com.example.tpGrupalSpring.entities.PuntoVenta;
import com.example.tpGrupalSpring.entities.TipoMoneda;
import com.example.tpGrupalSpring.entities.Usuario;
import com.example.tpGrupalSpring.exception.RecursoNoEncontradoException;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class FacturaService {

    private static final double ALICUOTA_IVA = 0.21;
    private static final String ESTADO_INICIAL = "EMITIDA";
    private static final String ESTADO_ANULADA = "ANULADA";

    @PersistenceContext
    private EntityManager em;

    public List<FacturaReporteDTO> buscarFacturasFiltradas(Date fechaDesde, Date fechaHasta, String estado, Double montoMinimo){
        StringBuilder jpql = new StringBuilder(
                "SELECT new com.example.tpGrupalSpring.dto.FacturaReporteDTO( " +
                        "f.id, f.numero, f.fechaEmision," +
                        " CASE" +
                        "   WHEN c.denominacion IS NULL THEN 'Consumidor Final'" +
                        "   ELSE c.denominacion" +
                        " END," +
                        " ci.denominacion, pv.descripcion, f.importeTotal, COUNT(d), f.estado " +
                        ")" +
                        " FROM FacturaVenta f " +
                        " LEFT JOIN f.cliente c " +
                        " JOIN f.condicionIva ci " +
                        " JOIN f.puntoVenta pv " +
                        " JOIN f.detalles d " +
                        " WHERE 1=1"
        );

        Map<String, Object> parametros = new HashMap<>();

        if(fechaDesde != null){
            jpql.append(" AND f.fechaEmision >= :fechaDesde ");
            parametros.put("fechaDesde", fechaDesde);
        }
        if(fechaHasta != null){
            jpql.append(" AND f.fechaEmision <= :fechaHasta ");
            parametros.put("fechaHasta", fechaHasta);
        }
        if(estado != null && !estado.trim().isEmpty()){
            jpql.append(" AND f.estado = :estado ");
            parametros.put("estado", estado);
        }
        if (montoMinimo != null){
            jpql.append(" AND f.importeTotal >= :montoMinimo ");
            parametros.put("montoMinimo", montoMinimo);
        }

        jpql.append(" GROUP BY f.id, f.numero, f.fechaEmision, c.denominacion, ci.denominacion," +
                " pv.descripcion, f.importeTotal, f.estado");

        TypedQuery<FacturaReporteDTO> query = em.createQuery(jpql.toString(),
                FacturaReporteDTO.class);
        parametros.forEach(query::setParameter);

        return query.getResultList();
    }

    // CREAR
    @Transactional
    public FacturaReporteDTO crear(FacturaRequestDTO dto) {
        if (dto.detalles() == null || dto.detalles().isEmpty()) {
            throw new IllegalArgumentException("La factura debe tener al menos un detalle");
        }

        // Buscar las entidades asociadas por ID (si no existen, RecursoNoEncontradoException)
        PuntoVenta puntoVenta = buscar(PuntoVenta.class, dto.puntoVentaId(), "el punto de venta");
        CondicionIva condicionIva = buscar(CondicionIva.class, dto.condicionIvaId(), "la condición de IVA");
        TipoMoneda tipoMoneda = buscar(TipoMoneda.class, dto.tipoMonedaId(), "el tipo de moneda");
        Cliente cliente = dto.clienteId() != null
                ? buscar(Cliente.class, dto.clienteId(), "el cliente")
                : null; // null = Consumidor Final

        // Mapear el DTO a la entidad
        Date ahora = new Date();
        Usuario usuario = usuarioActual();

        FacturaVenta factura = FacturaVenta.builder()
                .cliente(cliente)
                .tipoMoneda(tipoMoneda)
                .puntoVenta(puntoVenta)
                .condicionIva(condicionIva)
                .numero(siguienteNumero())
                .fechaEmision(dto.fechaEmision() != null ? dto.fechaEmision() : ahora)
                .estado(tieneTexto(dto.estado()) ? dto.estado() : ESTADO_INICIAL)
                .observaciones(dto.observaciones())
                .detalles(new ArrayList<>())
                .build();

        // Campos de auditoría (obligatorios en AuditoriaApp)
        factura.setFechaAlta(ahora);
        factura.setFechaModificacion(ahora);
        factura.setUsuarioCarga(usuario);
        factura.setUsuarioModificacion(usuario);

        // Detalles + importes (neto, IVA, subtotal por renglón y total de la factura)
        agregarDetalles(factura, dto.detalles());
        recalcularImportes(factura);

        // Guardar: los detalles se persisten en cascada (CascadeType.ALL)
        em.persist(factura);

        return FacturaReporteDTO.toDto(factura);
    }

    // Actualizar
    @Transactional
    public FacturaReporteDTO actualizar(Long id, FacturaRequestDTO dto) {
        FacturaVenta factura = em.find(FacturaVenta.class, id);
        if (factura == null) {
            throw new RecursoNoEncontradoException("No existe la factura con id " + id);
        }

        // Cabecera
        if (dto.clienteId() != null) {
            factura.setCliente(buscar(Cliente.class, dto.clienteId(), "el cliente"));
        }
        if (dto.condicionIvaId() != null) {
            factura.setCondicionIva(buscar(CondicionIva.class, dto.condicionIvaId(), "la condición de IVA"));
        }
        if (dto.puntoVentaId() != null) {
            factura.setPuntoVenta(buscar(PuntoVenta.class, dto.puntoVentaId(), "el punto de venta"));
        }
        if (dto.tipoMonedaId() != null) {
            factura.setTipoMoneda(buscar(TipoMoneda.class, dto.tipoMonedaId(), "el tipo de moneda"));
        }
        if (dto.fechaEmision() != null) {
            factura.setFechaEmision(dto.fechaEmision());
        }
        if (dto.observaciones() != null) {
            factura.setObservaciones(dto.observaciones());
        }

        // Estado (anulación lógica)
        if (tieneTexto(dto.estado())) {
            factura.setEstado(dto.estado());
            if (ESTADO_ANULADA.equalsIgnoreCase(dto.estado()) && factura.getFechaAnulacion() == null) {
                factura.setFechaAnulacion(new Date());
            }
        }

        // detalles: si vienen, reemplazan a los anteriores
        if (dto.detalles() != null) {
            if (dto.detalles().isEmpty()) {
                throw new IllegalArgumentException("La factura debe tener al menos un detalle");
            }
            // clear() por el orphanRemoval = true
            factura.getDetalles().clear();
            agregarDetalles(factura, dto.detalles());
            recalcularImportes(factura);
        }

        factura.setFechaModificacion(new Date());
        factura.setUsuarioModificacion(usuarioActual());

        return FacturaReporteDTO.toDto(factura);

        // No hay persist porque Hibernate, por el em.find, cuando termina el metodo Hibernate detecta que cambio y ejecuta UPDATE (dirty checking)
    }


    // Eliminar
    @Transactional
    public void eliminar(Long id) {
        FacturaVenta factura = em.find(FacturaVenta.class, id);
        if (factura == null) {
            throw new RecursoNoEncontradoException("No existe la factura con id " + id);
        }
        em.remove(factura); // los detalles se borran en cascada
    }

    // Métodos

    // Convierte cada renglón del DTO en un detalle con sus importes
    private void agregarDetalles(FacturaVenta factura, List<FacturaDetalleRequestDTO> detallesDto) {
        for (FacturaDetalleRequestDTO d : detallesDto) {
            if (d.cantidad() <= 0) {
                throw new IllegalArgumentException("La cantidad debe ser mayor a 0");
            }
            if (d.porcentajeBonificacion() < 0 || d.porcentajeBonificacion() > 100) {
                throw new IllegalArgumentException("La bonificación debe estar entre 0 y 100");
            }

            ListaPrecioArticulo listaPrecioArticulo = buscarListaPrecioArticulo(d.articuloId());

            // Si el cliente no escribe precio, se usa el de la lista de precios
            double precio = d.precioUnitario() != null
                    ? d.precioUnitario()
                    : listaPrecioArticulo.getPrecioVenta();
            if (precio < 0) {
                throw new IllegalArgumentException("El precio unitario no puede ser negativo");
            }

            double neto = redondear(d.cantidad() * precio * (1 - d.porcentajeBonificacion() / 100));
            double iva = redondear(neto * ALICUOTA_IVA);

            FacturaVentaDetalle detalle = FacturaVentaDetalle.builder()
                    .facturaVenta(factura)
                    .listaPrecioArticulo(listaPrecioArticulo)
                    .descripcion(tieneTexto(d.descripcion())
                            ? d.descripcion()
                            : listaPrecioArticulo.getArticulo().getDenominacion())
                    .cantidad(d.cantidad())
                    .precioUnitario(precio)
                    .porcentajeBonificacion(d.porcentajeBonificacion())
                    .importeNeto(neto)
                    .importeIva(iva)
                    .importeSubtotal(redondear(neto + iva))
                    .build();

            factura.getDetalles().add(detalle);
        }
    }

    // Suma los subtotales y calcula el saldo
    private void recalcularImportes(FacturaVenta factura) {
        double total = redondear(factura.getDetalles().stream()
                .mapToDouble(FacturaVentaDetalle::getImporteSubtotal)
                .sum());
        factura.setImporteTotal(total);
        factura.setImporteSaldo(redondear(total - factura.getImporteCobrado()));
    }

    // Busca cualquier entidad por ID, con 400 si falta el id y 404 si no existe
    private <T> T buscar(Class<T> clase, Long id, String nombre) {
        if (id == null) {
            throw new IllegalArgumentException("Falta el id de " + nombre);
        }
        T entidad = em.find(clase, id);
        if (entidad == null) {
            throw new RecursoNoEncontradoException("No existe " + nombre + " con id " + id);
        }
        return entidad;
    }

    // Trae el precio de lista vigente de un artículo
    private ListaPrecioArticulo buscarListaPrecioArticulo(Long articuloId) {
        if (articuloId == null) {
            throw new IllegalArgumentException("Falta el id del artículo");
        }
        List<ListaPrecioArticulo> resultado = em.createQuery(
                        "SELECT l FROM ListaPrecioArticulo l " +
                                "WHERE l.articulo.id = :articuloId AND l.fechaBaja IS NULL " +
                                "ORDER BY l.id",
                        ListaPrecioArticulo.class)
                .setParameter("articuloId", articuloId)
                .setMaxResults(1)
                .getResultList();
        if (resultado.isEmpty()) {
            throw new RecursoNoEncontradoException(
                    "No hay precio de lista para el artículo con id " + articuloId);
        }
        return resultado.get(0);
    }

    // Toma el mayor numero y le suma uno
    private Long siguienteNumero() {
        Long maximo = em.createQuery("SELECT MAX(f.numero) FROM FacturaVenta f", Long.class)
                .getSingleResult();
        return (maximo == null ? 0L : maximo) + 1;
    }

    // No hay login en el proyecto: se usa el usuario "admin" que crea CargaDatosInicial
    private Usuario usuarioActual() {
        return em.createQuery("SELECT u FROM Usuario u WHERE u.usuario = :nombre", Usuario.class)
                .setParameter("nombre", "admin")
                .getResultStream()
                .findFirst()
                .orElseThrow(() -> new RecursoNoEncontradoException("No existe el usuario admin"));
    }

    // Revisa si hay texto vacio
    private boolean tieneTexto(String texto) {
        return texto != null && !texto.trim().isEmpty();
    }

    // Redondea a dos decimales
    private double redondear(double valor) {
        return Math.round(valor * 100.0) / 100.0;
    }
}


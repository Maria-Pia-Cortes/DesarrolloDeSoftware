package com.example.tpGrupalARCA.controller;

import com.example.tpGrupalARCA.dto.TipoMoneda.TipoMonedaDTO;
import com.example.tpGrupalARCA.service.TipoMonedaService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/tipos-moneda")
@RequiredArgsConstructor
public class TipoMonedaController{
    private final TipoMonedaService tipoMonedaService;

    @GetMapping
    public List<TipoMonedaDTO> findAll(){
        return tipoMonedaService.findAll();
    }
}

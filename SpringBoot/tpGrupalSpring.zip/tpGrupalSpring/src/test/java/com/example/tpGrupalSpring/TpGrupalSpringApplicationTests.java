package com.example.tpGrupalSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpGrupalSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}

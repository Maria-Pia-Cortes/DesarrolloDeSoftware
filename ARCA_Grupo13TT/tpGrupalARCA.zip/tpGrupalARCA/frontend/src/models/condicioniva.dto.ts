export interface CondicionIvaDTO {
    idCondicionIva : number,
    codigoAfip : number,
    denominacion : string
}
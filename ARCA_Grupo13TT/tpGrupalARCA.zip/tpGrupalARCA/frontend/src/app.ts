import type { ClienteDTO } from "./models/cliente.dto";
import { Factura } from "./models/Factura";
import type { FacturaFiltrosDTO, FacturaReporteDTO } from "./models/factura.dto";
import { FacturaDetalle } from "./models/FacturaDetalle";
import type { ListaPrecioArticuloDTO } from "./models/listaprecio.dto";
import { CatalogoService } from "./services/CatalogoService";
import { ClienteService } from "./services/ClienteService";
import { FacturaService } from "./services/FacturaService";
import "./style.css";

function poblarSelect<T>(
    select: HTMLSelectElement,
    items: T[],
    obtenerValor: (item: T) => string,
    obtenerTexto: (item: T) => string,
    textoPlaceholder?: string
): void {
    select.length = 0;

    if (textoPlaceholder) {
        const placeholder = new Option(textoPlaceholder, "", true, true);
        placeholder.disabled = true;
        select.add(placeholder);
    }

    for (const item of items) {
        const opcion = new Option(obtenerTexto(item), obtenerValor(item));
        select.add(opcion);
    }
}

function mostrarMensaje(texto: string, tipo: 'ok' | 'error' | 'info'): void {
    const toasts = document.getElementById("toasts") as HTMLDivElement;
    const mensaje = document.createElement("div") as HTMLDivElement;

    mensaje.className = `toast toast-${tipo}`;
    mensaje.textContent = texto;
    toasts.appendChild(mensaje);

    setTimeout(() => mensaje.remove(), 3000);
}

function pintarClientes(clientes: ClienteDTO[], llamado: 'filtro' | 'facturaNueva'): void {
    const tbodyClientes = document.getElementById("tbodyClientes") as HTMLTableSectionElement;
    tbodyClientes.innerHTML = "";
    sinClientes.hidden = clientes.length > 0;

    for (const cliente of clientes) { 
        const fila = document.createElement("tr");

        const tdCuit = document.createElement("td");
        tdCuit.textContent = cliente.cuitCuil;

        const tdDenominacion = document.createElement("td");
        tdDenominacion.textContent = cliente.denominacion;

        const tdAccion = document.createElement("td");
        const btnElegir = document.createElement("button");
        btnElegir.type = "button";
        btnElegir.textContent = "Elegir";
        btnElegir.addEventListener("click", () => {
            if (llamado === 'facturaNueva'){
                inpCliente.value = cliente.denominacion;
                factura.cliente = cliente;
            } else {
                inpFltCliente.value = cliente.idCliente.toString();
            }
            dlgCliente.close();
        });
        tdAccion.appendChild(btnElegir);

        fila.append(tdCuit, tdDenominacion, tdAccion);
        tbodyClientes.appendChild(fila);
    }
}

function pintarArticulos(articulos: ListaPrecioArticuloDTO[]){
    const tbodyArticulos = document.getElementById("tbodyArticulos") as HTMLTableSectionElement;
    tbodyArticulos.innerHTML = "";
    sinArticulos.hidden = articulos.length > 0;

    for(const articulo of articulos){
        const fila = document.createElement("tr");

        const tdCodigo = document.createElement("td");
        tdCodigo.textContent = articulo.codigo;

        const tdDenominacion = document.createElement("td");
        tdDenominacion.textContent = articulo.denominacion;

        const tdRubro = document.createElement("td");
        tdRubro.textContent = articulo.denominacionRubro ?? "";

        const tdMarca = document.createElement("td");
        tdMarca.textContent = articulo.denominacionMarca ?? "";

        const tdPrecio = document.createElement("td");
        tdPrecio.className = "num";
        tdPrecio.textContent = articulo.precioVenta.toFixed(2);

        const tdAccion = document.createElement("td");
        const btnElegir = document.createElement("button");
        btnElegir.type = "button";
        btnElegir.textContent = "Elegir";
        btnElegir.addEventListener("click", () => {
            articuloElejido = articulo;
            inpArticulo.value = articulo.denominacion;
            inpPrecioArticulo.value = articulo.precioVenta.toFixed(2);
            dlgArticulo.close();
        });
        tdAccion.appendChild(btnElegir);

        fila.append(tdCodigo, tdDenominacion, tdRubro, tdMarca, tdPrecio, tdAccion);
        tbodyArticulos.appendChild(fila);
    }
} 

async function cargarCatalogos(): Promise<boolean> {
    try {
        const [puntosVenta, tiposMoneda, condicionesIva, listasPrecio] = await Promise.all([
                catalogoService.listarPuntosVenta(),
                catalogoService.listarTiposMoneda(),
                catalogoService.listarCondicionesIVA(),
                catalogoService.listarListaPrecio(),
        ]);
        poblarSelect(selPuntoVenta, puntosVenta, pv => pv.idPuntoVenta.toString(), pv => pv.descripcion, "Elija un Punto de Venta");
        poblarSelect(selTipoMoneda, tiposMoneda, tm => tm.idTipoMoneda.toString(), tm => tm.simbolo + " " + tm.denominacion, "Elija un Tipo de Moneda");
        poblarSelect(selCondicionIva, condicionesIva, civa => civa.idCondicionIva.toString(), civa => civa.denominacion, "Elija una Condicion Iva");
        poblarSelect(selListaPrecio, listasPrecio, lp => lp.idListaPrecio.toString(), lp => lp.denominacion, "Elija una Lista de Precios");
        return true;
    } catch (error) {
        const texto = error instanceof Error ? error.message : "Error desconocido al cargar los catálogos";
        mostrarMensaje(texto, 'error');
        return false;
    }
}

function pintarItems(){
    const tbodyItems = document.getElementById("tbodyItems") as HTMLTableSectionElement;
    tbodyItems.innerHTML= "";

    const sinItems = document.getElementById("sinItems") as HTMLParagraphElement;
    sinItems.hidden = factura.tieneItems;

    for(const itemF of factura.leerDetalles()){
        const fila = document.createElement("tr");

        const tdDenArt = document.createElement("td");
        tdDenArt.textContent = itemF.nombreArticulo;

        const tdDes = document.createElement("td");
        const inpDes = document.createElement("input");
        inpDes.setAttribute('type', 'text');
        inpDes.setAttribute('placeHolder', 'Sin detalles');
        inpDes.value = itemF.descripcion;
        inpDes.addEventListener("change", () =>{
            itemF.descripcion = inpDes.value;
        });
        tdDes.appendChild(inpDes);

        const tdCant = document.createElement("td");
        const inpCant = document.createElement("input");
        inpCant.setAttribute('type', 'number');
        inpCant.setAttribute('min', '1')
        inpCant.value = itemF.getCantidad.toString();
        inpCant.addEventListener("change", () => {
            try {
                itemF.setCantidad = Number(inpCant.value);
            } catch (error) {
                inpCant.value = itemF.getCantidad.toString();
                const texto = error instanceof Error ? error.message : "Error desconocido al cargar los articulos";
                mostrarMensaje(texto, 'error');
            }
            tdSubtotal.textContent = conIva(itemF.subtotal).toFixed(2);
            valTotal.textContent = "$" + conIva(factura.total).toFixed(2);
        });
        tdCant.appendChild(inpCant);

        const tdPrecio = document.createElement("td");
        tdPrecio.textContent = itemF.precio.toFixed(2);

        const tdSubtotal = document.createElement("td");
        tdSubtotal.textContent = conIva(itemF.subtotal).toFixed(2);

        tdCant.className = "num";
        tdPrecio.className = "num";
        tdSubtotal.className = "num";

        const tdAccion = document.createElement("td");
        const btnEliminar = document.createElement("button");
        btnEliminar.type = "button";
        btnEliminar.className = "peligro";
        btnEliminar.textContent = "Quitar";
        btnEliminar.addEventListener("click", () => {
            factura.quitarDetalle(itemF.idArticulo);
            pintarItems();
        });
        tdAccion.appendChild(btnEliminar);

        fila.append(tdDenArt, tdDes, tdCant, tdPrecio, tdSubtotal,tdAccion);
        tbodyItems.appendChild(fila);
    }
    const valTotal = document.getElementById("valTotal") as HTMLElement;
    valTotal.textContent = "$" + conIva(factura.total).toFixed(2);
}

function pintarFacturasBuscadas(facturasBuscadas: FacturaReporteDTO[]){
    tbodyFacturas.innerHTML = "";

    for(const facBuscada of facturasBuscadas){
        const fila = document.createElement("tr");

        const tdNro = document.createElement("td");
        tdNro.textContent = formatearComprobante(facBuscada);

        const tdFecha = document.createElement("td");
        tdFecha.textContent = facBuscada.fechaEmision.substring(0, 10);

        const tdCliente = document.createElement("td");
        tdCliente.textContent = facBuscada.clienteDenominacion;

        const tdCondIva = document.createElement("td");
        tdCondIva.textContent = facBuscada.condicionIva;

        const tdPuntoV = document.createElement("td");
        tdPuntoV.textContent = facBuscada.puntoVentaDescripcion;

        const tdTotal = document.createElement("td");
        tdTotal.className = "num";
        tdTotal.textContent = facBuscada.importeTotal.toLocaleString("es-AR", { style: "currency", currency: "ARS" });

        const tdItems = document.createElement("td");
        tdItems.className = "num";
        tdItems.textContent = facBuscada.cantidadItems.toString();

        const tdEstado = document.createElement("td");
        tdEstado.textContent = facBuscada.estado ?? "";
        tdEstado.title = facBuscada.motivoRechazo ?? "";

        const tdCae = document.createElement("td");
        tdCae.textContent = facBuscada.cae ?? "-";

        const tdAcciones = document.createElement("td");

        const btnEditar = document.createElement("button");
        btnEditar.type = "button";
        btnEditar.textContent = "Editar";
        btnEditar.disabled = !puedeEditar(facBuscada);
        btnEditar.addEventListener("click", () => abrirEdicion(facBuscada.idFactura));

        const btnArca = document.createElement("button");
        btnArca.type = "button";
        btnArca.textContent = "Enviar a ARCA";
        btnArca.disabled = !puedeEnviar(facBuscada);
        btnArca.addEventListener("click", async () => {
            try {
                const resultado = await facturaService.autorizarFactura(facBuscada.idFactura);
                mostrarMensaje(resultado.cae
                    ? `Factura autorizada por ARCA. CAE: ${resultado.cae}`
                    : `Factura ${resultado.estado}: ${resultado.motivoRechazo ?? ""}`, 
                    resultado.cae
                    ? 'ok'
                    : 'error'
                );
                await cargarFacturas();
            } catch (error) {
                const texto = error instanceof Error ? error.message : "Error al enviar la factura a ARCA";
                mostrarMensaje(texto, 'error');
            }
        });

        const btnBorrar = document.createElement("button");
        btnBorrar.type = "button";
        btnBorrar.className = "peligro";
        btnBorrar.textContent = puedeEliminar(facBuscada) ? "Eliminar" : "Anular";
        if (puedeEliminar(facBuscada)){
            btnBorrar.addEventListener("click", async () => {
                const confirmacion = confirm(`Desea eliminar esta factura`);
                if (!confirmacion) return;
                try {
                    await facturaService.eliminarFactura(facBuscada.idFactura);
                    mostrarMensaje(`Factura eliminada`, 'info');
                    btnBorrar.disabled = true;
                    if (tbodyFacturas.children.length === 1 && paginaActual > 0) paginaActual--;
                    await cargarFacturas();
                } catch (error) {
                    const texto = error instanceof Error ? error.message : "Error desconocido al eliminar la factura";
                    mostrarMensaje(texto, 'error');
                }
            });
        } else if(puedeAnular(facBuscada)){
            btnBorrar.addEventListener("click", async () => {
                const confirmacion = confirm(`Desea anular la factura Nro: ${formatearComprobante(facBuscada)}?`);
                if (!confirmacion) return;
                try {
                    await facturaService.anularFactura(facBuscada.idFactura);
                    mostrarMensaje(`Factura de Nro: ${formatearComprobante(facBuscada)} anulada`, 'info');
                    btnBorrar.disabled = true;
                    await cargarFacturas();
                } catch (error){
                    const texto = error instanceof Error ? error.message : "Error desconocido al eliminar la factura";
                    mostrarMensaje(texto, 'error');
                }
            });
        } else {
            btnBorrar.disabled = facBuscada.estado === "ANULADA";
        }

        const btnImprimir = document.createElement("button");
            btnImprimir.type = "button";
            btnImprimir.textContent = "Imprimir";
            btnImprimir.disabled = !facBuscada.cae || facBuscada.estado === "ANULADA";
            btnImprimir.addEventListener("click", async () => {
                try {
                    const pdf = await facturaService.obtenerPdf(facBuscada.idFactura);
                    window.open(URL.createObjectURL(pdf), "_blank");
                } catch (error) {
                    mostrarMensaje(error instanceof Error ? error.message : "Error al imprimir", 'error');
                }
        });

        const contenedor = document.createElement("div");
        contenedor.className = "acciones-factura";
        contenedor.append(btnEditar, btnArca, btnBorrar, btnImprimir);
        tdAcciones.appendChild(contenedor);

        fila.append(tdNro, tdFecha, tdCliente, tdCondIva, tdPuntoV, tdTotal, tdItems, tdEstado, tdCae, tdAcciones);
        tbodyFacturas.appendChild(fila);
    }

}

function leerFiltros(): FacturaFiltrosDTO{
    const fltFechaDesde = document.getElementById("fltFechaDesde") as HTMLInputElement;
    const fltFechaHasta = document.getElementById("fltFechaHasta") as HTMLInputElement;
    const fltNumero = document.getElementById("fltNumero") as HTMLInputElement;
    const fltInformada = document.getElementById("fltInformada") as HTMLInputElement;
    const valor = fltInformada.value === "" ? undefined : fltInformada.value;

    const filtro : FacturaFiltrosDTO = {
        fechaDesde : fltFechaDesde.value,
        fechaHasta : fltFechaHasta.value,
        numeroComprobante: fltNumero.value ? Number(fltNumero.value) : undefined,
        idCliente: inpFltCliente.value ? Number(inpFltCliente.value) : undefined,
        informada: valor === undefined ? undefined : valor === "true" ? true : false,
    }
    return filtro;
}

async function cargarFacturas(){
    if(paginaActual<0 || paginaActual+1>paginasMax) {
        mostrarMensaje("Elija una pagina existente", 'error');
        return;
    }
    try {
        const response = await facturaService.obtenerFacturasPaginadas(filtrosVigentes, paginaActual, tamanio);
        pintarFacturasBuscadas(response.contenido);
        const totalPaginas = Math.max(response.totalPaginas, 1);
        paginasMax = totalPaginas;
        infoPagina.textContent = `Página ${response.pagina + 1} de ${totalPaginas}`;
        btnAnterior.disabled = response.pagina === 0;
        btnSiguiente.disabled = response.pagina + 1 >= totalPaginas;
    } catch (error) {
        const texto = error instanceof Error ? error.message : "Error desconocido al cargar las facturas";
        mostrarMensaje(texto, 'error');
    }
}

function cerrarFormFactura(){
    inpPrecioArticulo.value = "";
    formFactura.reset()
    factura = new Factura();
    iva = 0;
    pintarItems();
    articuloElejido = null;
    idEdicion = null;
    configurarModoFormulario();
}

function ocultarFormFactura(){
    sectNuevaFactura.hidden = true;
    btnNuevaFactura.hidden = false;
}

function configurarModoFormulario(){
    const editando = idEdicion !== null;
    tituloFactura.textContent = editando ? "Editar factura" : "Nueva factura";
    btnGuardarFactura.textContent = editando ? "Guardar cambios" : "Guardar factura";
    btnCerrarNuevaFactura.textContent = editando ? "Cancelar edición" : "Cerrar Nueva Factura";

    for (const campo of [selListaPrecio, selPuntoVenta, selTipoMoneda, selCondicionIva]) {
        campo.disabled = editando;
    }
    btnBuscarCliente.disabled = editando;
    btnQuitarCliente.disabled = editando;
}

async function abrirEdicion(idFactura: number): Promise<void> {
    if (!sectNuevaFactura.hidden && !confirm("Hay un formulario abierto, si seguís vas a perder lo que no guardaste. ¿Continuar?")) return;

    try {
        const dto = await facturaService.obtenerFacturaAEditar(idFactura);

        cerrarFormFactura();
        const catalogosListos = await cargarCatalogos();
        if (!catalogosListos) return;

        factura = Factura.desdeDTO(dto);
        idEdicion = idFactura;

        selListaPrecio.value = dto.idListaPrecio.toString();
        selPuntoVenta.value = dto.idPuntoVenta.toString();
        selTipoMoneda.value = dto.idTipoMoneda.toString();
        selCondicionIva.value = dto.idCondicionIVA.toString();
        actualizarIva();
        inpCliente.value = dto.denominacionCliente;
        txtObservaciones.value = factura.observaciones;

        pintarArticulos([]);
        configurarModoFormulario();
        pintarItems();

        sectNuevaFactura.hidden = false;
        btnNuevaFactura.hidden = true;
        sectNuevaFactura.scrollIntoView({ behavior: "smooth" });
    } catch (error) {
        const texto = error instanceof Error ? error.message : "Error al cargar la factura para editar";
        mostrarMensaje(texto, 'error');
    }
}

function formatearComprobante(facturaReporte: FacturaReporteDTO): string{
    return String(facturaReporte.puntoVentaNumero).padStart(4,"0") +"_"+ (facturaReporte.numeroFactura?.toString().padStart(8, "0") ?? "");
}

function puedeAnular(factura: FacturaReporteDTO): boolean{
    if (factura.estado === "AUTORIZADA") return true;
    return false;
}

function puedeEnviar(factura: FacturaReporteDTO): boolean{
    if (estadosPendientes.includes(factura.estado)) return true;
    return false;
}

function puedeEliminar(factura: FacturaReporteDTO): boolean{
    if (estadosPendientes.includes(factura.estado)) return true;
    return false;
}

function puedeEditar(factura: FacturaReporteDTO): boolean{
    if (estadosPendientes.includes(factura.estado)) return true;
    return false;
}

function alicuotaSegunCondicion(denominacion: string | undefined): number {
    if (denominacion === "Consumidor Final") return 21;
    if (denominacion === "Responsable Inscripto") return 10.5;
    return 0;   
}

function actualizarIva(): void {
    iva = alicuotaSegunCondicion(selCondicionIva.selectedOptions[0]?.text);
}

function conIva(monto: number): number {
    return monto * (1 + iva / 100);
}

const catalogoService = new CatalogoService();
const facturaService = new FacturaService();
const clienteService = new ClienteService();

const selPuntoVenta = document.getElementById("selPuntoVenta") as HTMLSelectElement;
const selTipoMoneda = document.getElementById("selTipoMoneda") as HTMLSelectElement;
const selCondicionIva = document.getElementById("selCondicionIva") as HTMLSelectElement;
const selListaPrecio = document.getElementById("selListaPrecio") as HTMLSelectElement;
const inpPrecioArticulo = document.getElementById("inpPrecioArticulo") as HTMLInputElement;


const dlgCliente = document.getElementById("dlgCliente") as HTMLDialogElement;
const inpBusquedaDenominacionC = document.getElementById("inpBusquedaDenominacionC") as HTMLInputElement;
const inpBusquedaCuitCuil = document.getElementById("inpBusquedaCuitCuil") as HTMLInputElement;
const inpCliente = document.getElementById("inpCliente") as HTMLInputElement;
const selTamanio = document.getElementById("selTamanio") as HTMLSelectElement;
let factura: Factura = new Factura();
let paginaActual : number = 0;
let tamanio : number = Number(selTamanio.value);
let filtrosVigentes: FacturaFiltrosDTO = {};
let paginasMax : number = 1;
let articuloElejido : ListaPrecioArticuloDTO | null = null;
const estadosPendientes = ["INGRESADA", "RECHAZADA", "ERROR_ARCA"];
let llamado: 'facturaNueva' | 'filtro';
let idEdicion: number | null = null;
let iva: number = 0;

const formFactura = document.getElementById("formFactura") as HTMLFormElement;
const txtObservaciones = document.getElementById("txtObservaciones") as HTMLTextAreaElement;
const btnSiguiente = document.getElementById("btnSiguiente") as HTMLButtonElement;
const btnAnterior = document.getElementById("btnAnterior") as HTMLButtonElement;
const formFiltros = document.getElementById("formFiltros") as HTMLFormElement;
const infoPagina = document.getElementById("infoPagina") as HTMLSpanElement;
const tbodyFacturas = document.getElementById("tbodyFacturas") as HTMLTableSectionElement;
const sectNuevaFactura = document.getElementById("sectNuevaFactura") as HTMLElement;
const btnNuevaFactura = document.getElementById("btnNuevaFactura") as HTMLButtonElement;
const btnCerrarNuevaFactura = document.getElementById("btnCerrarNuevaFactura") as HTMLButtonElement;
const btnGuardarFactura = document.getElementById("btnGuardarFactura") as HTMLButtonElement;
const tituloFactura = document.getElementById("t-alta") as HTMLHeadingElement;
const btnBuscarCliente = document.getElementById("btnBuscarCliente") as HTMLButtonElement;
const btnQuitarCliente = document.getElementById("btnQuitarCliente") as HTMLButtonElement;
const dlgArticulo = document.getElementById("dlgArticulo") as HTMLDialogElement;
const inpBusquedaCodigoA = document.getElementById("inpBusquedaCodigoA") as HTMLInputElement;
const inpBusquedaDenominacionA = document.getElementById("inpBusquedaDenominacionA") as HTMLInputElement; 
const inpDescripcionA = document.getElementById("inpDescripcionA") as HTMLInputElement;
const inpCantidadA = document.getElementById("inpCantidadA") as HTMLInputElement;
const inpArticulo = document.getElementById("inpArticulo") as HTMLInputElement;
const sinArticulos = document.getElementById("sinArticulos") as HTMLParagraphElement;
const sinClientes = document.getElementById("sinClientes") as HTMLParagraphElement;
const inpFltCliente = document.getElementById("inpFltCliente") as HTMLInputElement;

btnNuevaFactura.addEventListener("click", () => {
    sectNuevaFactura.hidden = false;
    btnNuevaFactura.hidden = true;
    idEdicion = null;
    configurarModoFormulario();
    cargarCatalogos();
});

btnCerrarNuevaFactura.addEventListener("click", () => {
    ocultarFormFactura();
    cerrarFormFactura();
});

btnBuscarCliente.addEventListener("click", () => {
    dlgCliente.showModal();
    llamado = 'facturaNueva';
    pintarClientes([], llamado);
});

document.getElementById("btnBuscarArticulo")!.addEventListener("click", () => {
    pintarArticulos([]);
    inpBusquedaCodigoA.value = "";
    inpBusquedaDenominacionA.value = "";

    if (!factura.idListaPrecio) {
        mostrarMensaje("Seleccione una lista de precios antes de buscar un artículo", 'error');
        return;
    }
    dlgArticulo.showModal();
});

selListaPrecio.addEventListener("change", () => {
    if (factura.tieneItems) {
        const cambio = confirm("Desea cambiar la lista de precio de la factura (perderas todos los items)");
        if (!cambio) {
            selListaPrecio.value = factura.idListaPrecio.toString();
            return;
        };
    }
    factura.idListaPrecio = Number(selListaPrecio.value); 
    inpPrecioArticulo.value = "";
    inpArticulo.value = "";
    inpDescripcionA.value = "";
    inpCantidadA.value = "1";
    articuloElejido = null;
    factura.vaciarDetalles();
    pintarItems();
    pintarArticulos([]);
});

selTipoMoneda.addEventListener("change", () => {
    factura.idTipoMoneda = Number(selTipoMoneda.value); 
});

selPuntoVenta.addEventListener("change", () => {
    factura.idPuntoVenta = Number(selPuntoVenta.value); 
});

selCondicionIva.addEventListener("change", () => {
    actualizarIva(); 
    pintarItems();
    factura.idCondicionIVA = Number(selCondicionIva.value); 
});

document.getElementById("btnEjecutarBusquedaCliente")!.addEventListener("click", async () => {
    try {
        const clientes = await clienteService.buscarClientes(
            inpBusquedaCuitCuil.value ? inpBusquedaCuitCuil.value : undefined,
            inpBusquedaDenominacionC.value ? inpBusquedaDenominacionC.value : undefined
        );
        pintarClientes(clientes, llamado);

    } catch (error) {
        const texto = error instanceof Error ? error.message : "Error al buscar clientes";
        mostrarMensaje(texto, 'error');
    }
});

document.getElementById("btnBuscarClienteFiltro")!.addEventListener("click", async () => {
    dlgCliente.showModal();
    llamado = 'filtro';
    pintarClientes([], llamado);
});

document.getElementById("btnEjecutarBusquedaArticulo")!.addEventListener("click", async () => {
    try {
        const articulos = await catalogoService.listarArticulosPorListaPrecio(factura.idListaPrecio,
            inpBusquedaCodigoA.value ? inpBusquedaCodigoA.value : undefined,
            inpBusquedaDenominacionA.value || undefined);
        
        pintarArticulos(articulos);
    } catch (error) {
        const texto = error instanceof Error ? error.message : "Error desconocido al cargar los articulos";
        mostrarMensaje(texto, 'error');
    }
});

btnQuitarCliente.addEventListener("click", () => {
    factura.cliente = null;
    inpCliente.value = "Consumidor Final";
});

document.getElementById("btnQuitarClienteFiltro")!.addEventListener("click", () => {
    inpFltCliente.value = "";
    inpFltCliente.placeholder = "Consumidor Final";
    
})

document.getElementById("btnAgregarItem")!.addEventListener("click", () =>{
    const articulo = articuloElejido;
    if (!articulo) {
        mostrarMensaje("Seleccione un artículo antes de agregarlo", 'error');
        return;
    }
    const inpCantidad = document.getElementById("inpCantidadA") as HTMLInputElement;
    const inpDescripcion = document.getElementById("inpDescripcionA") as HTMLInputElement;
    try {
        const facturaDetalle : FacturaDetalle = new FacturaDetalle(articulo.idArticulo, articulo.denominacion, articulo.precioVenta ,inpDescripcion.value, Number(inpCantidad.value), );    
        const agregado: boolean = factura.agregarDetalle(facturaDetalle);
        if (!agregado) {
            mostrarMensaje("El artículo ya se encuentra en la factura, se incrementó la cantidad", 'info');
        }     
    } catch (error) {
        const texto = error instanceof Error ? error.message : "Error desconocido al cargar los articulos";
        mostrarMensaje(texto, 'error');
        return;
    }
    pintarItems();
    articuloElejido = null;
    inpDescripcion.value = "";
    inpCantidad.value = "1";
    inpArticulo.value = "";
    inpPrecioArticulo.value = "";
});

formFactura.addEventListener("submit",async event => {
    event.preventDefault();
    factura.observaciones = txtObservaciones.value;
    if (!factura.tieneItems) {
        mostrarMensaje("No se puede crear una factura sin añadir articulos",'error')
        return;
    };

    const idAEditar = idEdicion;
    try {
        if (idAEditar === null) {
            await facturaService.crearFactura(factura.aRequest());
            mostrarMensaje("La factura se creo correctamente :D", 'ok');
        } else {
            await facturaService.actualizarFactura(idAEditar, factura.aRequestEdit());
            mostrarMensaje("La factura se actualizó correctamente", 'ok');
            ocultarFormFactura();
            await cargarFacturas();
        }
    } catch (error) {
        const texto = error instanceof Error
            ? error.message
            : idAEditar === null ? "Error al crear la factura" : "Error al actualizar la factura";
        mostrarMensaje(texto, 'error');
        ocultarFormFactura();
        // Si falló al editar, el estado de la factura pudo haber cambiado: se recarga para mostrar lo real.
        if (idAEditar !== null) await cargarFacturas();
    } finally {
        cerrarFormFactura();
    }
});

btnAnterior.addEventListener("click", () => {
    paginaActual--;
    cargarFacturas();
});

btnSiguiente.addEventListener("click", () => {
    paginaActual++;
    cargarFacturas();
});

selTamanio.addEventListener("change", () => {
    tamanio = Number(selTamanio.value);
    paginaActual = 0;
    cargarFacturas();
})

formFiltros.addEventListener("submit", event => {
    event.preventDefault();
    filtrosVigentes = leerFiltros();
    paginaActual = 0;   
    cargarFacturas();
});

document.getElementById("btnLimpiar")!.addEventListener("click", () => {
    formFiltros.reset();
    filtrosVigentes = {};
    paginaActual = 0;
    tbodyFacturas.innerHTML= "";
    infoPagina.textContent = "Página 1 de 1";
    btnAnterior.disabled = true;
    btnSiguiente.disabled = true;
    paginasMax = 1;
});
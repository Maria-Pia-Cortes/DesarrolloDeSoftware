package com.example.tpGrupalSpring.dto;

import com.example.tpGrupalSpring.entities.FacturaVenta;
import lombok.Builder;


import java.util.Date;

@Builder

public record FacturaReporteDTO(
        Long id,
        Long numeroFactura,
        Date fechaEmision,
        String clienteDenominacion,
        String condicionIva,
        String puntoVentaDescripcion,
        double importeTotal,
        long cantidadItems,
        String estado
) {
    public static FacturaReporteDTO toDto(FacturaVenta facturaVenta){
        // El cliente es opcional (null = Consumidor Final), igual que en el JPQL del reporte
        String cliente = facturaVenta.getCliente() != null
                ? facturaVenta.getCliente().getDenominacion()
                : "Consumidor Final";

        return FacturaReporteDTO.builder()
                .id(facturaVenta.getId())
                .numeroFactura(facturaVenta.getNumero())
                .fechaEmision(facturaVenta.getFechaEmision())
                .clienteDenominacion(cliente)
                .condicionIva(facturaVenta.getCondicionIva().getDenominacion())
                .puntoVentaDescripcion(facturaVenta.getPuntoVenta().getDescripcion())
                .importeTotal(facturaVenta.getImporteTotal())
                .cantidadItems(facturaVenta.getDetalles().size())
                .estado(facturaVenta.getEstado())
                .build();
    }
}

package com.example.tpGrupalARCA.entities;

import jakarta.persistence.*;
import lombok.*;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Entity
@Table (name = "Factura", schema = "modelo")
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@EqualsAndHashCode(callSuper = true, exclude = {"detalles", "motivoRechazo", "estado", "fechaAnulacion"})
@ToString(exclude = {"detalles"})

public class FacturaVenta extends AuditoriaApp{
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cliente_id")
    private Cliente cliente;

    @Setter
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "tipo_moneda_id" ,nullable = false)
    private TipoMoneda tipoMoneda;

    @Setter
    private Long numero;

    @Temporal(TemporalType.DATE)
    @Column(nullable = false)
    private Date fechaEmision;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "lista_precio_id", nullable = false)
    private ListaPrecio listaPrecio;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "punto_venta_id" ,nullable = false)
    private PuntoVenta puntoVenta;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "condicion_iva_id" ,nullable = false)
    private CondicionIva condicionIva;

    private double importeCobrado;
    private double importeSaldo;

    @Setter
    @Column (nullable = false)
    private double importeTotal;
    @Setter
    private String cae;

    @Setter
    @Temporal(TemporalType.DATE)
    private Date caeFechaVencimiento;
    @Setter
    private String resultadoAfip;

    @Setter
    @Column(length = 500)
    private String motivoRechazo;

    @Setter
    @Column(nullable = false)
    private String estado;

    @Setter
    @Temporal(TemporalType.DATE)
    private Date fechaAnulacion;
    @Setter
    private String observaciones;

    @Builder.Default
    @OneToMany(mappedBy = "facturaVenta", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<FacturaVentaDetalle> detalles = new ArrayList<>();

    public void addDetalle(FacturaVentaDetalle detalle) {
        detalles.add(detalle);
        importeTotal += detalle.getImporteSubtotal();
    }

    public void limpiarDetalles(){
        this.detalles.clear();
        this.importeTotal = 0;
    }
}

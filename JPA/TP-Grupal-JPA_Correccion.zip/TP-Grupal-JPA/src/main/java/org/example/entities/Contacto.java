package org.example.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.*;

@Entity
@Table(name = "ContactoCliente", schema = "modelo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter
@Setter

public class Contacto extends EntityId{
    private String email;
    private String telefono;
    private String celular;
}

package org.example.entities;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "ListaPrecioArticulo", schema = "modelo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter

public class ListaPrecioArticulo extends AuditoriaApp{
    @ManyToOne
    @JoinColumn(nullable = false)
    private ListaPrecio listaPrecio;
    @Column(nullable = false)
    private double precioVenta;
    @ManyToOne
    @JoinColumn(nullable = false)
    private Articulo articulo;
}

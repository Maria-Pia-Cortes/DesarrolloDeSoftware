package com.example.tpGrupalARCA.repository;

import com.example.tpGrupalARCA.entities.PuntoVenta;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PuntoVentaRepository extends JpaRepository<PuntoVenta, Long>{
    Optional<PuntoVenta> findByIdAndFechaBajaNull(Long id);
}

import { FacturaFiltrosDTO, FacturaReporteDTO, FacturaRequestDTO } from './models/factura.dto.js';

// Capa de cliente HTTP: centraliza todas las llamadas al backend
export class FacturaService {

    private readonly baseUrl = 'http://localhost:8080/api/facturas';

    // GET /api/facturas: lista las facturas. Cada filtro que viene se manda como parametro de la URL
    async obtenerFacturas(filtros: FacturaFiltrosDTO = {}): Promise<FacturaReporteDTO[]> {
        const params = new URLSearchParams();
        if (filtros.fechaDesde) params.append('fechaDesde', filtros.fechaDesde);
        if (filtros.fechaHasta) params.append('fechaHasta', filtros.fechaHasta);
        if (filtros.estado) params.append('estado', filtros.estado);
        if (filtros.montoMinimo !== undefined) params.append('montoMinimo', String(filtros.montoMinimo));

        const query = params.toString();
        const url = query ? `${this.baseUrl}?${query}` : this.baseUrl;

        const respuesta = await fetch(url);
        return this.leerJson<FacturaReporteDTO[]>(respuesta);
    }

    // POST /api/facturas: crea una factura (backend responde 201 con la factura creada)
    async crearFactura(factura: FacturaRequestDTO): Promise<FacturaReporteDTO> {
        const respuesta = await fetch(this.baseUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(factura)
        });
        return this.leerJson<FacturaReporteDTO>(respuesta);
    }

    // PUT /api/facturas/{id}: cambia solo el estado (y las observaciones si hay). Sirve tmb para anular
    async actualizarEstado(id: number, estado: string, observaciones?: string): Promise<FacturaReporteDTO> {
        const cambios: Partial<FacturaRequestDTO> = { estado };
        if (observaciones !== undefined) cambios.observaciones = observaciones;

        const respuesta = await fetch(`${this.baseUrl}/${id}`, {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(cambios)
        });
        return this.leerJson<FacturaReporteDTO>(respuesta);
    }

    // DELETE /api/facturas/{id}: elimina la factura (el backend manda 204)
    async eliminarFactura(id: number): Promise<void> {
        const respuesta = await fetch(`${this.baseUrl}/${id}`, { method: 'DELETE' });
        await this.verificarRespuesta(respuesta);
    }

    // Si la respuesta es un error (404, 400, 500) lanza un Error con el mensaje que del backend
    private async verificarRespuesta(respuesta: Response): Promise<void> {
        if (respuesta.ok) return;

        let mensaje = `Error ${respuesta.status}`;
        try {
            const error = await respuesta.json(); // formato del backend: { status, mensaje, fecha }
            if (error.mensaje) mensaje = error.mensaje;
        } catch {
            // la respuesta no era JSON: queda el mensaje generico
        }
        throw new Error(mensaje);
    }

    // Verifica que la respuesta sea correcta y devuelve su cuerpo JSON tipado
    private async leerJson<T>(respuesta: Response): Promise<T> {
        await this.verificarRespuesta(respuesta);
        return await respuesta.json() as T;
    }
}
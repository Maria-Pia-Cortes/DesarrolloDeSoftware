package com.example.tpGrupalARCA.dto.FacturaVenta;

import com.example.tpGrupalARCA.entities.FacturaVenta;
import com.example.tpGrupalARCA.entities.FacturaVentaDetalle;
import com.example.tpGrupalARCA.entities.ListaPrecioArticulo;

public record FacturaDetalleRequestDTO(
        Long idArticulo,
        String descripcion,
        Integer cantidad
) {
    public FacturaVentaDetalle toEntity(FacturaVenta factura, ListaPrecioArticulo listaPrecioArticulo, double iva) {
        double importeNeto = cantidad*listaPrecioArticulo.getPrecioVenta();
        double importeIva = importeNeto * iva/100;
        double importeSubtotal = importeNeto+importeIva;

        return FacturaVentaDetalle.builder()
                .facturaVenta(factura)
                .listaPrecioArticulo(listaPrecioArticulo)
                .descripcion(descripcion)
                .cantidad(cantidad)
                .precioUnitario(listaPrecioArticulo.getPrecioVenta())
                .importeNeto(importeNeto)
                .importeIva(importeIva)
                .importeSubtotal(importeSubtotal)
                .build();
    }
}

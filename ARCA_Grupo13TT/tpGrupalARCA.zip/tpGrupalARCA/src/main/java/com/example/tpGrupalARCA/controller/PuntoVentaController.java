package com.example.tpGrupalARCA.controller;

import com.example.tpGrupalARCA.dto.PuntoVenta.PuntoVentaDTO;
import com.example.tpGrupalARCA.service.PuntoVentaService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/puntos-venta")
@RequiredArgsConstructor
public class PuntoVentaController {
    private final PuntoVentaService puntoVentaService;

    @GetMapping
    public List<PuntoVentaDTO> findAll(){
        return puntoVentaService.findAll();
    }
}

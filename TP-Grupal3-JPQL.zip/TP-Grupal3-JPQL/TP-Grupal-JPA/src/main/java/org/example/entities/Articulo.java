package org.example.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "Articulo", schema = "modelo")
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter

public class Articulo extends AuditoriaApp{
    @ManyToOne
    private Rubro rubro;
    @Column(nullable = false)
    private String codigo;
    @Column(nullable = false)
    private String denominacion;
    @ManyToOne
    private Marca marca;

    @Override
    public String toString() {
        return "Articulo = " + "Codigo = " + codigo + ", Denominacion = " + denominacion;
    }
}

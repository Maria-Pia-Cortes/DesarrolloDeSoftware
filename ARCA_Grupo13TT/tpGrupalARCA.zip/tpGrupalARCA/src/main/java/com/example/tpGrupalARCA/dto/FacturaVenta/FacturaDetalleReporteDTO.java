package com.example.tpGrupalARCA.dto.FacturaVenta;

import com.example.tpGrupalARCA.entities.FacturaVentaDetalle;
import lombok.Builder;

@Builder
public record FacturaDetalleReporteDTO(
        Long idArticulo,
        String nombreArticulo,
        String descripcion,
        Integer cantidad,
        Double precioLista
) {
    public static FacturaDetalleReporteDTO toDto(FacturaVentaDetalle facturaVentaDetalle) {
        return FacturaDetalleReporteDTO.builder()
                .idArticulo(facturaVentaDetalle.getListaPrecioArticulo().getArticulo().getId())
                .nombreArticulo(facturaVentaDetalle.getListaPrecioArticulo().getArticulo().getDenominacion())
                .descripcion(facturaVentaDetalle.getDescripcion())
                .cantidad(facturaVentaDetalle.getCantidad())
                .precioLista(facturaVentaDetalle.getListaPrecioArticulo().getPrecioVenta())
                .build();
    }
}

package org.example.entities;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;

@MappedSuperclass
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public abstract class  AuditoriaApp extends EntityId{
    @Column(nullable = false)
    @Temporal(TemporalType.DATE)
    protected Date fechaAlta;
    @Temporal(TemporalType.DATE)
    protected Date fechaBaja;
    @Column(nullable = false)
    @Temporal(TemporalType.DATE)
    protected Date fechaModificacion;
    @ManyToOne
    @JoinColumn(nullable = false)
    protected Usuario usuarioCarga;
    @ManyToOne
    protected Usuario usuarioBaja;
    @ManyToOne
    @JoinColumn(nullable = false)
    protected Usuario usuarioModificacion;
}

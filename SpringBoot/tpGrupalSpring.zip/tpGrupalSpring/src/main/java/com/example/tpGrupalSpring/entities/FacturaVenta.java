package com.example.tpGrupalSpring.entities;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;
import java.util.List;

@Entity
@Table (name = "Factura", schema = "modelo")
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter
@EqualsAndHashCode(callSuper = true, exclude = {"detalles", "motivoRechazo", "estado", "fechaAnulacion"})
@ToString(exclude = {"detalles"})

public class FacturaVenta extends AuditoriaApp{
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "cliente_id")
    private Cliente cliente;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "tipo_moneda_id" ,nullable = false)
    private TipoMoneda tipoMoneda;

    private Long numero;

    @Temporal(TemporalType.DATE)
    @Column(nullable = false)
    private Date fechaEmision;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "punto_venta_id" ,nullable = false)
    private PuntoVenta puntoVenta;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "condicion_iva_id" ,nullable = false)
    private CondicionIva condicionIva;

    private double importeCobrado;
    private double importeSaldo;

    @Column (nullable = false)
    private double importeTotal;
    private String cae;
    @Temporal(TemporalType.DATE)
    private Date caeFechaVencimiento;
    private String resultadoAfip;
    @Setter
    private String motivoRechazo;

    @Setter
    @Column(nullable = false)
    private String estado;

    @Setter
    @Temporal(TemporalType.DATE)
    private Date fechaAnulacion;
    private String observaciones;

    @OneToMany(mappedBy = "facturaVenta", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<FacturaVentaDetalle> detalles;
}

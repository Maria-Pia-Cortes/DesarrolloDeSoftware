package com.example.tpGrupalARCA.entities;

import jakarta.persistence.*;
import lombok.*;

import java.util.Date;

@MappedSuperclass
@Getter
@Setter
@NoArgsConstructor
@EqualsAndHashCode(callSuper = true, of = {"fechaAlta", "usuarioCarga"})

public abstract class AuditoriaApp extends EntityId{
    @Column(nullable = false)
    @Temporal(TemporalType.DATE)
    protected Date fechaAlta = new Date();
    @Temporal(TemporalType.DATE)
    protected Date fechaBaja;
    @Column(nullable = false)
    @Temporal(TemporalType.DATE)
    protected Date fechaModificacion = new Date();
    @ManyToOne
    @JoinColumn
    protected Usuario usuarioCarga;
    @ManyToOne
    protected Usuario usuarioBaja;
    @ManyToOne
    @JoinColumn
    protected Usuario usuarioModificacion;
}

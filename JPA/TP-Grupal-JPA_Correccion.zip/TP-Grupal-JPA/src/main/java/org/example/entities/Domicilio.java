package org.example.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Table;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "DomicilioCliente", schema = "modelo")
@Builder
@NoArgsConstructor
@AllArgsConstructor
@Getter

public class Domicilio extends EntityId{
    private String nombreCalle;
    private String numeroCalle;
}

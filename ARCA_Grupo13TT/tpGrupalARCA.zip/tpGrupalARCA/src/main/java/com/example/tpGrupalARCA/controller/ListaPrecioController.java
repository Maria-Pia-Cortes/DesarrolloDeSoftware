package com.example.tpGrupalARCA.controller;

import com.example.tpGrupalARCA.dto.ListaPrecio.ListaPrecioDTO;
import com.example.tpGrupalARCA.service.ListaPrecioService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/api/listas-precio")
@RequiredArgsConstructor
public class ListaPrecioController {
    private final ListaPrecioService listaPrecioService;

    @GetMapping
    public List<ListaPrecioDTO> findAll(){
        return listaPrecioService.findAll();
    }
}

package com.example.tpGrupalARCA.service;

import com.example.tpGrupalARCA.dto.ListaPrecio.ListaPrecioArticuloDTO;
import com.example.tpGrupalARCA.entities.ListaPrecio;
import com.example.tpGrupalARCA.repository.ListaPrecioRepository;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityNotFoundException;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RequiredArgsConstructor
@Service
public class ListaPrecioArticuloService {
    private final ListaPrecioRepository listaPrecioRepository;

    @PersistenceContext
    private EntityManager em;

    public List<ListaPrecioArticuloDTO> findAll(Long idListaPrecio, String codigo, String denominacion){
        ListaPrecio listaPrecio = listaPrecioRepository.findByIdAndFechaBajaNull(idListaPrecio)
                .orElseThrow(()-> new EntityNotFoundException("No se encontro la Lista de Precio con id:" +  idListaPrecio));

        StringBuilder jpqlarticulos = new StringBuilder(
                "SELECT new com.example.tpGrupalARCA.dto.ListaPrecio.ListaPrecioArticuloDTO(" +
                        "a.id, a.codigo, a.denominacion, r.denominacion, m.denominacion, lpa.precioVenta" +
                        ")" +
                        " FROM ListaPrecioArticulo lpa " +
                        " JOIN lpa.articulo a " +
                        " LEFT JOIN a.marca m " +
                        " LEFT JOIN a.rubro r " +
                        " WHERE lpa.listaPrecio.id = :idListaPrecio AND " +
                        " lpa.fechaBaja IS NULL AND " +
                        " a.fechaBaja IS NULL"
        );

        Map<String, Object> parametros = new HashMap<>();

        if (codigo != null && !codigo.trim().isEmpty()) {
            jpqlarticulos.append(" AND LOWER(a.codigo) LIKE LOWER(CONCAT('%',:codigo,'%')) ");
            parametros.put("codigo", codigo);
        }
        if (denominacion != null && !denominacion.trim().isEmpty()) {
            jpqlarticulos.append(" AND LOWER(a.denominacion) LIKE LOWER(CONCAT('%',:denominacion,'%')) ");
            parametros.put("denominacion", denominacion);
        }

        jpqlarticulos.append(" ORDER BY a.denominacion ASC, a.id ASC ");

        TypedQuery<ListaPrecioArticuloDTO> articulos = em.createQuery(jpqlarticulos.toString(), ListaPrecioArticuloDTO.class);
        articulos.setMaxResults(20);
        parametros.put("idListaPrecio", idListaPrecio);
        parametros.forEach(articulos::setParameter);

        return articulos.getResultList();
    }
}

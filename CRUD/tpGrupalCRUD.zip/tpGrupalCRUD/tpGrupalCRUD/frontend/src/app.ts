import { FacturaService } from './FacturaService.js';
import {
    FacturaDetalleRequestDTO,
    FacturaFiltrosDTO,
    FacturaReporteDTO,
    FacturaRequestDTO
} from './models/factura.dto.js';

const servicio = new FacturaService();

// Items de la factura que se esta armando: viven en memoria hasta que se guarda la factura
let items: FacturaDetalleRequestDTO[] = [];

// Referencias al DOM
function el<T extends HTMLElement>(id: string): T {
    return document.getElementById(id) as T;
}

const mensaje = el<HTMLDivElement>('mensaje');

const formBusqueda = el<HTMLFormElement>('form-busqueda');
const filtroFechaDesde = el<HTMLInputElement>('filtro-fecha-desde');
const filtroFechaHasta = el<HTMLInputElement>('filtro-fecha-hasta');
const filtroEstado = el<HTMLSelectElement>('filtro-estado');
const filtroMontoMinimo = el<HTMLInputElement>('filtro-monto-minimo');
const btnLimpiar = el<HTMLButtonElement>('btn-limpiar');

const formAlta = el<HTMLFormElement>('form-alta');
const altaCliente = el<HTMLInputElement>('alta-cliente');
const altaCondicionIva = el<HTMLInputElement>('alta-condicion-iva');
const altaPuntoVenta = el<HTMLInputElement>('alta-punto-venta');
const altaTipoMoneda = el<HTMLInputElement>('alta-tipo-moneda');
const altaObservaciones = el<HTMLInputElement>('alta-observaciones');
const btnGuardar = el<HTMLButtonElement>('btn-guardar');

const itemArticulo = el<HTMLInputElement>('item-articulo');
const itemDescripcion = el<HTMLInputElement>('item-descripcion');
const itemCantidad = el<HTMLInputElement>('item-cantidad');
const itemPrecio = el<HTMLInputElement>('item-precio');
const itemBonificacion = el<HTMLInputElement>('item-bonificacion');
const btnAgregarItem = el<HTMLButtonElement>('btn-agregar-item');
const tbodyItems = el<HTMLTableSectionElement>('tbody-items');

const tbodyFacturas = el<HTMLTableSectionElement>('tbody-facturas');

// Utilidades
const formatoMoneda = new Intl.NumberFormat('es-AR', { style: 'currency', currency: 'ARS' });

function formatearFecha(fechaIso: string): string {
    return new Date(fechaIso).toLocaleDateString('es-AR');
}

// Lee un input numerico: devuelve undefined si esta vacio o no es un numero
function leerNumero(input: HTMLInputElement): number | undefined {
    if (input.value.trim() === '') return undefined;
    const numero = Number(input.value);
    return Number.isNaN(numero) ? undefined : numero;
}

function mostrarMensaje(texto: string, tipo: 'ok' | 'error'): void {
    mensaje.textContent = texto;
    mensaje.className = `mensaje ${tipo}`;
    mensaje.hidden = false;
}

function ocultarMensaje(): void {
    mensaje.hidden = true;
}

// Convierte un error en un texto
function textoDeError(error: unknown): string {
    if (error instanceof TypeError) {
        return 'No se pudo conectar con el servidor. ¿Está levantado el backend?';
    }
    return error instanceof Error ? error.message : String(error);
}

// Crea una celda de tabla con texto
function crearCelda(fila: HTMLTableRowElement, texto: string, clase?: string): HTMLTableCellElement {
    const celda = fila.insertCell();
    celda.textContent = texto;
    if (clase) celda.className = clase;
    return celda;
}

// Listado y filtros
function leerFiltros(): FacturaFiltrosDTO {
    const filtros: FacturaFiltrosDTO = {};
    if (filtroFechaDesde.value) filtros.fechaDesde = filtroFechaDesde.value;
    if (filtroFechaHasta.value) filtros.fechaHasta = filtroFechaHasta.value;
    if (filtroEstado.value) filtros.estado = filtroEstado.value;
    const montoMinimo = leerNumero(filtroMontoMinimo);
    if (montoMinimo !== undefined) filtros.montoMinimo = montoMinimo;
    return filtros;
}

async function cargarFacturas(): Promise<void> {
    try {
        const facturas = await servicio.obtenerFacturas(leerFiltros());
        renderFacturas(facturas);
    } catch (error) {
        mostrarMensaje(textoDeError(error), 'error');
    }
}

function renderFacturas(facturas: FacturaReporteDTO[]): void {
    tbodyFacturas.replaceChildren();

    if (facturas.length === 0) {
        const fila = tbodyFacturas.insertRow();
        const celda = crearCelda(fila, 'No hay facturas para mostrar.', 'vacio');
        celda.colSpan = 9;
        return;
    }

    // Se muestran por numero de factura
    const ordenadas = [...facturas].sort((a, b) => a.numeroFactura - b.numeroFactura);

    for (const factura of ordenadas) {
        const fila = tbodyFacturas.insertRow();
        crearCelda(fila, String(factura.numeroFactura));
        crearCelda(fila, formatearFecha(factura.fechaEmision));
        crearCelda(fila, factura.clienteDenominacion);
        crearCelda(fila, factura.condicionIva);
        crearCelda(fila, factura.puntoVentaDescripcion);
        crearCelda(fila, formatoMoneda.format(factura.importeTotal), 'numero');
        crearCelda(fila, String(factura.cantidadItems), 'numero');

        const anulada = factura.estado === 'ANULADA';
        crearCelda(fila, factura.estado, anulada ? 'estado-anulada' : undefined);

        // Acciones de la fila: anular y eliminar
        const celdaAcciones = crearCelda(fila, '', 'acciones');

        const btnAnular = document.createElement('button');
        btnAnular.type = 'button';
        btnAnular.textContent = 'Anular';
        btnAnular.className = 'secundario';
        btnAnular.disabled = anulada;
        btnAnular.addEventListener('click', () => anularFactura(factura));

        const btnEliminar = document.createElement('button');
        btnEliminar.type = 'button';
        btnEliminar.textContent = 'Eliminar';
        btnEliminar.className = 'peligro';
        btnEliminar.addEventListener('click', () => eliminarFactura(factura));

        celdaAcciones.append(btnAnular, btnEliminar);
    }
}

async function anularFactura(factura: FacturaReporteDTO): Promise<void> {
    if (!confirm(`¿Anular la factura N° ${factura.numeroFactura}?`)) return;
    try {
        await servicio.actualizarEstado(factura.id, 'ANULADA');
        mostrarMensaje(`Factura N° ${factura.numeroFactura} anulada.`, 'ok');
        await cargarFacturas();
    } catch (error) {
        mostrarMensaje(textoDeError(error), 'error');
    }
}

async function eliminarFactura(factura: FacturaReporteDTO): Promise<void> {
    if (!confirm(`¿Eliminar definitivamente la factura N° ${factura.numeroFactura}?`)) return;
    try {
        await servicio.eliminarFactura(factura.id);
        mostrarMensaje(`Factura N° ${factura.numeroFactura} eliminada.`, 'ok');
        await cargarFacturas();
    } catch (error) {
        mostrarMensaje(textoDeError(error), 'error');
    }
}

// Items de la factura en alta
function agregarItem(): void {
    const articuloId = leerNumero(itemArticulo);
    const cantidad = leerNumero(itemCantidad);
    const precio = leerNumero(itemPrecio);
    const bonificacion = leerNumero(itemBonificacion) ?? 0;
    const descripcion = itemDescripcion.value.trim();

    if (articuloId === undefined || articuloId <= 0) {
        mostrarMensaje('Ingresá el ID del artículo.', 'error');
        return;
    }
    if (cantidad === undefined || cantidad <= 0) {
        mostrarMensaje('La cantidad debe ser mayor a 0.', 'error');
        return;
    }
    if (precio !== undefined && precio < 0) {
        mostrarMensaje('El precio unitario no puede ser negativo.', 'error');
        return;
    }
    if (bonificacion < 0 || bonificacion > 100) {
        mostrarMensaje('La bonificación debe estar entre 0 y 100.', 'error');
        return;
    }

    const item: FacturaDetalleRequestDTO = {
        articuloId,
        cantidad,
        porcentajeBonificacion: bonificacion
    };
    // Los opcionales solo se envian si el usuario los completo
    if (descripcion) item.descripcion = descripcion;
    if (precio !== undefined) item.precioUnitario = precio;

    items.push(item);
    renderItems();

    itemArticulo.value = '';
    itemDescripcion.value = '';
    itemCantidad.value = '';
    itemPrecio.value = '';
    itemBonificacion.value = '0';
    ocultarMensaje();
    itemArticulo.focus();
}

function quitarItem(indice: number): void {
    items.splice(indice, 1);
    renderItems();
}

function renderItems(): void {
    tbodyItems.replaceChildren();

    if (items.length === 0) {
        const fila = tbodyItems.insertRow();
        const celda = crearCelda(fila, 'Todavía no agregaste ítems.', 'vacio');
        celda.colSpan = 6;
        return;
    }

    items.forEach((item, indice) => {
        const fila = tbodyItems.insertRow();
        crearCelda(fila, String(item.articuloId));
        crearCelda(fila, item.descripcion ?? '-');
        crearCelda(fila, String(item.cantidad), 'numero');
        crearCelda(fila, item.precioUnitario != null ? formatoMoneda.format(item.precioUnitario) : 'Precio de lista', 'numero');
        crearCelda(fila, `${item.porcentajeBonificacion} %`, 'numero');

        const celdaAccion = crearCelda(fila, '', 'acciones');
        const btnQuitar = document.createElement('button');
        btnQuitar.type = 'button';
        btnQuitar.textContent = 'Quitar';
        btnQuitar.className = 'peligro';
        btnQuitar.addEventListener('click', () => quitarItem(indice));
        celdaAccion.append(btnQuitar);
    });
}

// Alta de factura
async function guardarFactura(): Promise<void> {
    const clienteId = leerNumero(altaCliente);
    const condicionIvaId = leerNumero(altaCondicionIva);
    const puntoVentaId = leerNumero(altaPuntoVenta);
    const tipoMonedaId = leerNumero(altaTipoMoneda);
    const observaciones = altaObservaciones.value.trim();

    if (condicionIvaId === undefined || puntoVentaId === undefined || tipoMonedaId === undefined) {
        mostrarMensaje('Completá la condición de IVA, el punto de venta y el tipo de moneda.', 'error');
        return;
    }
    if (items.length === 0) {
        mostrarMensaje('Agregá al menos un ítem a la factura.', 'error');
        return;
    }

    const factura: FacturaRequestDTO = {
        condicionIvaId,
        puntoVentaId,
        tipoMonedaId,
        detalles: [...items]
    };
    if (clienteId !== undefined) factura.clienteId = clienteId;
    if (observaciones) factura.observaciones = observaciones;

    btnGuardar.disabled = true;
    try {
        const creada = await servicio.crearFactura(factura);
        mostrarMensaje(
            `Factura N° ${creada.numeroFactura} creada. Total: ${formatoMoneda.format(creada.importeTotal)}.`,
            'ok'
        );
        formAlta.reset();
        items = [];
        renderItems();
        await cargarFacturas();
    } catch (error) {
        mostrarMensaje(textoDeError(error), 'error');
    } finally {
        btnGuardar.disabled = false;
    }
}

// Eventos
formBusqueda.addEventListener('submit', (evento) => {
    evento.preventDefault();
    ocultarMensaje();
    cargarFacturas();
});

btnLimpiar.addEventListener('click', () => {
    formBusqueda.reset();
    ocultarMensaje();
    cargarFacturas();
});

btnAgregarItem.addEventListener('click', agregarItem);

formAlta.addEventListener('submit', (evento) => {
    evento.preventDefault();
    guardarFactura();
});

// Inicio
renderItems();
cargarFacturas();
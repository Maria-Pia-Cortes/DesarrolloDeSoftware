export interface ClienteDTO {
    idCliente : number,
    cuitCuil : string,
    denominacion : string
}
package org.example.entities;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "FacturaDetalle")
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Getter

public class FacturaVentaDetalle extends EntityId{
    @Setter
    @ManyToOne
    @JoinColumn(nullable = false)
    private FacturaVenta facturaVenta;
    @ManyToOne
    @JoinColumn(nullable = false)
    private ListaPrecioArticulo listaPrecioArticulo;
    private String descripcion;
    @Column(nullable = false)
    private double cantidad;
    @Column(nullable = false)
    private double precioUnitario;
    private double porcentajeBonificacion;
    private double importeNeto;
    private double importeIva;
    @Column(nullable = false)
    private double importeSubtotal;
}

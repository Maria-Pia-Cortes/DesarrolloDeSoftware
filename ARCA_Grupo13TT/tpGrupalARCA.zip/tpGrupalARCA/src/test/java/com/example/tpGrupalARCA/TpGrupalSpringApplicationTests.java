package com.example.tpGrupalARCA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpGrupalSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}

package com.example.tpGrupalSpring.service;

import com.example.tpGrupalSpring.dto.FacturaReporteDTO;
import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.persistence.TypedQuery;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class FacturaService {

    @PersistenceContext
    private EntityManager em;

    public List<FacturaReporteDTO> buscarFacturasFiltradas(Date fechaDesde, Date fechaHasta, String estado, Double montoMinimo){
        StringBuilder jpql = new StringBuilder(
                "SELECT new com.example.tpGrupalSpring.dto.FacturaReporteDTO( " +
                        "f.numero, f.fechaEmision," +
                        " CASE" +
                        "   WHEN c.denominacion IS NULL THEN 'Consumidor Final'" +
                        "   ELSE c.denominacion" +
                        " END," +
                        " ci.denominacion, pv.descripcion, f.importeTotal, COUNT(d) " +
                        ")" +
                        " FROM FacturaVenta f " +
                        " LEFT JOIN f.cliente c " +
                        " JOIN f.condicionIva ci " +
                        " JOIN f.puntoVenta pv " +
                        " JOIN f.detalles d " +
                        " WHERE 1=1"
        );

        Map<String, Object> parametros = new HashMap<>();

        if(fechaDesde != null){
            jpql.append(" AND f.fechaEmision >= :fechaDesde ");
            parametros.put("fechaDesde", fechaDesde);
        }
        if(fechaHasta != null){
            jpql.append(" AND f.fechaEmision <= :fechaHasta ");
            parametros.put("fechaHasta", fechaHasta);
        }
        if(estado != null && !estado.trim().isEmpty()){
            jpql.append(" AND f.estado = :estado ");
            parametros.put("estado", estado);
        }
        if (montoMinimo != null){
            jpql.append(" AND f.importeTotal >= :montoMinimo ");
            parametros.put("montoMinimo", montoMinimo);
        }

        jpql.append(" GROUP BY f.id, f.numero, f.fechaEmision, c.denominacion, ci.denominacion," +
                " pv.descripcion, f.importeTotal");

        TypedQuery<FacturaReporteDTO> query = em.createQuery(jpql.toString(),
                FacturaReporteDTO.class);
        parametros.forEach(query::setParameter);

        return query.getResultList();
    }
}
